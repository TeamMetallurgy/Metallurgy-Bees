package forestry;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLInterModComms.IMCEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.network.NetworkMod;
import forestry.core.ForestryCore;
import forestry.core.network.PacketHandler;
import forestry.core.utils.FluidMap;
import forestry.core.utils.ItemStackMap;

@Mod(modid="Forestry", name="Forestry", version="2.3.1.0", dependencies="after:Buildcraft|Core;after:ExtrabiomesXL;after:BiomesOPlenty;after:IC2")
@NetworkMod(channels={"FOR"}, clientSideRequired=true, serverSideRequired=true, packetHandler=PacketHandler.class)
public class Forestry
{

  @Mod.Instance("Forestry")
  public static Forestry instance;

  @SidedProxy(clientSide="forestry.core.ForestryClient", serverSide="forestry.core.ForestryCore")
  public static ForestryCore core = new ForestryCore();

  public Forestry()
  {
    forestry.api.fuels.FuelManager.fermenterFuel = new ItemStackMap();
    forestry.api.fuels.FuelManager.moistenerResource = new ItemStackMap();
    forestry.api.fuels.FuelManager.rainSubstrate = new ItemStackMap();
    forestry.api.fuels.FuelManager.bronzeEngineFuel = new FluidMap();
    forestry.api.fuels.FuelManager.copperEngineFuel = new ItemStackMap();
  }

  @Mod.EventHandler
  public void preInit(FMLPreInitializationEvent event)
  {
    core.preInit(event.getSourceFile(), this);
  }

  @Mod.EventHandler
  public void init(FMLInitializationEvent event) {
    core.init(this);
  }

  @Mod.EventHandler
  public void postInit(FMLPostInitializationEvent event) {
    core.postInit();
  }

  @Mod.EventHandler
  public void serverStarting(FMLServerStartingEvent event) {
    core.serverStarting(event.getServer());
  }

  @Mod.EventHandler
  public void processIMCMessages(FMLInterModComms.IMCEvent event)
  {
    core.processIMCMessages(event.getMessages());
  }
}