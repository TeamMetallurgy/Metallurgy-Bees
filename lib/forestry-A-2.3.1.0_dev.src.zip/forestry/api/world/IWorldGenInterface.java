package forestry.api.world;

import net.minecraft.world.gen.feature.WorldGenerator;

public abstract interface IWorldGenInterface
{
  public abstract Class<? extends WorldGenerator>[] getTreeGenerators(String paramString);
}