package forestry.api.world;

import net.minecraft.world.World;

public abstract interface ITreeGenData
{
  public abstract int getGirth(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract float getHeightModifier();

  public abstract boolean canGrow(World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract void setLeaves(World paramWorld, String paramString, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean allowsFruitBlocks();

  public abstract boolean trySpawnFruitBlock(World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}