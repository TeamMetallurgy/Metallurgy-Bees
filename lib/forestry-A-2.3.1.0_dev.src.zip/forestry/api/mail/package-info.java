package forestry.api.mail;

import cpw.mods.fml.common.API;

@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|mail")
abstract interface package-info
{
}