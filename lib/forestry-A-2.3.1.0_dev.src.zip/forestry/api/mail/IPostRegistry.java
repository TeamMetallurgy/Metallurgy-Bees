package forestry.api.mail;

import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IPostRegistry
{
  public abstract IPostOffice getPostOffice(World paramWorld);

  public abstract boolean isLetter(ItemStack paramItemStack);

  public abstract ILetter createLetter(MailAddress paramMailAddress1, MailAddress paramMailAddress2);

  public abstract ILetter getLetter(ItemStack paramItemStack);

  public abstract ItemStack createLetterStack(ILetter paramILetter);

  public abstract void registerCarrier(IPostalCarrier paramIPostalCarrier);

  public abstract IPostalCarrier getCarrier(String paramString);

  public abstract Map<String, IPostalCarrier> getRegisteredCarriers();

  public abstract void deleteTradeStation(World paramWorld, String paramString);

  public abstract ITradeStation getOrCreateTradeStation(World paramWorld, String paramString1, String paramString2);

  public abstract ITradeStation getTradeStation(World paramWorld, String paramString);

  public abstract boolean isAvailableTradeMoniker(World paramWorld, String paramString);

  public abstract boolean isValidTradeMoniker(World paramWorld, String paramString);

  public abstract boolean isValidPOBox(World paramWorld, String paramString);
}