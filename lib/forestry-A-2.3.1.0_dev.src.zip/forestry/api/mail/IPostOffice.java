package forestry.api.mail;

import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IPostOffice
{
  public abstract void collectPostage(ItemStack[] paramArrayOfItemStack);

  public abstract IPostalState lodgeLetter(World paramWorld, ItemStack paramItemStack, boolean paramBoolean);

  public abstract ItemStack getAnyStamp(int paramInt);

  public abstract ItemStack getAnyStamp(EnumPostage paramEnumPostage, int paramInt);

  public abstract ItemStack getAnyStamp(EnumPostage[] paramArrayOfEnumPostage, int paramInt);

  public abstract void registerTradeStation(ITradeStation paramITradeStation);

  public abstract void deregisterTradeStation(ITradeStation paramITradeStation);

  public abstract Map<String, ITradeStation> getActiveTradeStations(World paramWorld);
}