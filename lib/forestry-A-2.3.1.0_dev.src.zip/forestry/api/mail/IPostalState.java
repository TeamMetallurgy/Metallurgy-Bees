package forestry.api.mail;

public abstract interface IPostalState
{
  public abstract boolean isOk();

  public abstract String getIdentifier();

  public abstract int ordinal();
}