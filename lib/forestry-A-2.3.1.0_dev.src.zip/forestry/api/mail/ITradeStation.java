package forestry.api.mail;

import net.minecraft.inventory.IInventory;

public abstract interface ITradeStation extends ILetterHandler, IInventory
{
  public abstract String getMoniker();

  public abstract boolean isValid();

  public abstract void invalidate();

  public abstract void setVirtual(boolean paramBoolean);

  public abstract boolean isVirtual();

  public abstract TradeStationInfo getTradeInfo();
}