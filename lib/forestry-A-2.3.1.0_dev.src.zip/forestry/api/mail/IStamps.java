package forestry.api.mail;

import net.minecraft.item.ItemStack;

public abstract interface IStamps
{
  public abstract EnumPostage getPostage(ItemStack paramItemStack);
}