package forestry.api.mail;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.World;

public abstract interface IPostalCarrier
{
  public abstract String getUID();

  public abstract String getName();

  @SideOnly(Side.CLIENT)
  public abstract Icon getIcon();

  public abstract IPostalState deliverLetter(World paramWorld, IPostOffice paramIPostOffice, String paramString, ItemStack paramItemStack, boolean paramBoolean);
}