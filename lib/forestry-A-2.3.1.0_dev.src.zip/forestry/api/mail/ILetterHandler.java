package forestry.api.mail;

import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface ILetterHandler
{
  public abstract IPostalState handleLetter(World paramWorld, String paramString, ItemStack paramItemStack, boolean paramBoolean);
}