package forestry.api.mail;

import forestry.api.core.INBTTagable;
import java.util.List;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;

public abstract interface ILetter extends IInventory, INBTTagable
{
  public abstract ItemStack[] getPostage();

  public abstract void setProcessed(boolean paramBoolean);

  public abstract boolean isProcessed();

  public abstract boolean isMailable();

  public abstract void setSender(MailAddress paramMailAddress);

  public abstract MailAddress getSender();

  public abstract boolean hasRecipient();

  public abstract void setRecipient(MailAddress paramMailAddress);

  public abstract MailAddress[] getRecipients();

  public abstract String getRecipientString();

  public abstract void setText(String paramString);

  public abstract String getText();

  public abstract void addTooltip(List paramList);

  public abstract boolean isPostPaid();

  public abstract int requiredPostage();

  public abstract void invalidatePostage();

  public abstract ItemStack[] getAttachments();

  public abstract void addAttachment(ItemStack paramItemStack);

  public abstract void addAttachments(ItemStack[] paramArrayOfItemStack);

  public abstract int countAttachments();

  public abstract void addStamps(ItemStack paramItemStack);
}