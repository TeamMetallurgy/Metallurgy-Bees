package forestry.api.food;

import net.minecraft.item.ItemStack;

public abstract interface IIngredientManager
{
  public abstract String getDescription(ItemStack paramItemStack);

  public abstract void addIngredient(ItemStack paramItemStack, String paramString);
}