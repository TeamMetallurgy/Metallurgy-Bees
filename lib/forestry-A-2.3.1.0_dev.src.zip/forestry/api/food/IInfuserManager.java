package forestry.api.food;

import net.minecraft.item.ItemStack;

public abstract interface IInfuserManager
{
  public abstract void addMixture(int paramInt, ItemStack paramItemStack, IBeverageEffect paramIBeverageEffect);

  public abstract void addMixture(int paramInt, ItemStack[] paramArrayOfItemStack, IBeverageEffect paramIBeverageEffect);

  public abstract ItemStack getSeasoned(ItemStack paramItemStack, ItemStack[] paramArrayOfItemStack);

  public abstract boolean hasMixtures(ItemStack[] paramArrayOfItemStack);

  public abstract ItemStack[] getRequired(ItemStack[] paramArrayOfItemStack);
}