package forestry.api.food;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public abstract interface IBeverageEffect
{
  public abstract int getId();

  public abstract void doEffect(World paramWorld, EntityPlayer paramEntityPlayer);

  public abstract String getDescription();
}