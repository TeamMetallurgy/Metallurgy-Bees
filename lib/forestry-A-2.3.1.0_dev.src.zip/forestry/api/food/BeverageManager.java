package forestry.api.food;

public class BeverageManager
{
  public static IBeverageEffect[] effectList = new IBeverageEffect[''];
  public static IInfuserManager infuserManager;
  public static IIngredientManager ingredientManager;
}