package forestry.api.lepidopterology;

import forestry.api.genetics.IAllele;
import forestry.api.genetics.IGenome;
import forestry.api.genetics.IMutation;

public abstract interface IButterflyMutation extends IMutation
{
  public abstract float getChance(IButterflyNursery paramIButterflyNursery, IAllele paramIAllele1, IAllele paramIAllele2, IGenome paramIGenome1, IGenome paramIGenome2);
}