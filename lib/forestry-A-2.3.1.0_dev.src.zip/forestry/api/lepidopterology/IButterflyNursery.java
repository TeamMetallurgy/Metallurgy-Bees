package forestry.api.lepidopterology;

import forestry.api.genetics.IHousing;
import forestry.api.genetics.IIndividual;

public abstract interface IButterflyNursery extends IHousing
{
  public abstract IButterfly getCaterpillar();

  public abstract IIndividual getNanny();

  public abstract void setCaterpillar(IButterfly paramIButterfly);

  public abstract boolean canNurse(IButterfly paramIButterfly);
}