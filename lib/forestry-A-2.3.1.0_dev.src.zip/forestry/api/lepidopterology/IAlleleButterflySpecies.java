package forestry.api.lepidopterology;

import forestry.api.genetics.IAlleleSpecies;
import java.util.EnumSet;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.BiomeDictionary.Type;

public abstract interface IAlleleButterflySpecies extends IAlleleSpecies
{
  public abstract IButterflyRoot getRoot();

  public abstract String getEntityTexture();

  public abstract EnumSet<BiomeDictionary.Type> getSpawnBiomes();

  public abstract boolean strictSpawnMatch();

  public abstract float getRarity();

  public abstract float getFlightDistance();

  public abstract boolean isNocturnal();

  public abstract Map<ItemStack, Float> getButterflyLoot();

  public abstract Map<ItemStack, Float> getCaterpillarLoot();
}