package forestry.api.lepidopterology;

import forestry.api.genetics.IAllele;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.ISpeciesRoot;
import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public abstract interface IButterflyRoot extends ISpeciesRoot
{
  public abstract boolean isMember(ItemStack paramItemStack);

  public abstract IButterfly getMember(ItemStack paramItemStack);

  public abstract IButterfly getMember(NBTTagCompound paramNBTTagCompound);

  public abstract ItemStack getMemberStack(IIndividual paramIIndividual, int paramInt);

  public abstract IButterfly templateAsIndividual(IAllele[] paramArrayOfIAllele);

  public abstract IButterfly templateAsIndividual(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract IButterflyGenome templateAsGenome(IAllele[] paramArrayOfIAllele);

  public abstract IButterflyGenome templateAsGenome(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract ILepidopteristTracker getBreedingTracker(World paramWorld, String paramString);

  public abstract EntityLiving spawnButterflyInWorld(World paramWorld, IButterfly paramIButterfly, double paramDouble1, double paramDouble2, double paramDouble3);

  public abstract boolean isMated(ItemStack paramItemStack);

  public abstract ArrayList<IButterfly> getIndividualTemplates();

  public abstract Collection<IButterflyMutation> getMutations(boolean paramBoolean);
}