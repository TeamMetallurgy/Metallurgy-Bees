package forestry.api.lepidopterology;

import forestry.api.genetics.IIndividual;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.passive.IAnimals;

public abstract interface IEntityButterfly extends IAnimals
{
  public abstract void changeExhaustion(int paramInt);

  public abstract int getExhaustion();

  public abstract IButterfly getButterfly();

  public abstract EntityCreature getEntity();

  public abstract IIndividual getPollen();

  public abstract void setPollen(IIndividual paramIIndividual);
}