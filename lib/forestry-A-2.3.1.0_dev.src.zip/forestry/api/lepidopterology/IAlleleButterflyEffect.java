package forestry.api.lepidopterology;

import forestry.api.genetics.IAlleleEffect;
import forestry.api.genetics.IEffectData;

public abstract interface IAlleleButterflyEffect extends IAlleleEffect
{
  public abstract IEffectData doEffect(IEntityButterfly paramIEntityButterfly, IEffectData paramIEffectData);
}