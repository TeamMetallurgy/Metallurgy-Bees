package forestry.api.lepidopterology;

import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleArea;
import forestry.api.genetics.IAlleleBoolean;
import forestry.api.genetics.IAlleleFloat;
import forestry.api.genetics.IAlleleFlowers;
import forestry.api.genetics.IAlleleInteger;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IAlleleTolerance;
import forestry.api.genetics.IChromosomeType;
import forestry.api.genetics.ISpeciesRoot;

public enum EnumButterflyChromosome
  implements IChromosomeType
{
  SPECIES(IAlleleButterflySpecies.class), 

  SIZE(IAlleleFloat.class), 

  SPEED(IAlleleFloat.class), 

  LIFESPAN(IAlleleInteger.class), 

  METABOLISM(IAlleleInteger.class), 

  FERTILITY(IAlleleInteger.class), 

  TEMPERATURE_TOLERANCE(IAlleleTolerance.class), 

  HUMIDITY_TOLERANCE(IAlleleTolerance.class), 

  NOCTURNAL(IAlleleBoolean.class), 

  TOLERANT_FLYER(IAlleleBoolean.class), 

  FIRE_RESIST(IAlleleBoolean.class), 

  FLOWER_PROVIDER(IAlleleFlowers.class), 

  EFFECT(IAlleleButterflyEffect.class), 

  TERRITORY(IAlleleArea.class);

  Class<? extends IAllele> clss;

  private EnumButterflyChromosome(Class<? extends IAllele> clss)
  {
    this.clss = clss;
  }

  public Class<? extends IAllele> getAlleleClass()
  {
    return clss;
  }

  public String getName()
  {
    return toString().toLowerCase();
  }

  public ISpeciesRoot getSpeciesRoot()
  {
    return AlleleManager.alleleRegistry.getSpeciesRoot("rootButterflies");
  }
}