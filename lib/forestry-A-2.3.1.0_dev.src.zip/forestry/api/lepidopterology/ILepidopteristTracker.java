package forestry.api.lepidopterology;

import forestry.api.genetics.IBreedingTracker;

public abstract interface ILepidopteristTracker extends IBreedingTracker
{
  public abstract void registerCatch(IButterfly paramIButterfly);
}