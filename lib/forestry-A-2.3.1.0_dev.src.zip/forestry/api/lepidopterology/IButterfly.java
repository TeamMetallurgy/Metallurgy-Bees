package forestry.api.lepidopterology;

import forestry.api.genetics.IIndividualLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IButterfly extends IIndividualLiving
{
  public abstract IButterflyGenome getGenome();

  public abstract IButterflyGenome getMate();

  public abstract float getSize();

  public abstract boolean canSpawn(World paramWorld, double paramDouble1, double paramDouble2, double paramDouble3);

  public abstract boolean canTakeFlight(World paramWorld, double paramDouble1, double paramDouble2, double paramDouble3);

  public abstract boolean isAcceptedEnvironment(World paramWorld, double paramDouble1, double paramDouble2, double paramDouble3);

  public abstract IButterfly spawnCaterpillar(IButterflyNursery paramIButterflyNursery);

  public abstract ItemStack[] getLootDrop(IEntityButterfly paramIEntityButterfly, boolean paramBoolean, int paramInt);

  public abstract ItemStack[] getCaterpillarDrop(IButterflyNursery paramIButterflyNursery, boolean paramBoolean, int paramInt);

  public abstract IButterfly copy();
}