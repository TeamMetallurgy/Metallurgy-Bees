package forestry.api.lepidopterology;

import forestry.api.genetics.EnumTolerance;
import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.IGenome;

public abstract interface IButterflyGenome extends IGenome
{
  public abstract IAlleleButterflySpecies getPrimary();

  public abstract IAlleleButterflySpecies getSecondary();

  public abstract float getSize();

  public abstract int getLifespan();

  public abstract int getMetabolism();

  public abstract int getFertility();

  public abstract float getSpeed();

  public abstract EnumTolerance getToleranceTemp();

  public abstract EnumTolerance getToleranceHumid();

  public abstract boolean getNocturnal();

  public abstract boolean getTolerantFlyer();

  public abstract boolean getFireResist();

  public abstract IFlowerProvider getFlowerProvider();

  public abstract IAlleleButterflyEffect getEffect();
}