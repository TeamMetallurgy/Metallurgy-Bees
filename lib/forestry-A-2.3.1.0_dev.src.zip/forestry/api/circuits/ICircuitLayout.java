package forestry.api.circuits;

public abstract interface ICircuitLayout
{
  public abstract String getUID();

  public abstract String getName();

  public abstract String getUsage();
}