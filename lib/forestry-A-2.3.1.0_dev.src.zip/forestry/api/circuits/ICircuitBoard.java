package forestry.api.circuits;

import forestry.api.core.INBTTagable;
import java.util.List;
import net.minecraft.tileentity.TileEntity;

public abstract interface ICircuitBoard extends INBTTagable
{
  public abstract int getPrimaryColor();

  public abstract int getSecondaryColor();

  public abstract void addTooltip(List<String> paramList);

  public abstract void onInsertion(TileEntity paramTileEntity);

  public abstract void onLoad(TileEntity paramTileEntity);

  public abstract void onRemoval(TileEntity paramTileEntity);

  public abstract void onTick(TileEntity paramTileEntity);

  public abstract ICircuit[] getCircuits();
}