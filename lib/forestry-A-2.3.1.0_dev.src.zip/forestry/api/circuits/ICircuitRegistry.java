package forestry.api.circuits;

import java.util.HashMap;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface ICircuitRegistry
{
  public abstract HashMap<String, ICircuit> getRegisteredCircuits();

  public abstract void registerCircuit(ICircuit paramICircuit);

  public abstract ICircuit getCircuit(String paramString);

  public abstract ICircuitLibrary getCircuitLibrary(World paramWorld, String paramString);

  public abstract void registerLegacyMapping(int paramInt, String paramString);

  public abstract ICircuit getFromLegacyMap(int paramInt);

  public abstract HashMap<String, ICircuitLayout> getRegisteredLayouts();

  public abstract void registerLayout(ICircuitLayout paramICircuitLayout);

  public abstract ICircuitLayout getLayout(String paramString);

  public abstract ICircuitLayout getDefaultLayout();

  public abstract ICircuitBoard getCircuitboard(ItemStack paramItemStack);

  public abstract boolean isChipset(ItemStack paramItemStack);
}