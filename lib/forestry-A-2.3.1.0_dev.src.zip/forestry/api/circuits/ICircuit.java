package forestry.api.circuits;

import java.util.List;
import net.minecraft.tileentity.TileEntity;

public abstract interface ICircuit
{
  public abstract String getUID();

  public abstract boolean requiresDiscovery();

  public abstract int getLimit();

  public abstract String getName();

  public abstract boolean isCircuitable(TileEntity paramTileEntity);

  public abstract void onInsertion(int paramInt, TileEntity paramTileEntity);

  public abstract void onLoad(int paramInt, TileEntity paramTileEntity);

  public abstract void onRemoval(int paramInt, TileEntity paramTileEntity);

  public abstract void onTick(int paramInt, TileEntity paramTileEntity);

  public abstract void addTooltip(List<String> paramList);
}