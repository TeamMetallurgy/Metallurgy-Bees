package forestry.api.circuits;

import cpw.mods.fml.common.API;

@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|circuits")
abstract interface package-info
{
}