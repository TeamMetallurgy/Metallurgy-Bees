package forestry.api.circuits;

public abstract interface ICircuitLibrary
{
}