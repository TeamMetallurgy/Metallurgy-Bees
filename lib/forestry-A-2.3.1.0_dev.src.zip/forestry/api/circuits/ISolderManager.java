package forestry.api.circuits;

import net.minecraft.item.ItemStack;

public abstract interface ISolderManager
{
  public abstract void addRecipe(ICircuitLayout paramICircuitLayout, ItemStack paramItemStack, ICircuit paramICircuit);
}