package forestry.api.core;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface PluginInfo
{
  public abstract String pluginID();

  public abstract String name();

  public abstract String author();

  public abstract String url();

  public abstract String version();

  public abstract String description();

  public abstract String help();
}