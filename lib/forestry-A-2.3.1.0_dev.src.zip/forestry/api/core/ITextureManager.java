package forestry.api.core;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.util.Icon;

@SideOnly(Side.CLIENT)
public abstract interface ITextureManager
{
  public abstract void registerIconProvider(IIconProvider paramIIconProvider);

  public abstract Icon getIcon(short paramShort);

  public abstract Icon getDefault(String paramString);
}