package forestry.api.core;

public abstract interface IPlugin
{
  public abstract boolean isAvailable();

  public abstract void preInit();

  public abstract void doInit();

  public abstract void postInit();
}