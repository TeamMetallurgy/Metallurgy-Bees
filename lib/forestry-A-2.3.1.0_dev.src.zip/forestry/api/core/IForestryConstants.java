package forestry.api.core;

public abstract interface IForestryConstants
{
  public abstract int getApicultureVillagerID();

  public abstract int getArboricultureVillagerID();

  public abstract String getVillagerChestGenKey();
}