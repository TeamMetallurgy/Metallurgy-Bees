package forestry.api.core;

import cpw.mods.fml.common.FMLLog;
import java.lang.reflect.Method;
import net.minecraft.item.ItemStack;

@Deprecated
public class ItemInterface
{
  public static ItemStack getItem(String ident)
  {
    ItemStack item = null;
    try
    {
      String pack = ItemInterface.class.getPackage().getName();
      pack = pack.substring(0, pack.lastIndexOf('.'));
      String itemClass = pack.substring(0, pack.lastIndexOf('.')) + ".core.config.ForestryItem";
      Object[] enums = Class.forName(itemClass).getEnumConstants();
      for (Object e : enums)
        if (e.toString().equals(ident)) {
          Method m = e.getClass().getMethod("getItemStack", new Class[0]);
          return (ItemStack)m.invoke(e, new Object[0]);
        }
    }
    catch (Exception ex) {
      FMLLog.warning("Could not retrieve Forestry item identified by: " + ident, new Object[0]);
    }

    return item;
  }
}