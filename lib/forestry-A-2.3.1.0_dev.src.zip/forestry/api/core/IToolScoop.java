package forestry.api.core;

public abstract interface IToolScoop
{
}