package forestry.api.core;

import net.minecraft.nbt.NBTTagCompound;

public abstract interface INBTTagable
{
  public abstract void readFromNBT(NBTTagCompound paramNBTTagCompound);

  public abstract void writeToNBT(NBTTagCompound paramNBTTagCompound);
}