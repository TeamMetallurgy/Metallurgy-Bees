package forestry.api.core;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public abstract interface IArmorNaturalist
{
  public abstract boolean canSeePollination(EntityPlayer paramEntityPlayer, ItemStack paramItemStack, boolean paramBoolean);
}