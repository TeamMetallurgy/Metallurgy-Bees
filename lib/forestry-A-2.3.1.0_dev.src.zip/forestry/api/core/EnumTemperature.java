package forestry.api.core;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import net.minecraft.util.Icon;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeDictionary.Type;

public enum EnumTemperature
{
  NONE("None", "habitats/ocean"), ICY("Icy", "habitats/snow"), COLD("Cold", "habitats/taiga"), 
  NORMAL("Normal", "habitats/plains"), WARM("Warm", "habitats/jungle"), HOT("Hot", "habitats/desert"), HELLISH("Hellish", "habitats/nether");


  @Deprecated
  public static ArrayList<Integer> icyBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> coldBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> normalBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> warmBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> hotBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> hellishBiomeIds = new ArrayList();
  public final String name;
  public final String iconIndex;

  private EnumTemperature(String name, String iconIndex)
  {
    this.name = name;
    this.iconIndex = iconIndex;
  }

  public String getName() {
    return name;
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon() {
    return ForestryAPI.textureManager.getDefault(iconIndex);
  }

  /** @deprecated */
  public static ArrayList<Integer> getBiomeIds(EnumTemperature temperature)
  {
    switch (1.$SwitchMap$forestry$api$core$EnumTemperature[temperature.ordinal()]) {
    case 1:
      return icyBiomeIds;
    case 2:
      return coldBiomeIds;
    case 3:
      return warmBiomeIds;
    case 4:
      return hotBiomeIds;
    case 5:
      return hellishBiomeIds;
    case 6:
    }
    return normalBiomeIds;
  }

  public static boolean isBiomeHellish(BiomeGenBase biomeGen)
  {
    return BiomeDictionary.isBiomeOfType(biomeGen, BiomeDictionary.Type.NETHER);
  }

  public static boolean isBiomeHellish(int biomeID)
  {
    return (BiomeDictionary.isBiomeRegistered(biomeID)) && (BiomeDictionary.isBiomeOfType(BiomeGenBase.biomeList[biomeID], BiomeDictionary.Type.NETHER));
  }

  public static EnumTemperature getFromValue(float rawTemp)
  {
    EnumTemperature value = ICY;

    if (rawTemp >= 2.0F) {
      value = HOT;
    }
    else if (rawTemp >= 1.2F) {
      value = WARM;
    }
    else if (rawTemp >= 0.2F) {
      value = NORMAL;
    }
    else if (rawTemp >= 0.05F) {
      value = COLD;
    }

    return value;
  }
}