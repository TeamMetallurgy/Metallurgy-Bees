package forestry.api.core;

import java.util.ArrayList;

public enum EnumHumidity
{
  ARID("Arid"), NORMAL("Normal"), DAMP("Damp");


  @Deprecated
  public static ArrayList<Integer> aridBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> dampBiomeIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> normalBiomeIds = new ArrayList();
  public final String name;

  private EnumHumidity(String name)
  {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  @Deprecated
  public static ArrayList<Integer> getBiomeIds(EnumHumidity humidity) {
    switch (1.$SwitchMap$forestry$api$core$EnumHumidity[humidity.ordinal()]) {
    case 1:
      return aridBiomeIds;
    case 2:
      return dampBiomeIds;
    case 3:
    }
    return normalBiomeIds;
  }

  public static EnumHumidity getFromValue(float rawHumidity)
  {
    EnumHumidity value = ARID;

    if (rawHumidity >= 0.9F) {
      value = DAMP;
    }
    else if (rawHumidity >= 0.3F) {
      value = NORMAL;
    }

    return value;
  }
}