package forestry.api.core;

import java.util.ArrayList;

@Deprecated
public class GlobalManager
{

  @Deprecated
  public static ArrayList<Integer> dirtBlockIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> sandBlockIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> snowBlockIds = new ArrayList();

  @Deprecated
  public static ArrayList<Integer> leafBlockIds = new ArrayList();
}