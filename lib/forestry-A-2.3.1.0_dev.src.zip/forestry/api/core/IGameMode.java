package forestry.api.core;

import net.minecraft.item.ItemStack;

public abstract interface IGameMode
{
  public abstract String getIdentifier();

  public abstract boolean getBooleanSetting(String paramString);

  public abstract int getIntegerSetting(String paramString);

  public abstract float getFloatSetting(String paramString);

  public abstract ItemStack getStackSetting(String paramString);
}