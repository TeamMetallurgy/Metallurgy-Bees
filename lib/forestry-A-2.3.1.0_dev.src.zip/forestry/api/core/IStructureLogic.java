package forestry.api.core;

public abstract interface IStructureLogic extends INBTTagable
{
  public abstract String getTypeUID();

  public abstract void validateStructure();
}