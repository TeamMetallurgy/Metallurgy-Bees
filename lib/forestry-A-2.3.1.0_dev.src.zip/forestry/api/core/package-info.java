package forestry.api.core;

import cpw.mods.fml.common.API;

@API(apiVersion="1.0", owner="Forestry", provides="ForestryAPI|core")
abstract interface package-info
{
}