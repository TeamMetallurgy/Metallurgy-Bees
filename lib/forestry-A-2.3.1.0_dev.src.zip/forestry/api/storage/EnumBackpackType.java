package forestry.api.storage;

public enum EnumBackpackType
{
  T1, T2;
}