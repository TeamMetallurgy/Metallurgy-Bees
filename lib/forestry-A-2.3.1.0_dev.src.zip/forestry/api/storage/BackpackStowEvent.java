package forestry.api.storage;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.Cancelable;

@Cancelable
public class BackpackStowEvent extends BackpackEvent
{
  public final ItemStack stackToStow;

  public BackpackStowEvent(EntityPlayer player, IBackpackDefinition backpackDefinition, IInventory backpackInventory, ItemStack stackToStow)
  {
    super(player, backpackDefinition, backpackInventory);
    this.stackToStow = stackToStow;
  }
}