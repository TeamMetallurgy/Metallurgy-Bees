package forestry.api.storage;

import net.minecraft.item.Item;

public abstract interface IBackpackInterface
{
  public abstract Item addBackpack(int paramInt, IBackpackDefinition paramIBackpackDefinition, EnumBackpackType paramEnumBackpackType);
}