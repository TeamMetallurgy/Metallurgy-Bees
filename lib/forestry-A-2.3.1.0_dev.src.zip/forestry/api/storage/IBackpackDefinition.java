package forestry.api.storage;

import java.util.Collection;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public abstract interface IBackpackDefinition
{
  public abstract String getKey();

  public abstract String getName();

  public abstract int getPrimaryColour();

  public abstract int getSecondaryColour();

  public abstract void addValidItem(ItemStack paramItemStack);

  public abstract Collection<ItemStack> getValidItems(EntityPlayer paramEntityPlayer);

  public abstract boolean isValidItem(EntityPlayer paramEntityPlayer, ItemStack paramItemStack);
}