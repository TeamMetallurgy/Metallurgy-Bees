package forestry.api.storage;

import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.item.ItemStack;

public class BackpackManager
{
  public static ArrayList<ItemStack>[] backpackItems;
  public static IBackpackInterface backpackInterface;
  public static HashMap<String, IBackpackDefinition> definitions = new HashMap();
}