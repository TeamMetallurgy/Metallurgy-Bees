package forestry.api.genetics;

import java.util.EnumSet;
import net.minecraftforge.common.EnumPlantType;

public abstract interface IAllelePlantType extends IAllele
{
  public abstract EnumSet<EnumPlantType> getPlantTypes();
}