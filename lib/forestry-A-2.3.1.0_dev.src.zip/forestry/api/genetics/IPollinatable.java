package forestry.api.genetics;

import java.util.EnumSet;
import net.minecraftforge.common.EnumPlantType;

public abstract interface IPollinatable
{
  public abstract EnumSet<EnumPlantType> getPlantType();

  public abstract IIndividual getPollen();

  public abstract boolean canMateWith(IIndividual paramIIndividual);

  public abstract void mateWith(IIndividual paramIIndividual);
}