package forestry.api.genetics;

public abstract interface ILegacyHandler
{
  public abstract void registerLegacyMapping(int paramInt, String paramString);

  public abstract IAllele getFromLegacyMap(int paramInt);
}