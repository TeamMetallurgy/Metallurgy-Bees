package forestry.api.genetics;

public abstract interface IAlleleInteger extends IAllele
{
  public abstract int getValue();
}