package forestry.api.genetics;

import forestry.api.core.INBTTagable;

public abstract interface IEffectData extends INBTTagable
{
  public abstract void setInteger(int paramInt1, int paramInt2);

  public abstract void setFloat(int paramInt, float paramFloat);

  public abstract void setBoolean(int paramInt, boolean paramBoolean);

  public abstract int getInteger(int paramInt);

  public abstract float getFloat(int paramInt);

  public abstract boolean getBoolean(int paramInt);
}