package forestry.api.genetics;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public abstract interface ISpeciesRoot
{
  public abstract String getUID();

  public abstract Class getMemberClass();

  public abstract int getSpeciesCount();

  public abstract boolean isMember(ItemStack paramItemStack);

  public abstract boolean isMember(ItemStack paramItemStack, int paramInt);

  public abstract boolean isMember(IIndividual paramIIndividual);

  public abstract IIndividual getMember(ItemStack paramItemStack);

  public abstract IIndividual getMember(NBTTagCompound paramNBTTagCompound);

  public abstract ItemStack getMemberStack(IIndividual paramIIndividual, int paramInt);

  public abstract IBreedingTracker getBreedingTracker(World paramWorld, String paramString);

  public abstract IIndividual templateAsIndividual(IAllele[] paramArrayOfIAllele);

  public abstract IIndividual templateAsIndividual(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract IChromosome[] templateAsChromosomes(IAllele[] paramArrayOfIAllele);

  public abstract IChromosome[] templateAsChromosomes(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract IGenome templateAsGenome(IAllele[] paramArrayOfIAllele);

  public abstract IGenome templateAsGenome(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract void registerTemplate(IAllele[] paramArrayOfIAllele);

  public abstract void registerTemplate(String paramString, IAllele[] paramArrayOfIAllele);

  public abstract IAllele[] getTemplate(String paramString);

  public abstract IAllele[] getDefaultTemplate();

  public abstract IAllele[] getRandomTemplate(Random paramRandom);

  public abstract Map<String, IAllele[]> getGenomeTemplates();

  public abstract ArrayList<? extends IIndividual> getIndividualTemplates();

  public abstract void registerMutation(IMutation paramIMutation);

  public abstract Collection<? extends IMutation> getMutations(boolean paramBoolean);

  public abstract Collection<? extends IMutation> getCombinations(IAllele paramIAllele);

  public abstract Collection<? extends IMutation> getPaths(IAllele paramIAllele, int paramInt);

  public abstract Map<ItemStack, Float> getResearchCatalysts();

  public abstract void setResearchSuitability(ItemStack paramItemStack, float paramFloat);

  public abstract IChromosomeType[] getKaryotype();

  public abstract IChromosomeType getKaryotypeKey();
}