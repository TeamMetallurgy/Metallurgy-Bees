package forestry.api.genetics;

public abstract interface IAlleleTolerance extends IAllele
{
  public abstract EnumTolerance getValue();
}