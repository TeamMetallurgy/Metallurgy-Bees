package forestry.api.genetics;

public abstract interface IAlleleHandler
{
  public abstract void onRegisterAllele(IAllele paramIAllele);

  public abstract void onRegisterClassification(IClassification paramIClassification);

  public abstract void onRegisterFruitFamily(IFruitFamily paramIFruitFamily);
}