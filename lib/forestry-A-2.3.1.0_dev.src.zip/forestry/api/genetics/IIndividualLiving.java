package forestry.api.genetics;

import net.minecraft.world.World;

public abstract interface IIndividualLiving extends IIndividual
{
  public abstract IGenome getMate();

  public abstract int getHealth();

  public abstract int getMaxHealth();

  public abstract void age(World paramWorld, float paramFloat);

  public abstract void mate(IIndividual paramIIndividual);

  public abstract boolean isAlive();
}