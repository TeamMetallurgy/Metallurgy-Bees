package forestry.api.genetics;

import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IFlowerProvider
{
  public abstract boolean isAcceptedFlower(World paramWorld, IIndividual paramIIndividual, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean isAcceptedPollinatable(World paramWorld, IPollinatable paramIPollinatable);

  public abstract boolean growFlower(World paramWorld, IIndividual paramIIndividual, int paramInt1, int paramInt2, int paramInt3);

  public abstract String getDescription();

  public abstract ItemStack[] affectProducts(World paramWorld, IIndividual paramIIndividual, int paramInt1, int paramInt2, int paramInt3, ItemStack[] paramArrayOfItemStack);

  public abstract ItemStack[] getItemStacks();
}