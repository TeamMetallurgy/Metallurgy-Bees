package forestry.api.genetics;

import java.util.Collection;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IAlleleRegistry
{
  public abstract void registerSpeciesRoot(ISpeciesRoot paramISpeciesRoot);

  public abstract Map<String, ISpeciesRoot> getSpeciesRoot();

  public abstract ISpeciesRoot getSpeciesRoot(String paramString);

  public abstract ISpeciesRoot getSpeciesRoot(ItemStack paramItemStack);

  public abstract ISpeciesRoot getSpeciesRoot(Class<? extends IIndividual> paramClass);

  public abstract boolean isIndividual(ItemStack paramItemStack);

  public abstract IIndividual getIndividual(ItemStack paramItemStack);

  public abstract Map<String, IAllele> getRegisteredAlleles();

  public abstract void registerAllele(IAllele paramIAllele);

  public abstract Map<String, IAllele> getDeprecatedAlleleReplacements();

  public abstract void registerDeprecatedAlleleReplacement(String paramString, IAllele paramIAllele);

  public abstract IAllele getAllele(String paramString);

  @Deprecated
  public abstract void reloadMetaMap(World paramWorld);

  @Deprecated
  public abstract IAllele getFromMetaMap(int paramInt);

  @Deprecated
  public abstract int getFromUIDMap(String paramString);

  public abstract Map<String, IClassification> getRegisteredClassifications();

  public abstract void registerClassification(IClassification paramIClassification);

  public abstract IClassification createAndRegisterClassification(IClassification.EnumClassLevel paramEnumClassLevel, String paramString1, String paramString2);

  public abstract IClassification getClassification(String paramString);

  public abstract Map<String, IFruitFamily> getRegisteredFruitFamilies();

  public abstract void registerFruitFamily(IFruitFamily paramIFruitFamily);

  public abstract IFruitFamily getFruitFamily(String paramString);

  public abstract void registerAlleleHandler(IAlleleHandler paramIAlleleHandler);

  public abstract void blacklistAllele(String paramString);

  public abstract Collection<String> getAlleleBlacklist();

  public abstract boolean isBlacklisted(String paramString);

  public abstract ItemStack getSpeciesNoteStack(String paramString, IAlleleSpecies paramIAlleleSpecies);

  public abstract ItemStack getMutationNoteStack(String paramString, IMutation paramIMutation);
}