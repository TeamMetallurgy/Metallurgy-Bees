package forestry.api.genetics;

public abstract interface IAlleleBoolean extends IAllele
{
  public abstract boolean getValue();
}