package forestry.api.genetics;

import java.util.HashMap;
import net.minecraft.item.ItemStack;

public class AlleleManager
{
  public static IAlleleRegistry alleleRegistry;
  public static HashMap<ItemStack, IIndividual> ersatzSpecimen = new HashMap();

  public static HashMap<ItemStack, IIndividual> ersatzSaplings = new HashMap();
}