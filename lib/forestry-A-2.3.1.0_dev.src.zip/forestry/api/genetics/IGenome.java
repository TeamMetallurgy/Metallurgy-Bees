package forestry.api.genetics;

import forestry.api.core.INBTTagable;

public abstract interface IGenome extends INBTTagable
{
  public abstract IAlleleSpecies getPrimary();

  public abstract IAlleleSpecies getSecondary();

  public abstract IChromosome[] getChromosomes();

  public abstract IAllele getActiveAllele(int paramInt);

  public abstract IAllele getInactiveAllele(int paramInt);

  public abstract boolean isGeneticEqual(IGenome paramIGenome);

  public abstract ISpeciesRoot getSpeciesRoot();
}