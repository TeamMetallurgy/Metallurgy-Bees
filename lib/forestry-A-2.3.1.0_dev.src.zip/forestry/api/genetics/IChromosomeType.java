package forestry.api.genetics;

public abstract interface IChromosomeType
{
  public abstract Class<? extends IAllele> getAlleleClass();

  public abstract String getName();

  public abstract ISpeciesRoot getSpeciesRoot();

  public abstract int ordinal();
}