package forestry.api.genetics;

public abstract interface IAlleleArea extends IAllele
{
  public abstract int[] getValue();
}