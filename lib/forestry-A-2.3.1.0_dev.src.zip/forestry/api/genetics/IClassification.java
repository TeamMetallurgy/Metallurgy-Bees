package forestry.api.genetics;

public abstract interface IClassification
{
  public abstract EnumClassLevel getLevel();

  public abstract String getUID();

  public abstract String getName();

  public abstract String getScientific();

  public abstract String getDescription();

  public abstract IClassification[] getMemberGroups();

  public abstract void addMemberGroup(IClassification paramIClassification);

  public abstract IAlleleSpecies[] getMemberSpecies();

  public abstract void addMemberSpecies(IAlleleSpecies paramIAlleleSpecies);

  public abstract IClassification getParent();

  public abstract void setParent(IClassification paramIClassification);

  public static enum EnumClassLevel
  {
    DOMAIN(7831551, true), KINGDOM(7848959), PHYLUM(7864246, true), DIVISION(7864246, true), CLASS(8126327), ORDER(12517239), FAMILY(16776567), 
    SUBFAMILY(16776567), TRIBE(16776567), GENUS(16759415);

    private int colour;
    private boolean isDroppable;

    private EnumClassLevel(int colour) { this(colour, false); }

    private EnumClassLevel(int colour, boolean isDroppable)
    {
      this.colour = colour;
      this.isDroppable = isDroppable;
    }

    public int getColour()
    {
      return colour;
    }

    public boolean isDroppable()
    {
      return isDroppable;
    }
  }
}