package forestry.api.genetics;

public abstract interface IAlleleFlowers extends IAllele
{
  public abstract IFlowerProvider getProvider();
}