package forestry.api.genetics;

import java.util.Collection;

public abstract interface IMutation
{
  public abstract ISpeciesRoot getRoot();

  public abstract IAllele getAllele0();

  public abstract IAllele getAllele1();

  public abstract IAllele[] getTemplate();

  public abstract float getBaseChance();

  public abstract Collection<String> getSpecialConditions();

  public abstract boolean isPartner(IAllele paramIAllele);

  public abstract IAllele getPartner(IAllele paramIAllele);

  public abstract boolean isSecret();
}