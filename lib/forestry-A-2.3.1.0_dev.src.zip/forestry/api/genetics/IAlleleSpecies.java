package forestry.api.genetics;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import forestry.api.core.IIconProvider;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IAlleleSpecies extends IAllele
{
  public abstract ISpeciesRoot getRoot();

  public abstract String getDescription();

  public abstract String getBinomial();

  public abstract String getAuthority();

  public abstract IClassification getBranch();

  public abstract int getComplexity();

  public abstract float getResearchSuitability(ItemStack paramItemStack);

  public abstract ItemStack[] getResearchBounty(World paramWorld, String paramString, IIndividual paramIIndividual, int paramInt);

  public abstract EnumTemperature getTemperature();

  public abstract EnumHumidity getHumidity();

  public abstract boolean hasEffect();

  public abstract boolean isSecret();

  public abstract boolean isCounted();

  public abstract int getIconColour(int paramInt);

  @SideOnly(Side.CLIENT)
  public abstract IIconProvider getIconProvider();
}