package forestry.api.genetics;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;

public abstract interface IBreedingTracker
{
  public abstract String getModeName();

  public abstract void setModeName(String paramString);

  public abstract int getSpeciesBred();

  public abstract void registerBirth(IIndividual paramIIndividual);

  public abstract void registerPickup(IIndividual paramIIndividual);

  public abstract void registerSpecies(IAlleleSpecies paramIAlleleSpecies);

  @Deprecated
  public abstract void registerMutation(IAllele paramIAllele1, IAllele paramIAllele2);

  public abstract void registerMutation(IMutation paramIMutation);

  public abstract boolean isDiscovered(IMutation paramIMutation);

  public abstract boolean isDiscovered(IAlleleSpecies paramIAlleleSpecies);

  public abstract void synchToPlayer(EntityPlayer paramEntityPlayer);

  public abstract void decodeFromNBT(NBTTagCompound paramNBTTagCompound);

  public abstract void encodeToNBT(NBTTagCompound paramNBTTagCompound);
}