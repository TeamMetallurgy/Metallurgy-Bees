package forestry.api.genetics;

public abstract interface IAlleleEffect extends IAllele
{
  public abstract boolean isCombinable();

  public abstract IEffectData validateStorage(IEffectData paramIEffectData);
}