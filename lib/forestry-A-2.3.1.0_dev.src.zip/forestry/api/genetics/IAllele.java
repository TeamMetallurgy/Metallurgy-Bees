package forestry.api.genetics;

public abstract interface IAllele
{
  public abstract String getUID();

  public abstract boolean isDominant();

  public abstract String getName();
}