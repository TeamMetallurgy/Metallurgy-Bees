package forestry.api.genetics;

public abstract interface IFruitFamily
{
  public abstract String getUID();

  public abstract String getName();

  public abstract String getScientific();

  public abstract String getDescription();
}