package forestry.api.genetics;

import forestry.api.core.INBTTagable;

public abstract interface IChromosome extends INBTTagable
{
  public abstract IAllele getPrimaryAllele();

  public abstract IAllele getSecondaryAllele();

  public abstract IAllele getInactiveAllele();

  public abstract IAllele getActiveAllele();
}