package forestry.api.genetics;

import forestry.api.core.INBTTagable;
import java.util.List;

public abstract interface IIndividual extends INBTTagable
{
  public abstract String getIdent();

  public abstract String getDisplayName();

  public abstract void addTooltip(List<String> paramList);

  public abstract boolean analyze();

  public abstract boolean isAnalyzed();

  public abstract boolean hasEffect();

  public abstract boolean isSecret();

  public abstract IGenome getGenome();

  public abstract boolean isGeneticEqual(IIndividual paramIIndividual);

  public abstract IIndividual copy();

  public abstract boolean isPureBred(int paramInt);
}