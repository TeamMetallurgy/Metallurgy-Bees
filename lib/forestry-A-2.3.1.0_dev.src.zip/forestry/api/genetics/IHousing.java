package forestry.api.genetics;

import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IHousing
{
  public abstract String getOwnerName();

  public abstract World getWorld();

  public abstract int getXCoord();

  public abstract int getYCoord();

  public abstract int getZCoord();

  public abstract int getBiomeId();

  public abstract EnumTemperature getTemperature();

  public abstract EnumHumidity getHumidity();

  public abstract void setErrorState(int paramInt);

  public abstract int getErrorOrdinal();

  public abstract boolean addProduct(ItemStack paramItemStack, boolean paramBoolean);
}