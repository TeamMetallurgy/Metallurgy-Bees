package forestry.api.genetics;

import java.util.Collection;
import net.minecraft.item.ItemStack;

public abstract interface IFruitBearer
{
  public abstract boolean hasFruit();

  public abstract IFruitFamily getFruitFamily();

  public abstract Collection<ItemStack> pickFruit(ItemStack paramItemStack);

  public abstract float getRipeness();

  public abstract void addRipeness(float paramFloat);
}