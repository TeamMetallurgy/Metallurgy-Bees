package forestry.api.genetics;

public abstract interface IAlleleFloat extends IAllele
{
  public abstract float getValue();
}