package forestry.api.recipes;

import net.minecraftforge.fluids.FluidStack;

public abstract interface IStillManager extends ICraftingProvider
{
  public abstract void addRecipe(int paramInt, FluidStack paramFluidStack1, FluidStack paramFluidStack2);
}