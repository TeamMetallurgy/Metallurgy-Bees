package forestry.api.recipes;

import java.util.HashMap;
import net.minecraft.item.ItemStack;

public abstract interface ICentrifugeManager extends ICraftingProvider
{
  public abstract void addRecipe(int paramInt, ItemStack paramItemStack, HashMap<ItemStack, Integer> paramHashMap);

  public abstract void addRecipe(int paramInt, ItemStack paramItemStack, ItemStack[] paramArrayOfItemStack, int[] paramArrayOfInt);

  public abstract void addRecipe(int paramInt1, ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, int paramInt2);

  public abstract void addRecipe(int paramInt, ItemStack paramItemStack1, ItemStack paramItemStack2);
}