package forestry.api.recipes;

import java.util.Collection;

public class RecipeManagers
{
  public static Collection<ICraftingProvider> craftingProviders;
  public static IBottlerManager bottlerManager;
  public static ICarpenterManager carpenterManager;
  public static ICentrifugeManager centrifugeManager;
  public static IFermenterManager fermenterManager;
  public static IMoistenerManager moistenerManager;
  public static ISqueezerManager squeezerManager;
  public static IStillManager stillManager;
  public static IFabricatorManager fabricatorManager;
}