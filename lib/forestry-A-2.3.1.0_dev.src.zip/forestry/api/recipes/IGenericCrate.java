package forestry.api.recipes;

import net.minecraft.item.ItemStack;

public abstract interface IGenericCrate
{
  public abstract void setContained(ItemStack paramItemStack1, ItemStack paramItemStack2);

  public abstract ItemStack getContained(ItemStack paramItemStack);
}