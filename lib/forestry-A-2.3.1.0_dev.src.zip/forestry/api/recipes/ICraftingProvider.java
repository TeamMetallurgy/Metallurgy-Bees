package forestry.api.recipes;

import java.util.Map;

public abstract interface ICraftingProvider
{
  public abstract Map<Object[], Object[]> getRecipes();
}