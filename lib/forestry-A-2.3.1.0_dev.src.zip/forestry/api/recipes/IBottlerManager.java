package forestry.api.recipes;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

public abstract interface IBottlerManager extends ICraftingProvider
{
  @Deprecated
  public abstract void addRecipe(int paramInt, FluidStack paramFluidStack, ItemStack paramItemStack1, ItemStack paramItemStack2);
}