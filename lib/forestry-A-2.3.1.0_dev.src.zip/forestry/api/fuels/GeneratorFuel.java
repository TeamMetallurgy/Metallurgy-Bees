package forestry.api.fuels;

import java.util.HashMap;
import net.minecraftforge.fluids.FluidStack;

public class GeneratorFuel
{
  public static HashMap<Integer, GeneratorFuel> fuels = new HashMap();
  public final FluidStack fuelConsumed;
  public final int eu;
  public final int rate;

  public GeneratorFuel(FluidStack fuelConsumed, int eu, int rate)
  {
    this.fuelConsumed = fuelConsumed;
    this.eu = eu;
    this.rate = rate;
  }
}