package forestry.api.fuels;

import net.minecraft.item.ItemStack;

public class EngineCopperFuel
{
  public final ItemStack fuel;
  public final int powerPerCycle;
  public final int burnDuration;

  public EngineCopperFuel(ItemStack fuel, int powerPerCycle, int burnDuration)
  {
    this.fuel = fuel;
    this.powerPerCycle = powerPerCycle;
    this.burnDuration = burnDuration;
  }
}