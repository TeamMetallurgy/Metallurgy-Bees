package forestry.api.fuels;

import net.minecraft.item.ItemStack;

public class FermenterFuel
{
  public final ItemStack item;
  public final int fermentPerCycle;
  public final int burnDuration;

  public FermenterFuel(ItemStack item, int fermentPerCycle, int burnDuration)
  {
    this.item = item;
    this.fermentPerCycle = fermentPerCycle;
    this.burnDuration = burnDuration;
  }
}