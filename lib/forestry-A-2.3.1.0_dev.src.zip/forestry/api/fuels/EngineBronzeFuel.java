package forestry.api.fuels;

import net.minecraftforge.fluids.Fluid;

public class EngineBronzeFuel
{
  public final Fluid liquid;
  public final int powerPerCycle;
  public final int burnDuration;
  public final int dissipationMultiplier;

  public EngineBronzeFuel(Fluid liquid, int powerPerCycle, int burnDuration, int dissipationMultiplier)
  {
    this.liquid = liquid;
    this.powerPerCycle = powerPerCycle;
    this.burnDuration = burnDuration;
    this.dissipationMultiplier = dissipationMultiplier;
  }
}