package forestry.api.fuels;

import java.util.HashMap;

public class FuelManager
{
  public static HashMap<Object, FermenterFuel> fermenterFuel;
  public static HashMap<Object, MoistenerFuel> moistenerResource;
  public static HashMap<Object, RainSubstrate> rainSubstrate;
  public static HashMap<Object, EngineBronzeFuel> bronzeEngineFuel;
  public static HashMap<Object, EngineCopperFuel> copperEngineFuel;
}