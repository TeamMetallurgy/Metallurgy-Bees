package forestry.api.fuels;

import net.minecraft.item.ItemStack;

public class RainSubstrate
{
  public ItemStack item;
  public int duration;
  public float speed;
  public boolean reverse;

  public RainSubstrate(ItemStack item, int duration, float speed)
  {
    this(item, duration, speed, false);
  }

  public RainSubstrate(ItemStack item, float speed) {
    this(item, 0, speed, true);
  }

  public RainSubstrate(ItemStack item, int duration, float speed, boolean reverse) {
    this.item = item;
    this.duration = duration;
    this.speed = speed;
    this.reverse = reverse;
  }
}