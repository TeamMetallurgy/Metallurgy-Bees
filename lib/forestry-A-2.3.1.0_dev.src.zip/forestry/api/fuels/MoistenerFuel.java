package forestry.api.fuels;

import net.minecraft.item.ItemStack;

public class MoistenerFuel
{
  public final ItemStack item;
  public final ItemStack product;
  public final int moistenerValue;
  public final int stage;

  public MoistenerFuel(ItemStack item, ItemStack product, int stage, int moistenerValue)
  {
    this.item = item;
    this.product = product;
    this.stage = stage;
    this.moistenerValue = moistenerValue;
  }
}