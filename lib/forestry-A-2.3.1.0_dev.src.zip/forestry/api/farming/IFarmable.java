package forestry.api.farming;

import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IFarmable
{
  public abstract boolean isSaplingAt(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract ICrop getCropAt(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean isGermling(ItemStack paramItemStack);

  public abstract boolean isWindfall(ItemStack paramItemStack);

  public abstract boolean plantSaplingAt(ItemStack paramItemStack, World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}