package forestry.api.farming;

import java.util.Collection;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.ForgeDirection;

public abstract interface IFarmListener
{
  public abstract boolean beforeCropHarvest(ICrop paramICrop);

  public abstract void afterCropHarvest(Collection<ItemStack> paramCollection, ICrop paramICrop);

  public abstract void hasCollected(Collection<ItemStack> paramCollection, IFarmLogic paramIFarmLogic);

  public abstract void hasCultivated(IFarmLogic paramIFarmLogic, int paramInt1, int paramInt2, int paramInt3, ForgeDirection paramForgeDirection, int paramInt4);

  public abstract void hasScheduledHarvest(Collection<ICrop> paramCollection, IFarmLogic paramIFarmLogic, int paramInt1, int paramInt2, int paramInt3, ForgeDirection paramForgeDirection, int paramInt4);

  public abstract boolean cancelTask(IFarmLogic paramIFarmLogic, ForgeDirection paramForgeDirection);
}