package forestry.api.farming;

import java.util.Collection;
import net.minecraft.item.ItemStack;

public abstract interface ICrop
{
  public abstract Collection<ItemStack> harvest();
}