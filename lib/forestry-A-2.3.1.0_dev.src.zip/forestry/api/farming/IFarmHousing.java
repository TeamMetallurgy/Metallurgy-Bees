package forestry.api.farming;

import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.fluids.FluidStack;

public abstract interface IFarmHousing
{
  public abstract int[] getCoords();

  public abstract int[] getArea();

  public abstract int[] getOffset();

  public abstract World getWorld();

  public abstract boolean doWork();

  public abstract boolean hasLiquid(FluidStack paramFluidStack);

  public abstract void removeLiquid(FluidStack paramFluidStack);

  public abstract boolean hasResources(ItemStack[] paramArrayOfItemStack);

  public abstract void removeResources(ItemStack[] paramArrayOfItemStack);

  public abstract boolean plantGermling(IFarmable paramIFarmable, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean acceptsAsGermling(ItemStack paramItemStack);

  public abstract boolean acceptsAsResource(ItemStack paramItemStack);

  public abstract boolean acceptsAsFertilizer(ItemStack paramItemStack);

  public abstract void setFarmLogic(ForgeDirection paramForgeDirection, IFarmLogic paramIFarmLogic);

  public abstract void resetFarmLogic(ForgeDirection paramForgeDirection);
}