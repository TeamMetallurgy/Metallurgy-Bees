package forestry.api.farming;

import cpw.mods.fml.common.API;

@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|farming")
abstract interface package-info
{
}