package forestry.api.farming;

import forestry.api.core.IStructureLogic;

public abstract interface IFarmInterface
{
  public abstract IStructureLogic createFarmStructureLogic(IFarmComponent paramIFarmComponent);
}