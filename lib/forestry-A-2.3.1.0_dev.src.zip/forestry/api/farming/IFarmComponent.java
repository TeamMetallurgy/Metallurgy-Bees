package forestry.api.farming;

import forestry.api.core.ITileStructure;

public abstract interface IFarmComponent extends ITileStructure
{
  public abstract boolean hasFunction();

  public abstract void registerListener(IFarmListener paramIFarmListener);

  public abstract void removeListener(IFarmListener paramIFarmListener);
}