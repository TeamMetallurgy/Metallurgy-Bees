package forestry.api.farming;

import java.util.Collection;
import java.util.HashMap;

public class Farmables
{
  public static HashMap<String, Collection<IFarmable>> farmables = new HashMap();
  public static IFarmInterface farmInterface;
}