package forestry.api.farming;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Collection;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.ForgeDirection;

public abstract interface IFarmLogic
{
  public abstract int getFertilizerConsumption();

  public abstract int getWaterConsumption(float paramFloat);

  public abstract boolean isAcceptedResource(ItemStack paramItemStack);

  public abstract boolean isAcceptedGermling(ItemStack paramItemStack);

  public abstract Collection<ItemStack> collect();

  public abstract boolean cultivate(int paramInt1, int paramInt2, int paramInt3, ForgeDirection paramForgeDirection, int paramInt4);

  public abstract Collection<ICrop> harvest(int paramInt1, int paramInt2, int paramInt3, ForgeDirection paramForgeDirection, int paramInt4);

  @SideOnly(Side.CLIENT)
  public abstract Icon getIcon();

  public abstract ResourceLocation getSpriteSheet();

  public abstract String getName();
}