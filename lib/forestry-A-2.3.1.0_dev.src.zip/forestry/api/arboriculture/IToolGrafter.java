package forestry.api.arboriculture;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IToolGrafter
{
  public abstract float getSaplingModifier(ItemStack paramItemStack, World paramWorld, EntityPlayer paramEntityPlayer, int paramInt1, int paramInt2, int paramInt3);
}