package forestry.api.arboriculture;

import forestry.api.genetics.IAllele;
import forestry.api.genetics.IChromosome;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.ISpeciesRoot;
import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public abstract interface ITreeRoot extends ISpeciesRoot
{
  public abstract boolean isMember(ItemStack paramItemStack);

  public abstract ITree getMember(ItemStack paramItemStack);

  public abstract ITree getMember(NBTTagCompound paramNBTTagCompound);

  public abstract ITreeGenome templateAsGenome(IAllele[] paramArrayOfIAllele);

  public abstract ITreeGenome templateAsGenome(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract IArboristTracker getBreedingTracker(World paramWorld, String paramString);

  public abstract void registerLeafTickHandler(ILeafTickHandler paramILeafTickHandler);

  public abstract Collection<ILeafTickHandler> getLeafTickHandlers();

  public abstract EnumGermlingType getType(ItemStack paramItemStack);

  public abstract ITree getTree(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract ITree getTree(World paramWorld, ITreeGenome paramITreeGenome);

  public abstract boolean plantSapling(World paramWorld, ITree paramITree, String paramString, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean setLeaves(World paramWorld, IIndividual paramIIndividual, String paramString, int paramInt1, int paramInt2, int paramInt3);

  public abstract IChromosome[] templateAsChromosomes(IAllele[] paramArrayOfIAllele);

  public abstract IChromosome[] templateAsChromosomes(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract boolean setFruitBlock(World paramWorld, IAlleleFruit paramIAlleleFruit, float paramFloat, short[] paramArrayOfShort, int paramInt1, int paramInt2, int paramInt3);

  public abstract ArrayList<ITreekeepingMode> getTreekeepingModes();

  public abstract ITreekeepingMode getTreekeepingMode(World paramWorld);

  public abstract ITreekeepingMode getTreekeepingMode(String paramString);

  public abstract void registerTreekeepingMode(ITreekeepingMode paramITreekeepingMode);

  public abstract void setTreekeepingMode(World paramWorld, String paramString);

  public abstract ArrayList<ITree> getIndividualTemplates();

  public abstract Collection<ITreeMutation> getMutations(boolean paramBoolean);
}