package forestry.api.arboriculture;

import forestry.api.genetics.IAllele;

public abstract interface IAlleleGrowth extends IAllele
{
  public abstract IGrowthProvider getProvider();
}