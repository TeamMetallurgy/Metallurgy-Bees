package forestry.api.arboriculture;

public class TreeManager
{
  public static int treeSpeciesCount = 0;

  @Deprecated
  public static ITreeRoot treeInterface;
}