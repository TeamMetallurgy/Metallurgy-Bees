package forestry.api.arboriculture;

import net.minecraft.world.World;

public abstract interface IGrowthProvider
{
  public abstract boolean canGrow(ITreeGenome paramITreeGenome, World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract EnumGrowthConditions getGrowthConditions(ITreeGenome paramITreeGenome, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract String getDescription();

  public abstract String[] getInfo();
}