package forestry.api.arboriculture;

import forestry.api.genetics.IAllele;

public abstract interface IAlleleFruit extends IAllele
{
  public abstract IFruitProvider getProvider();
}