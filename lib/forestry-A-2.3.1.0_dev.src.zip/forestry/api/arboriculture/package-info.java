package forestry.api.arboriculture;

import cpw.mods.fml.common.API;

@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|arboriculture")
abstract interface package-info
{
}