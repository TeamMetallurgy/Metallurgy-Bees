package forestry.api.arboriculture;

import forestry.api.genetics.IAllele;
import forestry.api.genetics.IGenome;
import forestry.api.genetics.IMutation;
import net.minecraft.world.World;

public abstract interface ITreeMutation extends IMutation
{
  public abstract ITreeRoot getRoot();

  public abstract float getChance(World paramWorld, int paramInt1, int paramInt2, int paramInt3, IAllele paramIAllele1, IAllele paramIAllele2, IGenome paramIGenome1, IGenome paramIGenome2);
}