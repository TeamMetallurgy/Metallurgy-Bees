package forestry.api.arboriculture;

public abstract interface ITreeModifier
{
  public abstract float getHeightModifier(ITreeGenome paramITreeGenome, float paramFloat);

  public abstract float getYieldModifier(ITreeGenome paramITreeGenome, float paramFloat);

  public abstract float getSappinessModifier(ITreeGenome paramITreeGenome, float paramFloat);

  public abstract float getMaturationModifier(ITreeGenome paramITreeGenome, float paramFloat);

  public abstract float getMutationModifier(ITreeGenome paramITreeGenome1, ITreeGenome paramITreeGenome2, float paramFloat);
}