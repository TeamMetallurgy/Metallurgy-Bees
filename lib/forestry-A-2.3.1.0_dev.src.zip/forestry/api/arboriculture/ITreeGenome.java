package forestry.api.arboriculture;

import forestry.api.genetics.IGenome;
import java.util.EnumSet;
import net.minecraftforge.common.EnumPlantType;

public abstract interface ITreeGenome extends IGenome
{
  public abstract IAlleleTreeSpecies getPrimary();

  public abstract IAlleleTreeSpecies getSecondary();

  public abstract IFruitProvider getFruitProvider();

  public abstract IGrowthProvider getGrowthProvider();

  public abstract float getHeight();

  public abstract float getFertility();

  public abstract float getYield();

  public abstract float getSappiness();

  public abstract EnumSet<EnumPlantType> getPlantTypes();

  public abstract int getMaturationTime();

  public abstract int getGirth();

  public abstract IAlleleLeafEffect getEffect();
}