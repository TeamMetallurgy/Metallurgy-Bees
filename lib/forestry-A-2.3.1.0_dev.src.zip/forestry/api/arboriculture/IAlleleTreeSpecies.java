package forestry.api.arboriculture;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.genetics.IAlleleSpecies;
import forestry.api.genetics.IFruitFamily;
import java.util.Collection;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.EnumPlantType;

public abstract interface IAlleleTreeSpecies extends IAlleleSpecies
{
  public abstract ITreeRoot getRoot();

  public abstract EnumPlantType getPlantType();

  public abstract Collection<IFruitFamily> getSuitableFruit();

  @Deprecated
  public abstract int getGirth();

  public abstract WorldGenerator getGenerator(ITree paramITree, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract Class<? extends WorldGenerator>[] getGeneratorClasses();

  public abstract int getLeafColour(ITree paramITree);

  public abstract short getLeafIconIndex(ITree paramITree, boolean paramBoolean);

  @SideOnly(Side.CLIENT)
  public abstract Icon getGermlingIcon(EnumGermlingType paramEnumGermlingType, int paramInt);

  @SideOnly(Side.CLIENT)
  public abstract int getGermlingColour(EnumGermlingType paramEnumGermlingType, int paramInt);

  public abstract ItemStack[] getLogStacks();
}