package forestry.api.arboriculture;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.genetics.IFruitFamily;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract interface IFruitProvider
{
  public abstract IFruitFamily getFamily();

  public abstract int getColour(ITreeGenome paramITreeGenome, IBlockAccess paramIBlockAccess, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract boolean markAsFruitLeaf(ITreeGenome paramITreeGenome, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract int getRipeningPeriod();

  public abstract ItemStack[] getProducts();

  public abstract ItemStack[] getSpecialty();

  public abstract ItemStack[] getFruits(ITreeGenome paramITreeGenome, World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract String getDescription();

  public abstract short getIconIndex(ITreeGenome paramITreeGenome, IBlockAccess paramIBlockAccess, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);

  public abstract boolean requiresFruitBlocks();

  public abstract boolean trySpawnFruitBlock(ITreeGenome paramITreeGenome, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  @SideOnly(Side.CLIENT)
  public abstract void registerIcons(IconRegister paramIconRegister);
}