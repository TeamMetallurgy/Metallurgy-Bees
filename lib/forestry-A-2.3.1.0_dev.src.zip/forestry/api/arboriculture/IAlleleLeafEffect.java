package forestry.api.arboriculture;

import forestry.api.genetics.IAlleleEffect;
import forestry.api.genetics.IEffectData;
import net.minecraft.world.World;

public abstract interface IAlleleLeafEffect extends IAlleleEffect
{
  public abstract IEffectData doEffect(ITreeGenome paramITreeGenome, IEffectData paramIEffectData, World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}