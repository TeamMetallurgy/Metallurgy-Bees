package forestry.api.arboriculture;

import java.util.ArrayList;

public abstract interface ITreekeepingMode extends ITreeModifier
{
  public abstract String getName();

  public abstract ArrayList<String> getDescription();
}