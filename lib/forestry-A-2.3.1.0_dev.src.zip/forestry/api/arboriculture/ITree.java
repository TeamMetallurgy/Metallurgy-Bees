package forestry.api.arboriculture;

import forestry.api.genetics.IEffectData;
import forestry.api.genetics.IIndividual;
import java.util.EnumSet;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.EnumPlantType;

public abstract interface ITree extends IIndividual
{
  public abstract void mate(ITree paramITree);

  public abstract IEffectData[] doEffect(IEffectData[] paramArrayOfIEffectData, World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract IEffectData[] doFX(IEffectData[] paramArrayOfIEffectData, World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract ITreeGenome getGenome();

  public abstract ITreeGenome getMate();

  public abstract EnumSet<EnumPlantType> getPlantTypes();

  public abstract ITree[] getSaplings(World paramWorld, int paramInt1, int paramInt2, int paramInt3, float paramFloat);

  public abstract ItemStack[] getProduceList();

  public abstract ItemStack[] getSpecialtyList();

  public abstract ItemStack[] produceStacks(World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract boolean canStay(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean canGrow(World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract int getRequiredMaturity();

  public abstract int getResilience();

  public abstract int getGirth(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract EnumGrowthConditions getGrowthCondition(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract WorldGenerator getTreeGenerator(World paramWorld, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);

  public abstract ITree copy();

  public abstract boolean isPureBred(EnumTreeChromosome paramEnumTreeChromosome);

  public abstract boolean canBearFruit();
}