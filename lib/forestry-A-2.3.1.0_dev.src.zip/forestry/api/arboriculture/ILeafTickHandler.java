package forestry.api.arboriculture;

import net.minecraft.world.World;

public abstract interface ILeafTickHandler
{
  public abstract boolean onRandomLeafTick(ITree paramITree, World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
}