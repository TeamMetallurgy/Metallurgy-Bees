package forestry.api.arboriculture;

import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleArea;
import forestry.api.genetics.IAlleleFloat;
import forestry.api.genetics.IAlleleInteger;
import forestry.api.genetics.IAllelePlantType;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IChromosomeType;
import forestry.api.genetics.ISpeciesRoot;

public enum EnumTreeChromosome
  implements IChromosomeType
{
  SPECIES(IAlleleTreeSpecies.class), 

  GROWTH(IAlleleGrowth.class), 

  HEIGHT(IAlleleFloat.class), 

  FERTILITY(IAlleleFloat.class), 

  FRUITS(IAlleleFruit.class), 

  YIELD(IAlleleFloat.class), 

  PLANT(IAllelePlantType.class), 

  SAPPINESS(IAlleleFloat.class), 

  TERRITORY(IAlleleArea.class), 

  EFFECT(IAlleleLeafEffect.class), 

  MATURATION(IAlleleInteger.class), 

  GIRTH(IAlleleInteger.class);

  Class<? extends IAllele> clss;

  private EnumTreeChromosome(Class<? extends IAllele> clss)
  {
    this.clss = clss;
  }

  public Class<? extends IAllele> getAlleleClass()
  {
    return clss;
  }

  public String getName()
  {
    return toString().toLowerCase();
  }

  public ISpeciesRoot getSpeciesRoot()
  {
    return AlleleManager.alleleRegistry.getSpeciesRoot("rootTrees");
  }
}