package forestry.api.apiculture;

import forestry.api.core.ITileStructure;

public abstract interface IAlvearyComponent extends ITileStructure
{
  public abstract void registerBeeModifier(IBeeModifier paramIBeeModifier);

  public abstract void removeBeeModifier(IBeeModifier paramIBeeModifier);

  public abstract void registerBeeListener(IBeeListener paramIBeeListener);

  public abstract void removeBeeListener(IBeeListener paramIBeeListener);

  public abstract void addTemperatureChange(float paramFloat1, float paramFloat2, float paramFloat3);

  public abstract void addHumidityChange(float paramFloat1, float paramFloat2, float paramFloat3);

  public abstract boolean hasFunction();
}