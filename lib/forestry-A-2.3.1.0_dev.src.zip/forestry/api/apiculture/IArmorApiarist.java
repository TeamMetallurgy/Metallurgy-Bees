package forestry.api.apiculture;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public abstract interface IArmorApiarist
{
  public abstract boolean protectPlayer(EntityPlayer paramEntityPlayer, ItemStack paramItemStack, String paramString, boolean paramBoolean);
}