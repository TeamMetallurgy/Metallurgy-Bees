package forestry.api.apiculture;

public abstract interface IBeeModifier
{
  public abstract float getTerritoryModifier(IBeeGenome paramIBeeGenome, float paramFloat);

  public abstract float getMutationModifier(IBeeGenome paramIBeeGenome1, IBeeGenome paramIBeeGenome2, float paramFloat);

  public abstract float getLifespanModifier(IBeeGenome paramIBeeGenome1, IBeeGenome paramIBeeGenome2, float paramFloat);

  public abstract float getProductionModifier(IBeeGenome paramIBeeGenome, float paramFloat);

  public abstract float getFloweringModifier(IBeeGenome paramIBeeGenome, float paramFloat);

  public abstract float getGeneticDecay(IBeeGenome paramIBeeGenome, float paramFloat);

  public abstract boolean isSealed();

  public abstract boolean isSelfLighted();

  public abstract boolean isSunlightSimulated();

  public abstract boolean isHellish();
}