package forestry.api.apiculture;

import forestry.api.genetics.IEffectData;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IIndividualLiving;
import java.util.ArrayList;
import net.minecraft.item.ItemStack;

public abstract interface IBee extends IIndividualLiving
{
  public abstract IBeeGenome getGenome();

  public abstract IBeeGenome getMate();

  public abstract boolean isNatural();

  public abstract int getGeneration();

  public abstract void setIsNatural(boolean paramBoolean);

  public abstract boolean isIrregularMating();

  public abstract IEffectData[] doEffect(IEffectData[] paramArrayOfIEffectData, IBeeHousing paramIBeeHousing);

  public abstract IEffectData[] doFX(IEffectData[] paramArrayOfIEffectData, IBeeHousing paramIBeeHousing);

  public abstract boolean canSpawn();

  public abstract int isWorking(IBeeHousing paramIBeeHousing);

  public abstract boolean hasFlower(IBeeHousing paramIBeeHousing);

  public abstract ArrayList<Integer> getSuitableBiomeIds();

  public abstract ItemStack[] getProduceList();

  public abstract ItemStack[] getSpecialtyList();

  public abstract ItemStack[] produceStacks(IBeeHousing paramIBeeHousing);

  public abstract IBee spawnPrincess(IBeeHousing paramIBeeHousing);

  public abstract IBee[] spawnDrones(IBeeHousing paramIBeeHousing);

  public abstract void plantFlowerRandom(IBeeHousing paramIBeeHousing);

  public abstract IIndividual retrievePollen(IBeeHousing paramIBeeHousing);

  public abstract boolean pollinateRandom(IBeeHousing paramIBeeHousing, IIndividual paramIIndividual);
}