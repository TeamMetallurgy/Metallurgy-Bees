package forestry.api.apiculture;

import forestry.api.core.INBTTagable;
import forestry.api.genetics.IEffectData;

public abstract interface IBeekeepingLogic extends INBTTagable
{
  public abstract int getBreedingTime();

  public abstract int getTotalBreedingTime();

  public abstract IBee getQueen();

  public abstract IBeeHousing getHousing();

  public abstract IEffectData[] getEffectData();

  public abstract void update();
}