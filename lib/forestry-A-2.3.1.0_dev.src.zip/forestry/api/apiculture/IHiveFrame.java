package forestry.api.apiculture;

import net.minecraft.item.ItemStack;

public abstract interface IHiveFrame extends IBeeModifier
{
  public abstract ItemStack frameUsed(IBeeHousing paramIBeeHousing, ItemStack paramItemStack, IBee paramIBee, int paramInt);
}