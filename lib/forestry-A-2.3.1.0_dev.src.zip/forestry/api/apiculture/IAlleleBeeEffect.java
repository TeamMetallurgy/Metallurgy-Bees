package forestry.api.apiculture;

import forestry.api.genetics.IAlleleEffect;
import forestry.api.genetics.IEffectData;

public abstract interface IAlleleBeeEffect extends IAlleleEffect
{
  public abstract IEffectData doEffect(IBeeGenome paramIBeeGenome, IEffectData paramIEffectData, IBeeHousing paramIBeeHousing);

  public abstract IEffectData doFX(IBeeGenome paramIBeeGenome, IEffectData paramIEffectData, IBeeHousing paramIBeeHousing);
}