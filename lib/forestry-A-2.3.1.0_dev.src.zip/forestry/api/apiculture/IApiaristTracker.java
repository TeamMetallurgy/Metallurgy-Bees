package forestry.api.apiculture;

import forestry.api.genetics.IBreedingTracker;
import forestry.api.genetics.IIndividual;

public abstract interface IApiaristTracker extends IBreedingTracker
{
  public abstract void registerQueen(IIndividual paramIIndividual);

  public abstract int getQueenCount();

  public abstract void registerPrincess(IIndividual paramIIndividual);

  public abstract int getPrincessCount();

  public abstract void registerDrone(IIndividual paramIIndividual);

  public abstract int getDroneCount();
}