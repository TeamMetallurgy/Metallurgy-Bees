package forestry.api.apiculture;

import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleArea;
import forestry.api.genetics.IAlleleBoolean;
import forestry.api.genetics.IAlleleFloat;
import forestry.api.genetics.IAlleleFlowers;
import forestry.api.genetics.IAlleleInteger;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IAlleleTolerance;
import forestry.api.genetics.IChromosomeType;
import forestry.api.genetics.ISpeciesRoot;

public enum EnumBeeChromosome
  implements IChromosomeType
{
  SPECIES(IAlleleBeeSpecies.class), 

  SPEED(IAlleleFloat.class), 

  LIFESPAN(IAlleleInteger.class), 

  FERTILITY(IAlleleInteger.class), 

  TEMPERATURE_TOLERANCE(IAlleleTolerance.class), 

  NOCTURNAL(IAlleleBoolean.class), 

  HUMIDITY(IAllele.class), 

  HUMIDITY_TOLERANCE(IAlleleTolerance.class), 

  TOLERANT_FLYER(IAlleleBoolean.class), 

  CAVE_DWELLING(IAlleleBoolean.class), 

  FLOWER_PROVIDER(IAlleleFlowers.class), 

  FLOWERING(IAlleleInteger.class), 

  TERRITORY(IAlleleArea.class), 

  EFFECT(IAlleleBeeEffect.class);

  Class<? extends IAllele> clss;

  private EnumBeeChromosome(Class<? extends IAllele> clss) {
    this.clss = clss;
  }

  public Class<? extends IAllele> getAlleleClass()
  {
    return clss;
  }

  public String getName()
  {
    return toString().toLowerCase();
  }

  public ISpeciesRoot getSpeciesRoot()
  {
    return AlleleManager.alleleRegistry.getSpeciesRoot("rootBees");
  }
}