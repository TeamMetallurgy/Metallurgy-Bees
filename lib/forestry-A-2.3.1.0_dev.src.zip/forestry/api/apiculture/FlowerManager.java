package forestry.api.apiculture;

import java.util.ArrayList;
import net.minecraft.item.ItemStack;

public class FlowerManager
{
  public static ArrayList<ItemStack> plainFlowers = new ArrayList();
}