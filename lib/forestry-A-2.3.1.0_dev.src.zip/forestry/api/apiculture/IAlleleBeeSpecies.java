package forestry.api.apiculture;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.genetics.IAlleleSpecies;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;

public abstract interface IAlleleBeeSpecies extends IAlleleSpecies
{
  public abstract IBeeRoot getRoot();

  public abstract boolean isNocturnal();

  public abstract Map<ItemStack, Integer> getProducts();

  public abstract Map<ItemStack, Integer> getSpecialty();

  public abstract boolean isJubilant(IBeeGenome paramIBeeGenome, IBeeHousing paramIBeeHousing);

  @SideOnly(Side.CLIENT)
  public abstract Icon getIcon(EnumBeeType paramEnumBeeType, int paramInt);

  public abstract String getEntityTexture();
}