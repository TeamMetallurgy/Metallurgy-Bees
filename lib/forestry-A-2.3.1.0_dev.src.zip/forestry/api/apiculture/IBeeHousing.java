package forestry.api.apiculture;

import forestry.api.genetics.IHousing;
import net.minecraft.item.ItemStack;

public abstract interface IBeeHousing extends IBeeModifier, IBeeListener, IHousing
{
  public abstract ItemStack getQueen();

  public abstract ItemStack getDrone();

  public abstract void setQueen(ItemStack paramItemStack);

  public abstract void setDrone(ItemStack paramItemStack);

  public abstract boolean canBreed();
}