package forestry.api.apiculture;

import java.util.Collection;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract interface IHiveDrop
{
  public abstract ItemStack getPrincess(World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract Collection<ItemStack> getDrones(World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract Collection<ItemStack> getAdditional(World paramWorld, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract int getChance(World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}