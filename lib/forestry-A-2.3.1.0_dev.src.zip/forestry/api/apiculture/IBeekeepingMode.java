package forestry.api.apiculture;

import java.util.ArrayList;
import net.minecraft.world.World;

public abstract interface IBeekeepingMode extends IBeeModifier
{
  public abstract String getName();

  public abstract ArrayList<String> getDescription();

  public abstract float getWearModifier();

  public abstract int getFinalFertility(IBee paramIBee, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean isFatigued(IBee paramIBee, IBeeHousing paramIBeeHousing);

  public abstract boolean isOverworked(IBee paramIBee, IBeeHousing paramIBeeHousing);

  public abstract boolean isDegenerating(IBee paramIBee1, IBee paramIBee2, IBeeHousing paramIBeeHousing);

  public abstract boolean isNaturalOffspring(IBee paramIBee);

  public abstract boolean mayMultiplyPrincess(IBee paramIBee);
}