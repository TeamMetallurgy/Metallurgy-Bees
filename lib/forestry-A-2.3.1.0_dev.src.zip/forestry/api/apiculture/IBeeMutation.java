package forestry.api.apiculture;

import forestry.api.genetics.IAllele;
import forestry.api.genetics.IGenome;
import forestry.api.genetics.IMutation;

public abstract interface IBeeMutation extends IMutation
{
  public abstract IBeeRoot getRoot();

  public abstract float getChance(IBeeHousing paramIBeeHousing, IAllele paramIAllele1, IAllele paramIAllele2, IGenome paramIGenome1, IGenome paramIGenome2);
}