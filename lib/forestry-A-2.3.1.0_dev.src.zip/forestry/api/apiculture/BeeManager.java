package forestry.api.apiculture;

import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.item.ItemStack;

public class BeeManager
{

  @Deprecated
  public static IBeeRoot beeInterface;
  public static ArrayList<IHiveDrop>[] hiveDrops;
  public static ArrayList<IBeeGenome>[] villageBees;
  public static HashMap<ItemStack, Integer> inducers = new HashMap();
}