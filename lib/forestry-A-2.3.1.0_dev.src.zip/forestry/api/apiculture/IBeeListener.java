package forestry.api.apiculture;

import forestry.api.genetics.IIndividual;
import net.minecraft.item.ItemStack;

public abstract interface IBeeListener
{
  public abstract void onQueenChange(ItemStack paramItemStack);

  public abstract void wearOutEquipment(int paramInt);

  public abstract void onQueenDeath(IBee paramIBee);

  public abstract void onPostQueenDeath(IBee paramIBee);

  public abstract boolean onPollenRetrieved(IBee paramIBee, IIndividual paramIIndividual, boolean paramBoolean);

  public abstract boolean onEggLaid(IBee paramIBee);
}