package forestry.api.apiculture;

import forestry.api.core.IStructureLogic;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.ISpeciesRoot;
import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public abstract interface IBeeRoot extends ISpeciesRoot
{
  public abstract boolean isMember(ItemStack paramItemStack);

  public abstract IBee getMember(ItemStack paramItemStack);

  public abstract IBee getMember(NBTTagCompound paramNBTTagCompound);

  public abstract IBee templateAsIndividual(IAllele[] paramArrayOfIAllele);

  public abstract IBee templateAsIndividual(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract IBeeGenome templateAsGenome(IAllele[] paramArrayOfIAllele);

  public abstract IBeeGenome templateAsGenome(IAllele[] paramArrayOfIAllele1, IAllele[] paramArrayOfIAllele2);

  public abstract IApiaristTracker getBreedingTracker(World paramWorld, String paramString);

  public abstract EnumBeeType getType(ItemStack paramItemStack);

  public abstract boolean isDrone(ItemStack paramItemStack);

  public abstract boolean isMated(ItemStack paramItemStack);

  public abstract IBee getBee(World paramWorld, IBeeGenome paramIBeeGenome);

  public abstract IBee getBee(World paramWorld, IBeeGenome paramIBeeGenome, IBee paramIBee);

  public abstract ArrayList<IBee> getIndividualTemplates();

  public abstract Collection<IBeeMutation> getMutations(boolean paramBoolean);

  public abstract void resetBeekeepingMode();

  public abstract ArrayList<IBeekeepingMode> getBeekeepingModes();

  public abstract IBeekeepingMode getBeekeepingMode(World paramWorld);

  public abstract IBeekeepingMode getBeekeepingMode(String paramString);

  public abstract void registerBeekeepingMode(IBeekeepingMode paramIBeekeepingMode);

  public abstract void setBeekeepingMode(World paramWorld, String paramString);

  public abstract IBeekeepingLogic createBeekeepingLogic(IBeeHousing paramIBeeHousing);

  public abstract IStructureLogic createAlvearyStructureLogic(IAlvearyComponent paramIAlvearyComponent);
}