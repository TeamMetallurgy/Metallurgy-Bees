package forestry.api.apiculture;

import forestry.api.genetics.EnumTolerance;
import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.IGenome;

public abstract interface IBeeGenome extends IGenome
{
  public abstract IAlleleBeeSpecies getPrimary();

  public abstract IAlleleBeeSpecies getSecondary();

  public abstract float getSpeed();

  public abstract int getLifespan();

  public abstract int getFertility();

  public abstract EnumTolerance getToleranceTemp();

  public abstract EnumTolerance getToleranceHumid();

  public abstract boolean getNocturnal();

  public abstract boolean getTolerantFlyer();

  public abstract boolean getCaveDwelling();

  public abstract IFlowerProvider getFlowerProvider();

  public abstract int getFlowering();

  public abstract int[] getTerritory();

  public abstract IAlleleBeeEffect getEffect();
}