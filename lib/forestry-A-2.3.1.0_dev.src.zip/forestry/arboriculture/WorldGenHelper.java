package forestry.arboriculture;

import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.genetics.IIndividual;
import forestry.api.world.IWorldGenInterface;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import net.minecraft.world.gen.feature.WorldGenerator;

public class WorldGenHelper
  implements IWorldGenInterface
{
  public Class<? extends WorldGenerator>[] getTreeGenerators(String ident)
  {
    ArrayList generators = new ArrayList();
    for (IIndividual tree : PluginArboriculture.treeInterface.getIndividualTemplates()) {
      if (tree.getIdent().equals(ident))
        for (Class generator : ((ITree)tree).getGenome().getPrimary().getGeneratorClasses())
          generators.add(generator);
    }
    return (Class[])generators.toArray(new Class[0]);
  }
}