package forestry.arboriculture;

import forestry.api.genetics.IFruitBearer;
import forestry.arboriculture.gadgets.TileFruitPod;
import forestry.arboriculture.gadgets.TileSapling;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.event.Event.Result;
import net.minecraftforge.event.ForgeSubscribe;
import net.minecraftforge.event.entity.player.BonemealEvent;

public class EventHandlerArboriculture
{
  @ForgeSubscribe
  public void handleBonemeal(BonemealEvent event)
  {
    if (!Proxies.common.isSimulating(event.world)) {
      return;
    }
    TileEntity tile = event.world.getBlockTileEntity(event.X, event.Y, event.Z);
    if ((tile instanceof TileSapling)) {
      int result = ((TileSapling)tile).tryGrow(true);
      if ((result == 1) || (result == 2))
        event.setResult(Event.Result.ALLOW);
    } else if ((tile instanceof IFruitBearer)) {
      IFruitBearer bearer = (IFruitBearer)tile;
      if (bearer.getRipeness() <= 1.0F) {
        bearer.addRipeness(1.0F);
        event.setResult(Event.Result.ALLOW);
      }
    } else if (((tile instanceof TileFruitPod)) && 
      (((TileFruitPod)tile).canMature())) {
      ((TileFruitPod)tile).mature();
      event.setResult(Event.Result.ALLOW);
    }
  }
}