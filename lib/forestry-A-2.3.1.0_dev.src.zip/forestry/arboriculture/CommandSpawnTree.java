package forestry.arboriculture;

import forestry.api.arboriculture.ITreeRoot;
import forestry.api.world.ITreeGenData;
import forestry.arboriculture.genetics.TreeTemplates;
import forestry.arboriculture.worldgen.WorldGenBalsa;
import forestry.core.utils.CommandMC;
import forestry.plugins.PluginArboriculture;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class CommandSpawnTree extends CommandMC
{
  public String getCommandName()
  {
    return "spawntree";
  }

  public String getCommandUsage(ICommandSender sender) {
    return "/" + getCommandName() + " <player-name> <species-name>";
  }

  public void processCommand(ICommandSender sender, String[] arguments)
  {
    EntityPlayer player = getPlayerFromName(sender.getCommandSenderName());

    int x = (int)player.posX;
    int y = (int)player.posY;
    int z = (int)player.posZ;

    WorldGenerator gen = new WorldGenBalsa((ITreeGenData)PluginArboriculture.treeInterface.getTree(player.worldObj, TreeTemplates.templateAsGenome(PluginArboriculture.treeInterface.getTemplate("treeBalsa"))));

    gen.generate(player.worldObj, player.worldObj.rand, x, y, z);
  }
}