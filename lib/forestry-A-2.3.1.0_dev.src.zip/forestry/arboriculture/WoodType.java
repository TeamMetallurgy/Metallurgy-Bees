package forestry.arboriculture;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.core.render.TextureManager;
import java.util.Locale;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.Icon;

public enum WoodType
{
  LARCH, TEAK, ACACIA, LIME, CHESTNUT, WENGE, BAOBAB, SEQUOIA(4.0F), KAPOK, EBONY, MAHOGANY, BALSA(1.0F), WILLOW, WALNUT, GREENHEART(7.5F), CHERRY, MAHOE, POPLAR, PALM, PAPAYA, PINE(3.0F), 
  PLUM, MAPLE, CITRUS, GIGANTEUM(2.0F, false);

  public static final WoodType[] VALUES = values();
  private final float hardness;
  public final boolean hasPlank;

  @SideOnly(Side.CLIENT)
  private static Icon[][] icons;

  private WoodType() { this(2.0F, true); }

  private WoodType(float hardness)
  {
    this(hardness, true);
  }

  private WoodType(float hardness, boolean hasPlank) {
    this.hardness = hardness;
    this.hasPlank = hasPlank;
  }

  @SideOnly(Side.CLIENT)
  public static void registerIcons(IconRegister register)
  {
    icons = new Icon[3][VALUES.length];
    for (int i = 0; i < VALUES.length; i++)
      icons[0][i] = TextureManager.getInstance().registerTex(register, "wood/planks." + VALUES[i].toString().toLowerCase(Locale.ENGLISH));
    for (int i = 0; i < VALUES.length; i++)
      icons[1][i] = TextureManager.getInstance().registerTex(register, "wood/bark." + VALUES[i].toString().toLowerCase(Locale.ENGLISH));
    for (int i = 0; i < VALUES.length; i++)
      icons[2][i] = TextureManager.getInstance().registerTex(register, "wood/heart." + VALUES[i].toString().toLowerCase(Locale.ENGLISH));
  }

  @SideOnly(Side.CLIENT)
  public Icon getPlankIcon() {
    return icons[0][ordinal()];
  }

  @SideOnly(Side.CLIENT)
  public Icon getBarkIcon() {
    return icons[1][ordinal()];
  }

  @SideOnly(Side.CLIENT)
  public Icon getHeartIcon() {
    return icons[2][ordinal()];
  }

  public float getHardness() {
    return hardness;
  }

  public void saveToCompound(NBTTagCompound compound) {
    compound.setInteger("WoodType", ordinal());
  }

  public static WoodType getFromCompound(NBTTagCompound compound)
  {
    if (compound != null) {
      int typeOrdinal = compound.getInteger("WoodType");
      if (typeOrdinal < VALUES.length) {
        return VALUES[typeOrdinal];
      }
    }
    return LARCH;
  }
}