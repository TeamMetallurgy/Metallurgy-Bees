package forestry.arboriculture.genetics;

import forestry.api.arboriculture.EnumGrowthConditions;
import forestry.api.arboriculture.ITreeGenome;
import java.util.EnumSet;
import net.minecraft.world.World;

public class GrowthProviderTropical extends GrowthProvider
{
  public EnumGrowthConditions getGrowthConditions(ITreeGenome genome, World world, int xPos, int yPos, int zPos)
  {
    EnumGrowthConditions light = getConditionFromLight(world, xPos, yPos, zPos);
    EnumGrowthConditions moisture = getConditionsFromRainfall(world, xPos, yPos, zPos, 0.9F, 2.0F);
    EnumGrowthConditions temperature = getConditionsFromTemperature(world, xPos, yPos, zPos, 1.2F, 1.9F);

    EnumSet conditions = EnumSet.of(light, moisture, temperature);

    EnumGrowthConditions result = EnumGrowthConditions.HOSTILE;
    for (EnumGrowthConditions cond : conditions) {
      if (cond == EnumGrowthConditions.HOSTILE) {
        return EnumGrowthConditions.HOSTILE;
      }
      if (cond.ordinal() > result.ordinal()) {
        result = cond;
      }
    }
    return result;
  }

  public String getDescription()
  {
    return "Tropical";
  }
}