package forestry.arboriculture.genetics;

import forestry.api.arboriculture.IAlleleGrowth;
import forestry.api.arboriculture.IGrowthProvider;
import forestry.core.genetics.Allele;

public class AlleleGrowth extends Allele
  implements IAlleleGrowth
{
  IGrowthProvider provider;

  public AlleleGrowth(String uid, IGrowthProvider provider)
  {
    this(uid, provider, false);
  }

  public AlleleGrowth(String uid, IGrowthProvider provider, boolean isDominant) {
    super(uid, isDominant);
    this.provider = provider;
  }

  public IGrowthProvider getProvider()
  {
    return provider;
  }
}