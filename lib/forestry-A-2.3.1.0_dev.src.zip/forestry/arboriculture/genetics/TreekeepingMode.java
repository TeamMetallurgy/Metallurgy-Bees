package forestry.arboriculture.genetics;

import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreekeepingMode;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class TreekeepingMode
  implements ITreekeepingMode
{
  public static ITreekeepingMode easy = new TreekeepingMode("EASY", 1.4F, 1.3F, 1.2F, 1.2F);
  public static ITreekeepingMode normal = new TreekeepingMode("NORMAL", 1.0F, 1.0F, 1.0F, 1.0F);
  public static ITreekeepingMode hard = new TreekeepingMode("HARD", 0.9F, 0.9F, 0.9F, 0.9F);
  public static ITreekeepingMode hardcore = new TreekeepingMode("HARDCORE", 0.7F, 0.7F, 0.5F, 0.5F);
  public static ITreekeepingMode insane = new TreekeepingMode("INSANE", 0.5F, 0.5F, 0.2F, 0.1F);
  final Random rand;
  final String name;
  private float yieldModifier;
  private float sappinessModifier;
  private float maturationModifier;
  private float mutationModifier;

  public TreekeepingMode(String name, float yieldModifier, float sappinessModifier, float maturationModifier, float mutationModifier)
  {
    rand = new Random();
    this.name = name;
    this.yieldModifier = yieldModifier;
    this.sappinessModifier = sappinessModifier;
    this.maturationModifier = maturationModifier;
    this.mutationModifier = mutationModifier;
  }

  public String getName()
  {
    return name;
  }

  public ArrayList<String> getDescription()
  {
    ArrayList ret = new ArrayList();
    ret.add("treemode." + name.toLowerCase(Locale.ENGLISH) + ".desc");
    return ret;
  }

  public float getHeightModifier(ITreeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getYieldModifier(ITreeGenome genome, float currentModifier)
  {
    return yieldModifier;
  }

  public float getSappinessModifier(ITreeGenome genome, float currentModifier)
  {
    return sappinessModifier;
  }

  public float getMaturationModifier(ITreeGenome genome, float currentModifier)
  {
    return maturationModifier;
  }

  public float getMutationModifier(ITreeGenome genome, ITreeGenome mate, float currentModifier)
  {
    return mutationModifier;
  }
}