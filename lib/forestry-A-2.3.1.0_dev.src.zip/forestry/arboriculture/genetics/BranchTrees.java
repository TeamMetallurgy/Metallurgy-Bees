package forestry.arboriculture.genetics;

import forestry.core.genetics.Branch;

public class BranchTrees extends Branch
{
  public BranchTrees(String uid, String scientific)
  {
    super("trees." + uid, scientific);
  }
}