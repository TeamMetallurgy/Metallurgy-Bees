package forestry.arboriculture.genetics;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.EnumBeeChromosome;
import forestry.api.arboriculture.EnumGermlingType;
import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.core.IIconProvider;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IClassification;
import forestry.api.genetics.IFruitFamily;
import forestry.api.genetics.IMutation;
import forestry.api.world.ITreeGenData;
import forestry.arboriculture.worldgen.WorldGenArboriculture;
import forestry.arboriculture.worldgen.WorldGenBalsa;
import forestry.core.config.ForestryItem;
import forestry.core.genetics.AlleleSpecies;
import forestry.core.render.TextureManager;
import forestry.core.utils.Utils;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.EnumPlantType;

public class AlleleTreeSpecies extends AlleleSpecies
  implements IAlleleTreeSpecies, IIconProvider
{
  private static HashMap<String, LeafType> leafTypes = new HashMap();
  private ITreeRoot root;
  private Class<? extends WorldGenArboriculture> generatorClass = WorldGenBalsa.class;
  private int primaryColour;
  private int secondaryColour;
  private LeafType leafType;
  private int girth = 1;
  private EnumPlantType nativeType = EnumPlantType.Plains;
  private ArrayList<IFruitFamily> fruits = new ArrayList();
  private ItemStack wood;
  private int vanillaMap = -1;

  @SideOnly(Side.CLIENT)
  Icon icon;

  public AlleleTreeSpecies(String uid, boolean isDominant, String name, IClassification branch, String binomial, int primaryColor, int secondaryColor)
  {
    super(uid, isDominant, name, branch, binomial);

    root = ((ITreeRoot)AlleleManager.alleleRegistry.getSpeciesRoot("rootTrees"));
    primaryColour = primaryColor;
    secondaryColour = secondaryColor;
    leafType = ((LeafType)leafTypes.get("deciduous"));
  }

  public AlleleTreeSpecies(String uid, boolean isDominant, String name, IClassification branch, String binomial, int primaryColor, Class<? extends WorldGenArboriculture> generator, ItemStack wood)
  {
    this(uid, isDominant, name, branch, binomial, primaryColor, Utils.multiplyRGBComponents(primaryColor, 1.35F), generator, wood);
  }

  public AlleleTreeSpecies(String uid, boolean isDominant, String name, IClassification branch, String binomial, int primaryColor, int secondaryColor, Class<? extends WorldGenArboriculture> generator, ItemStack wood)
  {
    super(uid, isDominant, name, branch, binomial);

    root = ((ITreeRoot)AlleleManager.alleleRegistry.getSpeciesRoot("rootTrees"));
    generatorClass = generator;
    primaryColour = primaryColor;
    secondaryColour = secondaryColor;
    leafType = ((LeafType)leafTypes.get("deciduous"));
    this.wood = wood;
  }

  public ITreeRoot getRoot()
  {
    return root;
  }

  public AlleleTreeSpecies setPlantType(EnumPlantType type) {
    nativeType = type;
    return this;
  }

  public AlleleTreeSpecies setGirth(int girth) {
    this.girth = girth;
    return this;
  }

  public AlleleTreeSpecies addFruitFamily(IFruitFamily family) {
    fruits.add(family);
    return this;
  }

  public AlleleTreeSpecies setLeafIndices(String ident) {
    leafType = ((LeafType)leafTypes.get(ident));
    return this;
  }

  public AlleleTreeSpecies setVanillaMap(int vanillaMeta) {
    vanillaMap = vanillaMeta;
    return this;
  }

  public int getComplexity()
  {
    return 1 + getGeneticAdvancement(this, new ArrayList());
  }

  private int getGeneticAdvancement(IAllele species, ArrayList<IAllele> exclude)
  {
    int own = 1;
    int highest = 0;
    exclude.add(species);

    for (IMutation mutation : getRoot().getPaths(species, EnumBeeChromosome.SPECIES.ordinal())) {
      if (!exclude.contains(mutation.getAllele0())) {
        int otherAdvance = getGeneticAdvancement(mutation.getAllele0(), exclude);
        if (otherAdvance > highest)
          highest = otherAdvance;
      }
      if (!exclude.contains(mutation.getAllele1())) {
        int otherAdvance = getGeneticAdvancement(mutation.getAllele1(), exclude);
        if (otherAdvance > highest) {
          highest = otherAdvance;
        }
      }
    }
    return own + (highest < 0 ? 0 : highest);
  }

  public EnumPlantType getPlantType()
  {
    return nativeType;
  }

  public ArrayList<IFruitFamily> getSuitableFruit()
  {
    return fruits;
  }

  public int getGirth()
  {
    return girth;
  }

  public WorldGenerator getGenerator(ITree tree, World world, int x, int y, int z)
  {
    try {
      return (WorldGenerator)generatorClass.getConstructor(new Class[] { ITreeGenData.class }).newInstance(new Object[] { tree }); } catch (Exception ex) {
    }
    throw new RuntimeException("Failed to instantiate generator of class " + generatorClass.getName());
  }

  public Class<? extends WorldGenerator>[] getGeneratorClasses()
  {
    return new Class[] { generatorClass };
  }

  public short getLeafIconIndex(ITree tree, boolean fancy)
  {
    if (!fancy) {
      return leafType.plainUID;
    }
    if (tree.getMate() != null) {
      return leafType.changedUID;
    }
    return leafType.fancyUID;
  }

  public AlleleTreeSpecies setGenerator(Class<? extends WorldGenArboriculture> generatorClass) {
    this.generatorClass = generatorClass;
    return this;
  }

  public int getLeafColour(ITree tree)
  {
    return primaryColour;
  }

  public int getIconColour(int renderPass)
  {
    if (renderPass == 0)
      return primaryColour;
    return 16777215;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    if (vanillaMap < 0)
      icon = TextureManager.getInstance().registerTex(register, "germlings/sapling." + uid);
    else
      icon = Block.sapling.getIcon(0, vanillaMap);
    TextureManager.getInstance().registerTexUID(register, leafType.plainUID, "leaves/" + leafType.ident + ".plain");
    TextureManager.getInstance().registerTexUID(register, leafType.changedUID, "leaves/" + leafType.ident + ".changed");
    TextureManager.getInstance().registerTexUID(register, leafType.fancyUID, "leaves/" + leafType.ident + ".fancy");
  }

  @SideOnly(Side.CLIENT)
  public Icon getGermlingIcon(EnumGermlingType type, int renderPass)
  {
    if (type == EnumGermlingType.POLLEN) {
      return ForestryItem.pollen.item().getIconFromDamageForRenderPass(0, renderPass);
    }
    return icon;
  }

  @SideOnly(Side.CLIENT)
  public int getGermlingColour(EnumGermlingType type, int renderPass)
  {
    if (type == EnumGermlingType.SAPLING)
      return 16777215;
    return getLeafColour(null);
  }

  @SideOnly(Side.CLIENT)
  public IIconProvider getIconProvider()
  {
    return this;
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(short texUID)
  {
    return TextureManager.getInstance().getIcon(texUID);
  }

  public ItemStack[] getLogStacks()
  {
    return new ItemStack[] { wood };
  }

  static
  {
    leafTypes.put("deciduous", new LeafType("deciduous", (short)10, (short)11, (short)12));
    leafTypes.put("conifers", new LeafType("conifers", (short)15, (short)16, (short)17));
    leafTypes.put("jungle", new LeafType("jungle", (short)20, (short)21, (short)22));
    leafTypes.put("willow", new LeafType("willow", (short)25, (short)26, (short)27));
    leafTypes.put("maple", new LeafType("maple", (short)30, (short)31, (short)32));
    leafTypes.put("palm", new LeafType("palm", (short)35, (short)36, (short)37));
  }

  private static class LeafType
  {
    public final String ident;
    public final short fancyUID;
    public final short plainUID;
    public final short changedUID;

    public LeafType(String ident, short fancyUID, short plainUID, short changedUID)
    {
      this.ident = ident;
      this.fancyUID = fancyUID;
      this.plainUID = plainUID;
      this.changedUID = changedUID;
    }
  }
}