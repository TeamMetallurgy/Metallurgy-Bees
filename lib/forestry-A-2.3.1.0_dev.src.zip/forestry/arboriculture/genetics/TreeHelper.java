package forestry.arboriculture.genetics;

import cpw.mods.fml.common.FMLCommonHandler;
import forestry.api.arboriculture.EnumGermlingType;
import forestry.api.arboriculture.EnumTreeChromosome;
import forestry.api.arboriculture.IAlleleFruit;
import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.IArboristTracker;
import forestry.api.arboriculture.ILeafTickHandler;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeMutation;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.arboriculture.ITreekeepingMode;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IChromosomeType;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IMutation;
import forestry.arboriculture.gadgets.BlockFruitPod;
import forestry.arboriculture.gadgets.TileFruitPod;
import forestry.arboriculture.gadgets.TileLeaves;
import forestry.arboriculture.gadgets.TileSapling;
import forestry.core.config.ForestryBlock;
import forestry.core.config.ForestryItem;
import forestry.core.genetics.SpeciesRoot;
import forestry.core.utils.BlockUtil;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Logger;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class TreeHelper extends SpeciesRoot
  implements ITreeRoot
{
  public static final String UID = "rootTrees";
  public static int treeSpeciesCount = -1;

  ArrayList<ITreekeepingMode> treekeepingModes = new ArrayList();
  public static ITreekeepingMode activeTreekeepingMode;
  public static ArrayList<ITree> treeTemplates = new ArrayList();

  private static ArrayList<ITreeMutation> treeMutations = new ArrayList();

  private LinkedList<ILeafTickHandler> leafTickHandlers = new LinkedList();

  public String getUID()
  {
    return "rootTrees";
  }

  public TreeHelper() {
    setResearchSuitability(new ItemStack(Block.sapling.blockID, 1, 32767), 1.0F);
  }

  public Class getMemberClass()
  {
    return ITree.class;
  }

  public int getSpeciesCount()
  {
    if (treeSpeciesCount < 0) {
      treeSpeciesCount = 0;
      Iterator it = AlleleManager.alleleRegistry.getRegisteredAlleles().entrySet().iterator();
      while (it.hasNext()) {
        Map.Entry entry = (Map.Entry)it.next();
        if (((entry.getValue() instanceof IAlleleTreeSpecies)) && 
          (((IAlleleTreeSpecies)entry.getValue()).isCounted())) {
          treeSpeciesCount += 1;
        }
      }
    }
    return treeSpeciesCount;
  }

  public boolean isMember(ItemStack itemstack)
  {
    return getType(itemstack) != EnumGermlingType.NONE;
  }

  public boolean isMember(ItemStack stack, int type)
  {
    return getType(stack).ordinal() == type;
  }

  public boolean isMember(IIndividual individual)
  {
    return individual instanceof ITree;
  }

  public EnumGermlingType getType(ItemStack stack)
  {
    if (stack == null) {
      return EnumGermlingType.NONE;
    }
    if (ForestryItem.sapling.isItemEqual(stack))
      return EnumGermlingType.SAPLING;
    if (ForestryItem.pollenFertile.isItemEqual(stack)) {
      return EnumGermlingType.POLLEN;
    }
    return EnumGermlingType.NONE;
  }

  public ITree getTree(World world, int x, int y, int z)
  {
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileSapling)) {
      return null;
    }
    return ((TileSapling)tile).getTree();
  }

  public ITree getMember(ItemStack itemstack)
  {
    if (!isMember(itemstack))
      return null;
    if (itemstack.getTagCompound() == null) {
      return null;
    }
    return new Tree(itemstack.getTagCompound());
  }

  public ITree getMember(NBTTagCompound compound)
  {
    return new Tree(compound);
  }

  public ITree getTree(World world, ITreeGenome genome)
  {
    return new Tree(genome);
  }

  public ItemStack getMemberStack(IIndividual tree, int type)
  {
    Item germlingItem;
    switch (1.$SwitchMap$forestry$api$arboriculture$EnumGermlingType[EnumGermlingType.VALUES[type].ordinal()]) {
    case 1:
      germlingItem = ForestryItem.sapling.item();
      break;
    case 2:
      germlingItem = ForestryItem.pollenFertile.item();
      break;
    default:
      return null;
    }

    NBTTagCompound nbttagcompound = new NBTTagCompound("tag");
    tree.writeToNBT(nbttagcompound);

    ItemStack treeStack = new ItemStack(germlingItem);
    treeStack.setTagCompound(nbttagcompound);

    return treeStack;
  }

  public boolean plantSapling(World world, ITree tree, String owner, int x, int y, int z)
  {
    boolean placed = world.setBlock(x, y, z, ForestryBlock.saplingGE.blockID, 0, 2);
    if (!placed) {
      return false;
    }
    if (world.getBlockId(x, y, z) != ForestryBlock.saplingGE.blockID) {
      return false;
    }
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileSapling)) {
      world.setBlock(x, y, z, 0, 0, 2);
      return false;
    }

    TileSapling sapling = (TileSapling)tile;
    sapling.setTree(tree.copy());
    sapling.setOwner(owner);
    world.markBlockForUpdate(x, y, z);

    return true;
  }

  public boolean setLeaves(World world, IIndividual tree, String owner, int x, int y, int z)
  {
    boolean placed = world.setBlock(x, y, z, ForestryBlock.leaves.blockID, 0, 2);
    if (!placed) {
      return false;
    }
    if (world.getBlockId(x, y, z) != ForestryBlock.leaves.blockID) {
      return false;
    }
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileLeaves)) {
      world.setBlock(x, y, z, 0, 0, 2);
      return false;
    }

    TileLeaves leaves = (TileLeaves)tile;
    leaves.setTree((ITree)tree.copy());
    leaves.setOwner(owner);
    world.markBlockForUpdate(x, y, z);

    return true;
  }

  public boolean setFruitBlock(World world, IAlleleFruit allele, float sappiness, short[] indices, int x, int y, int z)
  {
    int direction = BlockUtil.getDirectionalMetadata(world, x, y, z);
    if (direction < 0)
      return false;
    boolean placed = world.setBlock(x, y, z, ForestryBlock.pods.blockID, direction, 2);
    if (!placed) {
      return false;
    }
    if (world.getBlockId(x, y, z) != ForestryBlock.pods.blockID) {
      return false;
    }
    TileFruitPod pod = BlockFruitPod.getPodTile(world, x, y, z);
    if (pod == null) {
      world.setBlock(x, y, z, 0, 0, 2);
      return false;
    }
    pod.setFruit(allele, sappiness, indices);
    world.markBlockForUpdate(x, y, z);
    return true;
  }

  public ITreeGenome templateAsGenome(IAllele[] template)
  {
    return new TreeGenome(templateAsChromosomes(template));
  }

  public ITreeGenome templateAsGenome(IAllele[] templateActive, IAllele[] templateInactive)
  {
    return new TreeGenome(templateAsChromosomes(templateActive, templateInactive));
  }

  public ITree templateAsIndividual(IAllele[] template)
  {
    return new Tree(templateAsGenome(template));
  }

  public ITree templateAsIndividual(IAllele[] templateActive, IAllele[] templateInactive)
  {
    return new Tree(templateAsGenome(templateActive, templateInactive));
  }

  public IArboristTracker getBreedingTracker(World world, String player)
  {
    String filename = "ArboristTracker." + player;
    ArboristTracker tracker = (ArboristTracker)world.loadItemData(ArboristTracker.class, filename);

    if (tracker == null) {
      tracker = new ArboristTracker(filename, player);
      world.setItemData(filename, tracker);
    }

    return tracker;
  }

  public ArrayList<ITreekeepingMode> getTreekeepingModes()
  {
    return treekeepingModes;
  }

  public ITreekeepingMode getTreekeepingMode(World world)
  {
    if (activeTreekeepingMode != null) {
      return activeTreekeepingMode;
    }

    IArboristTracker tracker = getBreedingTracker(world, "__COMMON_");
    String mode = tracker.getModeName();
    if ((mode == null) || (mode.isEmpty())) {
      mode = PluginArboriculture.treekeepingMode;
    }
    setTreekeepingMode(world, mode);
    FMLCommonHandler.instance().getFMLLogger().fine("Set Treekeeping mode for a world to " + mode);

    return activeTreekeepingMode;
  }

  public void registerTreekeepingMode(ITreekeepingMode mode)
  {
    treekeepingModes.add(mode);
  }

  public void setTreekeepingMode(World world, String name)
  {
    activeTreekeepingMode = getTreekeepingMode(name);
    getBreedingTracker(world, "__COMMON_").setModeName(name);
  }

  public ITreekeepingMode getTreekeepingMode(String name)
  {
    for (ITreekeepingMode mode : treekeepingModes) {
      if ((mode.getName().equals(name)) || (mode.getName().equals(name.toLowerCase(Locale.ENGLISH))))
        return mode;
    }
    FMLCommonHandler.instance().getFMLLogger().fine("Failed to find a Treekeeping mode called '%s', reverting to fallback.");
    return (ITreekeepingMode)treekeepingModes.get(0);
  }

  public ArrayList<ITree> getIndividualTemplates()
  {
    return treeTemplates;
  }

  public void registerTemplate(String identifier, IAllele[] template)
  {
    treeTemplates.add(new Tree(PluginArboriculture.treeInterface.templateAsGenome(template)));
    speciesTemplates.put(identifier, template);
  }

  public IAllele[] getDefaultTemplate()
  {
    return TreeTemplates.getDefaultTemplate();
  }

  public ArrayList<ITreeMutation> getMutations(boolean shuffle)
  {
    if (shuffle)
      Collections.shuffle(treeMutations);
    return treeMutations;
  }

  public void registerMutation(IMutation mutation)
  {
    if (AlleleManager.alleleRegistry.isBlacklisted(mutation.getTemplate()[0].getUID()))
      return;
    if (AlleleManager.alleleRegistry.isBlacklisted(mutation.getAllele0().getUID()))
      return;
    if (AlleleManager.alleleRegistry.isBlacklisted(mutation.getAllele1().getUID())) {
      return;
    }
    treeMutations.add((ITreeMutation)mutation);
  }

  public void registerLeafTickHandler(ILeafTickHandler handler)
  {
    leafTickHandlers.add(handler);
  }

  public Collection<ILeafTickHandler> getLeafTickHandlers()
  {
    return leafTickHandlers;
  }

  public IChromosomeType[] getKaryotype()
  {
    return EnumTreeChromosome.values();
  }

  public IChromosomeType getKaryotypeKey()
  {
    return EnumTreeChromosome.SPECIES;
  }
}