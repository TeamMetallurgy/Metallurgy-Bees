package forestry.arboriculture.genetics;

import forestry.api.arboriculture.IArboristTracker;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.genetics.IBreedingTracker;
import forestry.api.genetics.IIndividual;
import forestry.core.genetics.BreedingTracker;
import forestry.plugins.PluginArboriculture;
import net.minecraft.entity.player.EntityPlayer;

public class ArboristTracker extends BreedingTracker
  implements IArboristTracker
{
  public ArboristTracker(String s)
  {
    this(s, "");
  }

  public ArboristTracker(String s, String player) {
    super(s, player);
  }

  protected IBreedingTracker getCommonTracker(EntityPlayer player)
  {
    return PluginArboriculture.treeInterface.getBreedingTracker(player.worldObj, "__COMMON_");
  }

  protected String getPacketTag()
  {
    return "rootTrees";
  }

  public void registerPickup(IIndividual individual)
  {
  }
}