package forestry.arboriculture;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.arboriculture.EnumTreeChromosome;
import forestry.api.arboriculture.IAlleleFruit;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.genetics.IFruitFamily;
import forestry.core.render.TextureManager;
import forestry.core.utils.BlockUtil;
import forestry.plugins.PluginArboriculture;
import java.util.Locale;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class FruitProviderPod extends FruitProviderNone
{
  private static ItemStack[] DUMMY = new ItemStack[0];
  private EnumPodType type;
  private ItemStack[] drop;

  public FruitProviderPod(String key, IFruitFamily family, EnumPodType type, ItemStack[] dropOnMature)
  {
    super(key, family);
    this.type = type;
    drop = dropOnMature;
  }

  public boolean requiresFruitBlocks()
  {
    return true;
  }

  public ItemStack[] getFruits(ITreeGenome genome, World world, int x, int y, int z, int ripeningTime)
  {
    if ((drop == null) || (drop.length == 0)) {
      return DUMMY;
    }
    if (ripeningTime >= 2) {
      ItemStack[] dropping = new ItemStack[drop.length];
      for (int i = 0; i < drop.length; i++)
        dropping[i] = drop[i].copy();
      return dropping;
    }

    return DUMMY;
  }

  public boolean trySpawnFruitBlock(ITreeGenome genome, World world, int x, int y, int z)
  {
    if (world.rand.nextFloat() > genome.getSappiness()) {
      return false;
    }
    if (type == EnumPodType.COCOA) {
      return BlockUtil.tryPlantPot(world, x, y, z, Block.cocoaPlant.blockID);
    }
    return PluginArboriculture.treeInterface.setFruitBlock(world, (IAlleleFruit)genome.getActiveAllele(EnumTreeChromosome.FRUITS.ordinal()), genome.getSappiness(), type.uids, x, y, z);
  }

  public short getIconIndex(ITreeGenome genome, IBlockAccess world, int x, int y, int z, int ripeningTime, boolean fancy)
  {
    return type.uids[0];
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    if (type == EnumPodType.COCOA) {
      return;
    }
    TextureManager.getInstance().registerTexUID(register, type.uids[0], "pods/" + type.toString().toLowerCase(Locale.ENGLISH) + ".0");
    TextureManager.getInstance().registerTexUID(register, type.uids[1], "pods/" + type.toString().toLowerCase(Locale.ENGLISH) + ".1");
    TextureManager.getInstance().registerTexUID(register, type.uids[2], "pods/" + type.toString().toLowerCase(Locale.ENGLISH) + ".2");
  }

  public static enum EnumPodType
  {
    COCOA((short)2000, (short)2001, (short)2002), DATES((short)2010, (short)2011, (short)2012), 
    PAPAYA((short)2013, (short)2014, (short)2015);

    public final short[] uids;

    private EnumPodType(short stage1, short stage2, short stage3) {
      uids = new short[] { stage1, stage2, stage3 };
    }
  }
}