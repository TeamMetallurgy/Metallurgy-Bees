package forestry.arboriculture;

import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.arboriculture.ITreekeepingMode;
import forestry.api.genetics.IFruitFamily;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class FruitProviderRipening extends FruitProviderNone
{
  HashMap<ItemStack, Float> products = new HashMap();

  int colourRipe = 16777215;
  int colourCallow = 16777215;
  int diffR;
  int diffG;
  int diffB = 0;

  public FruitProviderRipening(String key, IFruitFamily family, ItemStack product, float modifier) {
    super(key, family);
    products.put(product, Float.valueOf(modifier));
  }

  public FruitProviderRipening setColours(int ripe, int callow) {
    colourRipe = ripe;
    colourCallow = callow;

    diffR = ((ripe >> 16 & 0xFF) - (callow >> 16 & 0xFF));
    diffG = ((ripe >> 8 & 0xFF) - (callow >> 8 & 0xFF));
    diffB = ((ripe & 0xFF) - (callow & 0xFF));

    return this;
  }

  public FruitProviderRipening setRipeningPeriod(int period) {
    ripeningPeriod = period;
    return this;
  }

  private float getRipeningStage(int ripeningTime) {
    if (ripeningTime >= ripeningPeriod) {
      return 1.0F;
    }
    return ripeningTime / ripeningPeriod;
  }

  public ItemStack[] getFruits(ITreeGenome genome, World world, int x, int y, int z, int ripeningTime)
  {
    ArrayList product = new ArrayList();

    float stage = getRipeningStage(ripeningTime);
    if (stage < 0.5F) {
      return new ItemStack[0];
    }
    float modeYieldMod = PluginArboriculture.treeInterface.getTreekeepingMode(world).getYieldModifier(genome, 1.0F);

    for (Map.Entry entry : products.entrySet()) {
      if (world.rand.nextFloat() <= genome.getYield() * ((Float)entry.getValue()).floatValue() * modeYieldMod * 5.0F * stage)
        product.add(((ItemStack)entry.getKey()).copy());
    }
    return (ItemStack[])product.toArray(new ItemStack[0]);
  }

  public ItemStack[] getProducts()
  {
    return (ItemStack[])products.keySet().toArray(new ItemStack[0]);
  }

  public ItemStack[] getSpecialty()
  {
    return new ItemStack[0];
  }

  public boolean markAsFruitLeaf(ITreeGenome genome, World world, int x, int y, int z)
  {
    return true;
  }

  public int getColour(ITreeGenome genome, IBlockAccess world, int x, int y, int z, int ripeningTime)
  {
    float stage = getRipeningStage(ripeningTime);

    int r = (colourCallow >> 16 & 0xFF) + (int)(diffR * stage);
    int g = (colourCallow >> 8 & 0xFF) + (int)(diffG * stage);
    int b = (colourCallow & 0xFF) + (int)(diffB * stage);

    return (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
  }
}