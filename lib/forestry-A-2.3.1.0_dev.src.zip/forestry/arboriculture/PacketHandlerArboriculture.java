package forestry.arboriculture;

import cpw.mods.fml.common.network.Player;
import forestry.arboriculture.gadgets.TileLeaves;
import forestry.arboriculture.network.PacketLeafUpdate;
import forestry.core.interfaces.IPacketHandler;
import forestry.core.network.ILocatedPacket;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import java.io.DataInputStream;
import net.minecraft.network.INetworkManager;
import net.minecraft.tileentity.TileEntity;

public class PacketHandlerArboriculture
  implements IPacketHandler
{
  public void onPacketData(INetworkManager network, int packetID, DataInputStream data, Player player)
  {
    try
    {
      switch (packetID) {
      case 90:
        PacketLeafUpdate packet = new PacketLeafUpdate();
        packet.readData(data);
        onLeafUpdate(packet);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }

  private void onLeafUpdate(PacketLeafUpdate packet)
  {
    TileEntity tile = packet.getTarget(Proxies.common.getRenderWorld());
    if ((tile instanceof TileLeaves))
      ((TileLeaves)tile).fromPacket(packet);
  }
}