package forestry.arboriculture;

import forestry.arboriculture.gui.ContainerTreealyzer;
import forestry.arboriculture.gui.GuiTreealyzer;
import forestry.arboriculture.items.ItemTreealyzer.TreealyzerInventory;
import forestry.core.GuiHandlerBase;
import forestry.core.network.GuiId;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class GuiHandlerArboriculture extends GuiHandlerBase
{
  public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z)
  {
    int cleanId = decodeGuiID(id);

    if (cleanId >= GuiId.values().length) {
      return null;
    }
    switch (1.$SwitchMap$forestry$core$network$GuiId[GuiId.values()[cleanId].ordinal()])
    {
    case 1:
      return getNaturalistChestContainer("rootTrees", player, world, x, y, z, decodeGuiData(id));
    case 2:
      ItemStack equipped = getEquippedItem(player);
      if (equipped == null) {
        return null;
      }
      return new ContainerTreealyzer(player.inventory, new ItemTreealyzer.TreealyzerInventory(player, equipped));
    }

    return null;
  }

  public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z)
  {
    int cleanId = decodeGuiID(id);

    if (cleanId >= GuiId.values().length) {
      return null;
    }
    switch (1.$SwitchMap$forestry$core$network$GuiId[GuiId.values()[cleanId].ordinal()])
    {
    case 1:
      return getNaturalistChestGui("rootTrees", player, world, x, y, z, decodeGuiData(id));
    case 2:
      ItemStack equipped = getEquippedItem(player);
      if (equipped == null) {
        return null;
      }
      return new GuiTreealyzer(player, new ItemTreealyzer.TreealyzerInventory(player, equipped));
    }

    return null;
  }
}