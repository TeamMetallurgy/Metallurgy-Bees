package forestry.arboriculture;

import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.arboriculture.ITreekeepingMode;
import forestry.api.genetics.IFruitFamily;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class FruitProviderRandom extends FruitProviderNone
{
  HashMap<ItemStack, Float> products = new HashMap();
  int colour = 16777215;

  public FruitProviderRandom(String key, IFruitFamily family, ItemStack product, float modifier) {
    super(key, family);
    products.put(product, Float.valueOf(modifier));
  }

  public FruitProviderRandom setColour(int colour) {
    this.colour = colour;
    return this;
  }

  public int getColour(ITreeGenome genome, IBlockAccess world, int x, int y, int z, int ripeningTime)
  {
    return colour;
  }

  public ItemStack[] getFruits(ITreeGenome genome, World world, int x, int y, int z, int ripeningTime)
  {
    ArrayList product = new ArrayList();

    float modeYieldMod = PluginArboriculture.treeInterface.getTreekeepingMode(world).getYieldModifier(genome, 1.0F);

    for (Map.Entry entry : products.entrySet()) {
      if (world.rand.nextFloat() <= genome.getYield() * modeYieldMod * ((Float)entry.getValue()).floatValue())
        product.add(((ItemStack)entry.getKey()).copy());
    }
    return (ItemStack[])product.toArray(new ItemStack[0]);
  }

  public ItemStack[] getProducts()
  {
    return (ItemStack[])products.keySet().toArray(new ItemStack[0]);
  }

  public ItemStack[] getSpecialty()
  {
    return new ItemStack[0];
  }

  public boolean markAsFruitLeaf(ITreeGenome genome, World world, int x, int y, int z)
  {
    return true;
  }
}