package forestry.arboriculture.gadgets;

import java.util.Random;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public abstract class BlockTreeContainer extends BlockContainer
{
  public BlockTreeContainer(int id, Material material)
  {
    super(id, material);
    setTickRandomly(true);
  }

  public void updateTick(World world, int x, int y, int z, Random rand)
  {
    if (world.rand.nextFloat() > 0.1D) {
      return;
    }
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileTreeContainer)) {
      return;
    }
    ((TileTreeContainer)tile).onBlockTick();
  }

  public boolean hasTileEntity(int metadata)
  {
    return true;
  }
}