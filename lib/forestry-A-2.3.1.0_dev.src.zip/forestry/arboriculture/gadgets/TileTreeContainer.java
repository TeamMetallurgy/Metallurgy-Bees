package forestry.arboriculture.gadgets;

import forestry.api.arboriculture.ITree;
import forestry.arboriculture.genetics.Tree;
import forestry.core.interfaces.IOwnable;
import forestry.core.network.ForestryPacket;
import forestry.core.network.INetworkedEntity;
import forestry.core.network.PacketTileNBT;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyNetwork;
import forestry.core.utils.EnumAccess;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public abstract class TileTreeContainer extends TileEntity
  implements INetworkedEntity, IOwnable
{
  private ITree containedTree;
  public String owner = null;

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    if (nbttagcompound.hasKey("ContainedTree"))
      containedTree = new Tree(nbttagcompound.getCompoundTag("ContainedTree"));
    if (nbttagcompound.hasKey("Owner"))
      owner = nbttagcompound.getString("Owner");
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    if (containedTree != null) {
      NBTTagCompound subcompound = new NBTTagCompound();
      containedTree.writeToNBT(subcompound);
      nbttagcompound.setCompoundTag("ContainedTree", subcompound);
    }
    if (owner != null)
      nbttagcompound.setString("Owner", owner);
  }

  public void setTree(ITree tree)
  {
    containedTree = tree;
    if (tree != null)
      sendNetworkUpdate();
  }

  public ITree getTree() {
    return containedTree;
  }

  public boolean canUpdate()
  {
    return false;
  }

  public abstract void onBlockTick();

  public Packet getDescriptionPacket()
  {
    return new PacketTileNBT(5, this).getPacket();
  }

  public void sendNetworkUpdate()
  {
    Proxies.net.sendNetworkPacket(new PacketTileNBT(5, this), xCoord, yCoord, zCoord);
  }

  public void fromPacket(ForestryPacket packetRaw)
  {
    PacketTileNBT packet = (PacketTileNBT)packetRaw;
    readFromNBT(packet.getTagCompound());
    worldObj.markBlockForRenderUpdate(xCoord, yCoord, zCoord);
  }

  public boolean allowsRemoval(EntityPlayer player)
  {
    return true;
  }

  public boolean allowsInteraction(EntityPlayer player)
  {
    return true;
  }

  public EnumAccess getAccess()
  {
    return EnumAccess.SHARED;
  }

  public boolean isOwnable()
  {
    return false;
  }

  public boolean isOwned()
  {
    return (owner != null) && (!owner.isEmpty());
  }

  public String getOwnerName()
  {
    return owner;
  }

  public void setOwner(EntityPlayer player)
  {
    owner = player.username;
  }

  public void setOwner(String playername) {
    owner = playername;
  }

  public boolean isOwner(EntityPlayer player)
  {
    if (owner != null) {
      return owner.equals(player.username);
    }
    return false;
  }

  public boolean switchAccessRule(EntityPlayer player)
  {
    return false;
  }
}