package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.arboriculture.IWoodTyped;
import forestry.arboriculture.WoodType;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public class BlockLog extends Block
  implements IWoodTyped
{
  private LogCat cat;

  public BlockLog(int id, LogCat cat)
  {
    super(id, Material.wood);
    this.cat = cat;

    setHardness(2.0F);
    setResistance(5.0F);
    setStepSound(soundWoodFootstep);
    setCreativeTab(Tabs.tabArboriculture);
  }

  public static int getTypeFromMeta(int damage)
  {
    return damage & 0x3;
  }

  public int getRenderType()
  {
    return Block.wood.getRenderType();
  }

  public void breakBlock(World world, int x, int y, int z, int par5, int par6)
  {
    byte radius = 4;
    int boundary = radius + 1;

    if (world.checkChunksExist(x - boundary, y - boundary, z - boundary, x + boundary, y + boundary, z + boundary))
      for (int i = -radius; i <= radius; i++)
        for (int j = -radius; j <= radius; j++)
          for (int k = -radius; k <= radius; k++) {
            int blockid = world.getBlockId(x + i, y + j, z + k);

            if (Block.blocksList[blockid] != null)
              Block.blocksList[blockid].beginLeavesDecay(world, x + i, y + j, z + k);
          }
  }

  public int onBlockPlaced(World world, int x, int y, int z, int side, float par6, float par7, float par8, int meta)
  {
    int type = getTypeFromMeta(meta);
    byte b0 = 0;

    switch (side) {
    case 0:
    case 1:
      b0 = 0;
      break;
    case 2:
    case 3:
      b0 = 8;
      break;
    case 4:
    case 5:
      b0 = 4;
    }

    return type | b0;
  }

  public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    if (cat == LogCat.CAT6) {
      return;
    }

    for (int i = 0; i < 4; i++)
      itemList.add(new ItemStack(this, 1, i));
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    WoodType.registerIcons(register);
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int side, int meta)
  {
    int oriented = meta & 0xC;

    WoodType type = getWoodType(getTypeFromMeta(meta));
    switch (oriented) {
    case 4:
      if (side > 3) {
        return type.getHeartIcon();
      }
      return type.getBarkIcon();
    case 8:
      if ((side == 2) || (side == 3)) {
        return type.getHeartIcon();
      }
      return type.getBarkIcon();
    case 0:
    }
    if (side < 2) {
      return type.getHeartIcon();
    }
    return type.getBarkIcon();
  }

  public int damageDropped(int meta)
  {
    return getTypeFromMeta(meta);
  }

  protected ItemStack createStackedBlock(int meta)
  {
    return new ItemStack(blockID, 1, getTypeFromMeta(meta));
  }

  public float getBlockHardness(World world, int x, int y, int z)
  {
    return getWoodType(getTypeFromMeta(world.getBlockMetadata(x, y, z))).getHardness();
  }

  public int getFlammability(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 20;
  }

  public boolean isFlammable(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return true;
  }

  public int getFireSpreadSpeed(World world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    if (face == ForgeDirection.DOWN)
      return 20;
    if (face != ForgeDirection.UP) {
      return 10;
    }
    return 5;
  }

  public boolean canSustainLeaves(World world, int x, int y, int z)
  {
    return true;
  }

  public boolean isWood(World world, int x, int y, int z)
  {
    return true;
  }

  public WoodType getWoodType(int meta)
  {
    if (meta + cat.ordinal() * 4 < WoodType.VALUES.length) {
      return WoodType.VALUES[(meta + cat.ordinal() * 4)];
    }
    return WoodType.LARCH;
  }

  public String getBlockKind()
  {
    return "log";
  }

  public static enum LogCat
  {
    CAT0, CAT1, CAT2, CAT3, CAT4, CAT5, CAT6, CAT7;
  }
}