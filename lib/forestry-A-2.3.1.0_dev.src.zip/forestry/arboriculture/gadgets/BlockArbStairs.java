package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.arboriculture.WoodType;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.StackUtils;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockArbStairs extends BlockStairs
{
  public BlockArbStairs(int id, Block par2Block, int par3)
  {
    super(id, par2Block, par3);
    Block.useNeighborBrightness[id] = true;
    setCreativeTab(Tabs.tabArboriculture);
    setHardness(2.0F);
    setResistance(5.0F);
  }

  public static TileStairs getStairTile(IBlockAccess world, int x, int y, int z) {
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileStairs)) {
      return null;
    }
    return (TileStairs)tile;
  }

  @SideOnly(Side.CLIENT)
  public void getSubBlocks(int id, CreativeTabs tab, List list) {
    for (WoodType type : WoodType.VALUES)
      if (type.hasPlank)
      {
        ItemStack stack = new ItemStack(id, 1, 0);
        NBTTagCompound compound = new NBTTagCompound("tag");
        type.saveToCompound(compound);
        stack.setTagCompound(compound);
        list.add(stack);
      }
  }

  public boolean removeBlockByPlayer(World world, EntityPlayer player, int x, int y, int z)
  {
    int meta = world.getBlockMetadata(x, y, z);
    if ((Proxies.common.isSimulating(world)) && (canHarvestBlock(player, meta)) && 
      (!player.capabilities.isCreativeMode))
    {
      TileEntity tile = world.getBlockTileEntity(x, y, z);

      if ((tile instanceof TileStairs)) {
        TileStairs stairs = (TileStairs)tile;

        ItemStack stack = new ItemStack(blockID, 1, 0);
        NBTTagCompound compound = new NBTTagCompound("tag");
        stairs.getType().saveToCompound(compound);
        stack.setTagCompound(compound);
        StackUtils.dropItemStackAsEntity(stack, world, x, y, z);
      }
    }

    return world.setBlock(x, y, z, 0, 0, 2);
  }

  public void breakBlock(World world, int x, int y, int z, int par5, int par6)
  {
    world.removeBlockTileEntity(x, y, z);
    super.breakBlock(world, x, y, z, par5, par6);
  }

  public ArrayList<ItemStack> getBlockDropped(World world, int x, int y, int z, int metadata, int fortune)
  {
    return new ArrayList();
  }

  public boolean hasTileEntity(int meta)
  {
    return true;
  }

  public TileEntity createTileEntity(World world, int meta)
  {
    return new TileStairs();
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    WoodType.registerIcons(register);
  }

  @SideOnly(Side.CLIENT)
  public Icon getBlockTexture(IBlockAccess world, int x, int y, int z, int side)
  {
    TileStairs stairs = getStairTile(world, x, y, z);
    if ((stairs != null) && (stairs.getType() != null)) {
      return stairs.getType().getPlankIcon();
    }
    return WoodType.LARCH.getPlankIcon();
  }
}