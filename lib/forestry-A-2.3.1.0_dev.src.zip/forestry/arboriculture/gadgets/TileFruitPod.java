package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.arboriculture.IAlleleFruit;
import forestry.api.arboriculture.IFruitProvider;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IFruitBearer;
import forestry.api.genetics.IFruitFamily;
import forestry.core.network.ForestryPacket;
import forestry.core.network.INetworkedEntity;
import forestry.core.network.PacketPayload;
import forestry.core.network.PacketUpdate;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyNetwork;
import forestry.core.render.TextureManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.World;

public class TileFruitPod extends TileEntity
  implements INetworkedEntity, IFruitBearer
{
  private static final short MAX_MATURITY = 2;
  private IAlleleFruit allele;
  private short maturity;
  private int[] indices = new int[0];
  private float sappiness;

  public void setFruit(IAlleleFruit allele, float sappiness, short[] indices)
  {
    this.allele = allele;
    this.sappiness = sappiness;
    this.indices = new int[indices.length];
    for (int i = 0; i < indices.length; i++)
      this.indices[i] = indices[i];
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    IAllele stored = AlleleManager.alleleRegistry.getAllele(nbttagcompound.getString("UID"));
    if ((stored != null) && ((stored instanceof IAlleleFruit)))
      allele = ((IAlleleFruit)stored);
    else {
      allele = ((IAlleleFruit)AlleleManager.alleleRegistry.getAllele("fruitCocoa"));
    }
    maturity = nbttagcompound.getShort("MT");
    sappiness = nbttagcompound.getFloat("SP");
    indices = nbttagcompound.getIntArray("IN");
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    if (allele != null) {
      nbttagcompound.setString("UID", allele.getUID());
    }
    nbttagcompound.setShort("MT", maturity);
    nbttagcompound.setFloat("SP", sappiness);
    nbttagcompound.setIntArray("IN", indices);
  }

  public boolean canUpdate()
  {
    return false;
  }

  public void onBlockTick() {
    if ((canMature()) && (worldObj.rand.nextFloat() <= sappiness))
      mature();
  }

  public void mature()
  {
    maturity = ((short)(maturity + 1));
    sendNetworkUpdateRipening();
  }

  public boolean canMature() {
    return maturity < 2;
  }

  @SideOnly(Side.CLIENT)
  public Icon getBlockTexture(int metadata, int side) {
    if (maturity < indices.length) {
      return TextureManager.getInstance().getIcon((short)indices[maturity]);
    }
    return null;
  }

  public short getMaturity() {
    return maturity;
  }

  public ItemStack[] getDrop() {
    return allele.getProvider().getFruits(null, worldObj, xCoord, yCoord, zCoord, maturity);
  }

  public Packet getDescriptionPacket()
  {
    return toPacket().getPacket();
  }

  public void sendNetworkUpdate()
  {
    Proxies.net.sendNetworkPacket(toPacket(), xCoord, yCoord, zCoord);
  }

  private void sendNetworkUpdateRipening() {
    Proxies.net.sendNetworkPacket(new PacketUpdate(1, xCoord, yCoord, zCoord, maturity), xCoord, yCoord, zCoord);
  }

  private ForestryPacket toPacket()
  {
    PacketPayload payload = new PacketPayload(indices.length, 1);
    payload.shortPayload[0] = maturity;
    payload.intPayload = indices;

    return new PacketUpdate(1, xCoord, yCoord, zCoord, payload);
  }

  public void fromPacket(ForestryPacket packetRaw)
  {
    PacketUpdate packet = (PacketUpdate)packetRaw;
    maturity = packet.payload.shortPayload[0];

    if ((packet.payload.intPayload != null) && (packet.payload.intPayload.length > 0)) {
      indices = packet.payload.intPayload;
    }

    worldObj.markBlockForRenderUpdate(xCoord, yCoord, zCoord);
  }

  public boolean hasFruit()
  {
    return true;
  }

  public IFruitFamily getFruitFamily()
  {
    if (allele == null)
      return null;
    return allele.getProvider().getFamily();
  }

  public Collection<ItemStack> pickFruit(ItemStack tool)
  {
    if (allele == null) {
      return new ArrayList();
    }

    Collection fruits = Arrays.asList(getDrop());
    maturity = 0;
    sendNetworkUpdateRipening();
    return fruits;
  }

  public float getRipeness()
  {
    return maturity / 2.0F;
  }

  public void addRipeness(float add)
  {
    maturity = ((short)(int)(maturity + 2.0F * add));
    sendNetworkUpdateRipening();
  }
}