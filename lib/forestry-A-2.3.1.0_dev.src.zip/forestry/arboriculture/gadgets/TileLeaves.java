package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.arboriculture.IAlleleFruit;
import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.IFruitProvider;
import forestry.api.arboriculture.ILeafTickHandler;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.arboriculture.ITreekeepingMode;
import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IEffectData;
import forestry.api.genetics.IFruitBearer;
import forestry.api.genetics.IFruitFamily;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IPollinatable;
import forestry.api.genetics.ISpeciesRoot;
import forestry.api.lepidopterology.IButterfly;
import forestry.api.lepidopterology.IButterflyGenome;
import forestry.api.lepidopterology.IButterflyNursery;
import forestry.api.lepidopterology.IButterflyRoot;
import forestry.arboriculture.network.PacketLeafUpdate;
import forestry.arboriculture.proxy.ProxyArboriculture;
import forestry.core.genetics.Allele;
import forestry.core.network.ForestryPacket;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyLog;
import forestry.core.proxy.ProxyNetwork;
import forestry.core.render.TextureManager;
import forestry.core.utils.Utils;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.util.Icon;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.EnumPlantType;

public class TileLeaves extends TileTreeContainer
  implements IPollinatable, IFruitBearer, IButterflyNursery
{
  private int colourLeaves;
  private int colourFruits;
  private short textureIndexFancy = 48;
  private short textureIndexPlain = 64;
  private short textureIndexFruits = -1;
  private boolean isFruitLeaf;
  private boolean isPollinatedState;
  private int ripeningTime;
  private int maturationTime;
  private int encumbrance;
  private int biomeId = -1;

  private IEffectData[] effectData = new IEffectData[2];
  private IButterfly caterpillar;

  private void updateBiome()
  {
    if (worldObj == null)
      return;
    BiomeGenBase biome = Utils.getBiomeAt(worldObj, xCoord, zCoord);
    if (biome != null)
      biomeId = biome.biomeID;
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    isFruitLeaf = nbttagcompound.getBoolean("FL");
    ripeningTime = nbttagcompound.getInteger("RT");

    encumbrance = nbttagcompound.getInteger("ENC");

    if (nbttagcompound.hasKey("CATER")) {
      maturationTime = nbttagcompound.getInteger("CATMAT");
      caterpillar = ((IButterfly)AlleleManager.alleleRegistry.getSpeciesRoot("rootButterflies").getMember(nbttagcompound.getCompoundTag("CATER")));
    }
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    nbttagcompound.setBoolean("FL", isFruitLeaf);
    nbttagcompound.setInteger("RT", ripeningTime);
    nbttagcompound.setInteger("ENC", encumbrance);

    if (caterpillar != null) {
      nbttagcompound.setInteger("CATMAT", maturationTime);

      NBTTagCompound subcompound = new NBTTagCompound();
      caterpillar.writeToNBT(subcompound);
      nbttagcompound.setCompoundTag("CATER", subcompound);
    }
  }

  public void onBlockTick()
  {
    if (biomeId < 0) {
      updateBiome();
    }
    if (getTree() == null) {
      return;
    }
    boolean isDestroyed = isDestroyed();
    for (ILeafTickHandler tickHandler : getTree().getGenome().getPrimary().getRoot().getLeafTickHandlers()) {
      if (tickHandler.onRandomLeafTick(getTree(), worldObj, biomeId, xCoord, yCoord, zCoord, isDestroyed))
        return;
    }
    if (isDestroyed) {
      return;
    }
    if (encumbrance > 0) {
      encumbrance -= 1;
    }
    if ((hasFruit()) && (ripeningTime < 32766)) {
      float sappiness = getTree().getGenome().getSappiness() * PluginArboriculture.treeInterface.getTreekeepingMode(worldObj).getSappinessModifier(getTree().getGenome(), 1.0F);

      if (worldObj.rand.nextFloat() < sappiness) {
        ripeningTime += 1;
        sendNetworkUpdateRipening();
      }
    }

    if (caterpillar != null) {
      matureCaterpillar();
    }
    effectData = getTree().doEffect(effectData, worldObj, biomeId, xCoord, yCoord, zCoord);
  }

  public void setTree(ITree tree)
  {
    if (tree.canBearFruit())
      isFruitLeaf = tree.getGenome().getFruitProvider().markAsFruitLeaf(tree.getGenome(), worldObj, xCoord, yCoord, zCoord);
    super.setTree(tree);
  }

  private boolean isDestroyed()
  {
    if (getTree() == null)
      return false;
    return encumbrance > getTree().getResilience();
  }

  public boolean isPollinated() {
    return (!isDestroyed()) && (getTree() != null) && (getTree().getMate() != null);
  }

  public int getFoliageColour(EntityPlayer player) {
    return (isPollinatedState & Utils.hasNaturalistEye(player)) ? 16777215 : colourLeaves;
  }

  public int getFruitColour() {
    return colourFruits;
  }

  @SideOnly(Side.CLIENT)
  public Icon getBlockTexture(boolean fancy) {
    if (fancy) {
      return TextureManager.getInstance().getIcon(textureIndexFancy);
    }
    return TextureManager.getInstance().getIcon(textureIndexPlain);
  }

  @SideOnly(Side.CLIENT)
  public Icon getFruitTexture() {
    if (textureIndexFruits >= 0) {
      return TextureManager.getInstance().getIcon(textureIndexFruits);
    }
    return null;
  }

  public int getRipeningTime() {
    return ripeningTime;
  }

  public EnumSet<EnumPlantType> getPlantType()
  {
    if (getTree() == null) {
      return EnumSet.noneOf(EnumPlantType.class);
    }
    return getTree().getPlantTypes();
  }

  public boolean canMateWith(IIndividual individual)
  {
    if (getTree() == null)
      return false;
    if (getTree().getMate() != null) {
      return false;
    }
    return !getTree().isGeneticEqual(individual);
  }

  public void mateWith(IIndividual individual)
  {
    if (getTree() == null) {
      return;
    }
    getTree().mate((ITree)individual);
    worldObj.markBlockForUpdate(xCoord, yCoord, zCoord);
  }

  public IIndividual getPollen()
  {
    return getTree();
  }

  public int determineFoliageColour()
  {
    if (getTree() == null) {
      return PluginArboriculture.proxy.getFoliageColorBasic();
    }
    int colour = getTree().getGenome().getPrimary().getLeafColour(getTree());

    if (isDestroyed())
      return Utils.addRGBComponents(colour, 92, 61, 0);
    if (caterpillar != null)
      return Utils.multiplyRGBComponents(colour, 1.5F);
    return colour;
  }

  public int determineFruitColour() {
    if (getTree() == null) {
      return 16777215;
    }
    IFruitProvider fruit = getTree().getGenome().getFruitProvider();
    return fruit.getColour(getTree().getGenome(), worldObj, xCoord, yCoord, zCoord, getRipeningTime());
  }

  public short determineTextureIndex(boolean fancy) {
    if (getTree() != null) {
      return getTree().getGenome().getPrimary().getLeafIconIndex(getTree(), fancy);
    }
    return 0;
  }

  public short determineOverlayIndex() {
    if (getTree() == null)
      return -1;
    if (!hasFruit()) {
      return -1;
    }
    IFruitProvider fruit = getTree().getGenome().getFruitProvider();

    if ((getTree().getGenome().getPrimary() == Allele.treeOak) && (fruit == ((IAlleleFruit)Allele.fruitApple).getProvider())) {
      return -1;
    }
    return fruit.getIconIndex(getTree().getGenome(), worldObj, xCoord, yCoord, zCoord, getRipeningTime(), true);
  }

  public Packet getDescriptionPacket()
  {
    return new PacketLeafUpdate(xCoord, yCoord, zCoord, this).getPacket();
  }

  public void sendNetworkUpdate()
  {
    Proxies.net.sendNetworkPacket(new PacketLeafUpdate(xCoord, yCoord, zCoord, this), xCoord, yCoord, zCoord);
  }

  private void sendNetworkUpdateRipening() {
    Proxies.net.sendNetworkPacket(new PacketLeafUpdate(xCoord, yCoord, zCoord, determineFruitColour()), xCoord, yCoord, zCoord);
  }

  public void fromPacket(ForestryPacket packetRaw)
  {
    PacketLeafUpdate packet = (PacketLeafUpdate)packetRaw;
    if (packet.isRipeningUpdate()) {
      colourFruits = packet.colourFruits;
    } else {
      isFruitLeaf = packet.isFruitLeaf();
      isPollinatedState = packet.isPollinated();
      textureIndexFancy = packet.textureIndexFancy;
      textureIndexPlain = packet.textureIndexPlain;
      textureIndexFruits = packet.textureIndexFruit;
      colourLeaves = packet.colourLeaves;
      colourFruits = packet.colourFruits;
    }

    worldObj.markBlockForRenderUpdate(xCoord, yCoord, zCoord);
  }

  public Collection<ItemStack> pickFruit(ItemStack tool)
  {
    if (!hasFruit())
      return new ArrayList();
    if (getTree() == null) {
      return new ArrayList();
    }
    ArrayList picked = new ArrayList(Arrays.asList(getTree().produceStacks(worldObj, xCoord, yCoord, zCoord, getRipeningTime())));
    ripeningTime = 0;
    sendNetworkUpdateRipening();
    return picked;
  }

  public IFruitFamily getFruitFamily()
  {
    if (getTree() == null)
      return null;
    return getTree().getGenome().getFruitProvider().getFamily();
  }

  public float getRipeness()
  {
    if (getTree() == null)
      return 0.0F;
    int ripeningPeriod = getTree().getGenome().getFruitProvider().getRipeningPeriod();
    if (ripeningPeriod == 0)
      return 1.0F;
    return ripeningTime / ripeningPeriod;
  }

  public boolean hasFruit()
  {
    return (isFruitLeaf) && (!isDestroyed());
  }

  public void addRipeness(float add)
  {
    if (getTree() == null)
      return;
    ripeningTime = ((int)(ripeningTime + getTree().getGenome().getFruitProvider().getRipeningPeriod() * add));
    sendNetworkUpdateRipening();
  }

  private void matureCaterpillar()
  {
    maturationTime += 1;

    boolean wasDestroyed = isDestroyed();
    encumbrance += caterpillar.getGenome().getMetabolism();
    wasDestroyed = (!wasDestroyed) && (isDestroyed());

    if ((maturationTime >= caterpillar.getGenome().getLifespan() / (caterpillar.getGenome().getFertility() * 2)) && (caterpillar.canTakeFlight(worldObj, xCoord, yCoord, zCoord)))
    {
      if (worldObj.isAirBlock(xCoord - 1, yCoord, zCoord))
        attemptButterflySpawn(worldObj, caterpillar, xCoord - 1, yCoord, zCoord);
      else if (worldObj.isAirBlock(xCoord + 1, yCoord, zCoord))
        attemptButterflySpawn(worldObj, caterpillar, xCoord + 1, yCoord, zCoord);
      else if (worldObj.isAirBlock(xCoord, yCoord, zCoord - 1))
        attemptButterflySpawn(worldObj, caterpillar, xCoord, yCoord, zCoord - 1);
      else if (worldObj.isAirBlock(xCoord, yCoord, zCoord + 1)) {
        attemptButterflySpawn(worldObj, caterpillar, xCoord, yCoord, zCoord + 1);
      }
      setCaterpillar(null);
    } else if (wasDestroyed) {
      sendNetworkUpdate();
    }
  }

  private void attemptButterflySpawn(World world, IButterfly butterfly, double x, double y, double z) {
    if (((IButterflyRoot)AlleleManager.alleleRegistry.getSpeciesRoot("rootButterflies")).spawnButterflyInWorld(world, butterfly.copy(), x, y + 0.1000000014901161D, z) != null)
      Proxies.log.finest("A caterpillar '%s' hatched at %s/%s/%s.", new Object[] { butterfly.getDisplayName(), Double.valueOf(x), Double.valueOf(y), Double.valueOf(z) }); 
  }

  public World getWorld() { return worldObj; } 
  public int getXCoord() { return xCoord; } 
  public int getYCoord() { return yCoord; } 
  public int getZCoord() { return zCoord; }

  public int getBiomeId()
  {
    return 0;
  }

  public EnumTemperature getTemperature()
  {
    return null;
  }

  public EnumHumidity getHumidity()
  {
    return null;
  }
  public void setErrorState(int state) {
  }
  public int getErrorOrdinal() { return 0; }

  public boolean addProduct(ItemStack product, boolean all) {
    return false;
  }
  public IButterfly getCaterpillar() {
    return caterpillar; } 
  public IIndividual getNanny() { return getTree(); }

  public void setCaterpillar(IButterfly butterfly)
  {
    maturationTime = 0;
    caterpillar = butterfly;
    sendNetworkUpdate();
  }

  public boolean canNurse(IButterfly butterfly)
  {
    return (!isDestroyed()) && (caterpillar == null);
  }
}