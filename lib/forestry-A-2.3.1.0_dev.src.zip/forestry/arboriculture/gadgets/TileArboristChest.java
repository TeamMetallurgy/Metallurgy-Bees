package forestry.arboriculture.gadgets;

import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAlleleRegistry;
import forestry.core.gadgets.TileNaturalistChest;
import forestry.core.network.GuiId;

public class TileArboristChest extends TileNaturalistChest
{
  public TileArboristChest()
  {
    super(AlleleManager.alleleRegistry.getSpeciesRoot("rootTrees"), GuiId.ArboristChestGUI.ordinal());
  }
}