package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.arboriculture.IWoodTyped;
import forestry.arboriculture.WoodType;
import forestry.plugins.PluginArboriculture;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFence;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public class BlockArbFence extends BlockFence
  implements IWoodTyped
{
  private FenceCat cat;

  public BlockArbFence(int id, FenceCat cat)
  {
    super(id, "", Material.wood);
    this.cat = cat;
    setHardness(2.0F);
    setResistance(5.0F);
    setStepSound(soundWoodFootstep);
    setCreativeTab(Tabs.tabArboriculture);
  }

  public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    int count = cat == FenceCat.CAT0 ? 16 : 8;
    for (int i = 0; i < count; i++)
      itemList.add(new ItemStack(this, 1, i));
  }

  public int damageDropped(int meta)
  {
    return meta;
  }

  public boolean canPlaceTorchOnTop(World world, int x, int y, int z)
  {
    return true;
  }

  public boolean canConnectFenceTo(IBlockAccess world, int x, int y, int z)
  {
    if (!isFence(world, x, y, z)) {
      int blockid = world.getBlockId(x, y, z);
      Block block = Block.blocksList[blockid];
      return block.blockMaterial != Material.pumpkin;
    }
    return true;
  }

  public int getRenderType()
  {
    return PluginArboriculture.modelIdFences;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    WoodType.registerIcons(register);
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int side, int meta)
  {
    return getWoodType(meta).getPlankIcon();
  }

  public boolean isFence(IBlockAccess world, int x, int y, int z) {
    int blockid = world.getBlockId(x, y, z);
    if (PluginArboriculture.validFenceIDs.contains(Integer.valueOf(blockid))) {
      return true;
    }
    return false;
  }

  public boolean isWood(World world, int x, int y, int z)
  {
    return true;
  }

  public int getFlammability(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 20;
  }

  public boolean isFlammable(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return true;
  }

  public int getFireSpreadSpeed(World world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 5;
  }

  public WoodType getWoodType(int meta)
  {
    if (cat.ordinal() * 16 + meta < WoodType.VALUES.length) {
      return WoodType.VALUES[(cat.ordinal() * 16 + meta)];
    }
    return WoodType.LARCH;
  }

  public String getBlockKind()
  {
    return "fences";
  }

  public static enum FenceCat
  {
    CAT0, CAT1;
  }
}