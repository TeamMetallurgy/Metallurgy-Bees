package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.render.TextureManager;
import forestry.core.utils.BlockUtil;
import forestry.core.utils.StackUtils;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.BlockCocoa;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFruitPod extends BlockCocoa
{

  @SideOnly(Side.CLIENT)
  private static Icon defaultIcon;

  public BlockFruitPod(int id)
  {
    super(id);
  }

  public static TileFruitPod getPodTile(IBlockAccess world, int x, int y, int z) {
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileFruitPod)) {
      return null;
    }
    return (TileFruitPod)tile;
  }

  public void updateTick(World world, int x, int y, int z, Random rand)
  {
    if (!canBlockStay(world, x, y, z)) {
      dropBlockAsItem(world, x, y, z, world.getBlockMetadata(x, y, z), 0);
      world.setBlock(x, y, z, 0, 0, 2);
      return;
    }

    TileFruitPod tile = getPodTile(world, x, y, z);
    if (tile == null) {
      return;
    }
    tile.onBlockTick();
  }

  public boolean removeBlockByPlayer(World world, EntityPlayer player, int x, int y, int z)
  {
    if (Proxies.common.isSimulating(world)) {
      TileFruitPod tile = getPodTile(world, x, y, z);
      if (tile != null) {
        for (ItemStack drop : tile.getDrop()) {
          StackUtils.dropItemStackAsEntity(drop, world, x, y, z);
        }
      }
    }

    return super.removeBlockByPlayer(world, player, x, y, z);
  }

  public ArrayList<ItemStack> getBlockDropped(World world, int x, int y, int z, int metadata, int fortune)
  {
    return new ArrayList();
  }

  public boolean canBlockStay(World world, int x, int y, int z)
  {
    return BlockUtil.getDirectionalMetadata(world, x, y, z) >= 0;
  }

  public void breakBlock(World world, int x, int y, int z, int par5, int par6)
  {
    world.removeBlockTileEntity(x, y, z);
    super.breakBlock(world, x, y, z, par5, par6);
  }

  public boolean hasTileEntity(int meta)
  {
    return true;
  }

  public TileEntity createTileEntity(World world, int meta)
  {
    return new TileFruitPod();
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    defaultIcon = TextureManager.getInstance().registerTex(register, "pods/papaya.2");
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int par1, int par2)
  {
    return defaultIcon;
  }

  @SideOnly(Side.CLIENT)
  public Icon getBlockTexture(IBlockAccess world, int x, int y, int z, int side)
  {
    TileFruitPod pod = getPodTile(world, x, y, z);
    if (pod != null) {
      Icon podIcon = pod.getBlockTexture(world.getBlockMetadata(x, y, z), side);
      if (podIcon != null) {
        return podIcon;
      }
    }
    return defaultIcon;
  }

  public int getRenderType()
  {
    return PluginArboriculture.modelIdPods;
  }
}