package forestry.arboriculture.gadgets;

import forestry.arboriculture.WoodType;
import forestry.core.network.ForestryPacket;
import forestry.core.network.INetworkedEntity;
import forestry.core.network.PacketTileNBT;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyNetwork;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class TileStairs extends TileEntity
  implements INetworkedEntity
{
  private WoodType type;

  public WoodType getType()
  {
    return type;
  }

  public void setType(WoodType type) {
    this.type = type;
    sendNetworkUpdate();
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    if (nbttagcompound.hasKey("WT"))
      type = WoodType.VALUES[nbttagcompound.getShort("WT")];
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    if (type != null)
      nbttagcompound.setShort("WT", (short)type.ordinal());
  }

  public boolean canUpdate()
  {
    return false;
  }

  public Packet getDescriptionPacket()
  {
    return new PacketTileNBT(5, this).getPacket();
  }

  public void sendNetworkUpdate()
  {
    Proxies.net.sendNetworkPacket(new PacketTileNBT(5, this), xCoord, yCoord, zCoord);
  }

  public void fromPacket(ForestryPacket packetRaw)
  {
    PacketTileNBT packet = (PacketTileNBT)packetRaw;
    readFromNBT(packet.getTagCompound());
    worldObj.markBlockForRenderUpdate(xCoord, yCoord, zCoord);
  }
}