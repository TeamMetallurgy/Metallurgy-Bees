package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.arboriculture.IWoodTyped;
import forestry.arboriculture.WoodType;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public class BlockPlanks extends Block
  implements IWoodTyped
{
  private PlankCat cat;

  public BlockPlanks(int id, PlankCat cat)
  {
    super(id, Material.wood);
    this.cat = cat;
    setResistance(5.0F);
    setStepSound(soundWoodFootstep);
    setCreativeTab(Tabs.tabArboriculture);
  }

  public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    int count = cat == PlankCat.CAT0 ? 16 : 8;
    for (int i = 0; i < count; i++)
      itemList.add(new ItemStack(this, 1, i));
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    WoodType.registerIcons(register);
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int side, int meta)
  {
    return getWoodType(meta).getPlankIcon();
  }

  public int damageDropped(int meta)
  {
    return meta;
  }

  public float getBlockHardness(World world, int x, int y, int z)
  {
    return getWoodType(world.getBlockMetadata(x, y, z)).getHardness();
  }

  public boolean isWood(World world, int x, int y, int z)
  {
    return true;
  }

  public int getFlammability(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 20;
  }

  public boolean isFlammable(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return true;
  }

  public int getFireSpreadSpeed(World world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 5;
  }

  public WoodType getWoodType(int meta)
  {
    if (cat.ordinal() * 16 + meta < WoodType.VALUES.length) {
      return WoodType.VALUES[(cat.ordinal() * 16 + meta)];
    }
    return WoodType.LARCH;
  }

  public String getBlockKind()
  {
    return "planks";
  }

  public static enum PlankCat
  {
    CAT0, CAT1;
  }
}