package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.arboriculture.IWoodTyped;
import forestry.arboriculture.WoodType;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHalfSlab;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public class BlockSlab extends BlockHalfSlab
  implements IWoodTyped
{
  private SlabCat cat;

  public BlockSlab(int id, SlabCat cat)
  {
    super(id, false, Material.wood);
    this.cat = cat;
    setCreativeTab(Tabs.tabArboriculture);
    setLightOpacity(0);
    setHardness(2.0F);
    setResistance(5.0F);
    setStepSound(soundWoodFootstep);
    Block.useNeighborBrightness[id] = true;
  }

  public boolean isOpaqueCube()
  {
    return false;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    WoodType.registerIcons(register);
  }

  public Icon getIcon(int side, int meta)
  {
    WoodType type = WoodType.VALUES[(8 * cat.ordinal() + (meta & 0x7))];
    return type.getPlankIcon();
  }

  public int idDropped(int par1, Random par2Random, int par3)
  {
    return blockID;
  }

  public int idPicked(World world, int x, int y, int z)
  {
    return blockID;
  }

  public int getDamageValue(World world, int x, int y, int z)
  {
    return super.getDamageValue(world, x, y, z) & 0x7;
  }

  protected ItemStack createStackedBlock(int meta)
  {
    return new ItemStack(Block.woodSingleSlab.blockID, 2, meta & 0x7);
  }

  public String getFullSlabName(int var1)
  {
    return "SomeSlab";
  }

  public void getSubBlocks(int id, CreativeTabs par2CreativeTabs, List itemList)
  {
    for (int i = 0; i < 8; i++)
      itemList.add(new ItemStack(id, 1, i));
  }

  public int getFlammability(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 20;
  }

  public boolean isFlammable(IBlockAccess world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return true;
  }

  public int getFireSpreadSpeed(World world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return 5;
  }

  public WoodType getWoodType(int meta)
  {
    if (meta + cat.ordinal() * 8 < WoodType.VALUES.length) {
      return WoodType.VALUES[(meta + cat.ordinal() * 8)];
    }
    return WoodType.LARCH;
  }

  public String getBlockKind()
  {
    return "slab";
  }

  public static enum SlabCat
  {
    CAT0, CAT1, CAT2;
  }
}