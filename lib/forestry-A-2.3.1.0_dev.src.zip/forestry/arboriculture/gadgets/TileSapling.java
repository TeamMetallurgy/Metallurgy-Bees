package forestry.arboriculture.gadgets;

import forestry.api.arboriculture.IArboristTracker;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.arboriculture.ITreekeepingMode;
import forestry.plugins.PluginArboriculture;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class TileSapling extends TileTreeContainer
{
  private int timesTicked = 0;

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    timesTicked = nbttagcompound.getInteger("TT");
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    nbttagcompound.setInteger("TT", timesTicked);
  }

  public void onBlockTick()
  {
    timesTicked += 1;
    tryGrow(false);
  }

  public int tryGrow(boolean bonemealed)
  {
    int result = 0;
    if (getTree() == null) {
      return result;
    }
    int maturity = (int)(getTree().getRequiredMaturity() * PluginArboriculture.treeInterface.getTreekeepingMode(worldObj).getMaturationModifier(getTree().getGenome(), 1.0F));

    if ((bonemealed) && (timesTicked < maturity)) {
      timesTicked += 1;
      result = 1;
    }

    if (timesTicked < maturity) {
      return result;
    }
    WorldGenerator generator = getTree().getTreeGenerator(worldObj, xCoord, yCoord, zCoord, bonemealed);
    if (generator.generate(worldObj, worldObj.rand, xCoord, yCoord, zCoord)) {
      PluginArboriculture.treeInterface.getBreedingTracker(worldObj, getOwnerName()).registerBirth(getTree());
      return 2;
    }

    return 3;
  }
}