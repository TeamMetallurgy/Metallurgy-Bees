package forestry.arboriculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.arboriculture.EnumGermlingType;
import forestry.api.arboriculture.IAlleleFruit;
import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.IFruitProvider;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.core.IIconProvider;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.render.TextureManager;
import forestry.core.utils.StackUtils;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.Map;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSapling extends BlockTreeContainer
{

  @SideOnly(Side.CLIENT)
  private static Icon defaultIcon;

  public static TileSapling getSaplingTile(IBlockAccess world, int x, int y, int z)
  {
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileSapling)) {
      return null;
    }
    return (TileSapling)tile;
  }

  public BlockSapling(int id) {
    super(id, Material.plants);

    float factor = 0.4F;
    setBlockBounds(0.5F - factor, 0.0F, 0.5F - factor, 0.5F + factor, factor * 2.0F, 0.5F + factor);
    setStepSound(soundGrassFootstep);
  }

  public TileEntity createNewTileEntity(World var1)
  {
    return new TileSapling();
  }

  public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z)
  {
    return null;
  }

  public boolean isOpaqueCube()
  {
    return false;
  }

  public boolean renderAsNormalBlock()
  {
    return false;
  }

  public int getRenderType()
  {
    return PluginArboriculture.modelIdSaplings;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    defaultIcon = TextureManager.getInstance().registerTex(register, "germlings/sapling.treeBalsa");

    for (IAllele allele : AlleleManager.alleleRegistry.getRegisteredAlleles().values()) {
      if ((allele instanceof IAlleleTreeSpecies))
        ((IAlleleTreeSpecies)allele).getIconProvider().registerIcons(register);
      if ((allele instanceof IAlleleFruit))
        ((IAlleleFruit)allele).getProvider().registerIcons(register);
    }
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int side, int metadata)
  {
    return defaultIcon;
  }

  @SideOnly(Side.CLIENT)
  public Icon getBlockTexture(IBlockAccess world, int x, int y, int z, int side)
  {
    TileSapling sapling = getSaplingTile(world, x, y, z);
    if (sapling == null) {
      return defaultIcon;
    }
    if (sapling.getTree() == null) {
      return defaultIcon;
    }
    return sapling.getTree().getGenome().getPrimary().getGermlingIcon(EnumGermlingType.SAPLING, 0);
  }

  public boolean canBlockStay(World world, int x, int y, int z)
  {
    TileSapling tile = getSaplingTile(world, x, y, z);
    if (tile == null)
      return false;
    if (tile.getTree() == null) {
      return false;
    }
    return tile.getTree().canStay(world, x, y, z);
  }

  public void onNeighborBlockChange(World world, int x, int y, int z, int neighbourId)
  {
    if ((Proxies.common.isSimulating(world)) && (!canBlockStay(world, x, y, z))) {
      dropAsSapling(world, x, y, z);
      world.setBlock(x, y, z, 0, 0, 2);
    }
  }

  public ArrayList<ItemStack> getBlockDropped(World world, int x, int y, int z, int metadata, int fortune)
  {
    return new ArrayList();
  }

  public boolean removeBlockByPlayer(World world, EntityPlayer player, int x, int y, int z)
  {
    if ((Proxies.common.isSimulating(world)) && (canHarvestBlock(player, world.getBlockMetadata(x, y, z))) && 
      (!player.capabilities.isCreativeMode)) {
      dropAsSapling(world, x, y, z);
    }
    return world.setBlock(x, y, z, 0, 0, 2);
  }

  private void dropAsSapling(World world, int x, int y, int z) {
    if (!Proxies.common.isSimulating(world)) {
      return;
    }
    TileSapling sapling = getSaplingTile(world, x, y, z);
    if ((sapling != null) && (sapling.getTree() != null)) {
      ItemStack saplingStack = PluginArboriculture.treeInterface.getMemberStack(sapling.getTree(), EnumGermlingType.SAPLING.ordinal());
      StackUtils.dropItemStackAsEntity(saplingStack, world, x, y, z);
    }
  }
}