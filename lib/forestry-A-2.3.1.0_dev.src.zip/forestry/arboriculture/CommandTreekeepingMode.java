package forestry.arboriculture;

import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.IArboristTracker;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.arboriculture.ITreekeepingMode;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.core.config.Version;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.CommandMC;
import forestry.core.utils.StringUtil;
import forestry.plugins.PluginArboriculture;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;

public class CommandTreekeepingMode extends CommandMC
{
  String[] modeStrings;

  public CommandTreekeepingMode()
  {
    modeStrings = new String[PluginArboriculture.treeInterface.getTreekeepingModes().size()];
    for (int i = 0; i < PluginArboriculture.treeInterface.getTreekeepingModes().size(); i++)
      modeStrings[i] = ((ITreekeepingMode)PluginArboriculture.treeInterface.getTreekeepingModes().get(i)).getName();
  }

  public int compareTo(Object arg0)
  {
    return getCommandName().compareTo(((ICommand)arg0).getCommandName());
  }

  public String getCommandName()
  {
    return "treekeeping";
  }

  public String getCommandUsage(ICommandSender var1)
  {
    return "/" + getCommandName() + " help";
  }

  public List getCommandAliases()
  {
    return null;
  }

  public void processCommand(ICommandSender sender, String[] arguments)
  {
    if (arguments.length <= 0) {
      throw new WrongUsageException("Type '" + getCommandUsage(sender) + "' for help.", new Object[0]);
    }
    if (arguments[0].matches("list")) {
      listModes(sender, arguments);
    } else if (arguments[0].matches("info")) {
      listModeInfo(sender, arguments);
    } else if (arguments[0].matches("set")) {
      if (arguments.length <= 1) {
        throw new WrongUsageException("/" + getCommandName() + " set [<world-#>] <mode-name>", new Object[0]);
      }
      World world = getWorld(sender, arguments);
      String desired = arguments[(arguments.length - 1)];

      ITreekeepingMode mode = PluginArboriculture.treeInterface.getTreekeepingMode(desired);
      if (mode == null) {
        throw new CommandException("A treekeeping mode called '%s' is not available.", new Object[] { desired });
      }
      PluginArboriculture.treeInterface.setTreekeepingMode(world, mode.getName());
      notifyAdmins(sender, "Treekeeping mode set to %s.", new Object[] { mode.getName() });
    }
    else if (arguments[0].matches("save")) {
      if (arguments.length <= 1) {
        throw new WrongUsageException("/" + getCommandName() + " save <player-name>", new Object[0]);
      }
      saveStatistics(sender, arguments);
    } else if (arguments[0].matches("help")) {
      sendChatMessage(sender, "Format: '/" + getCommandName() + " <command> <arguments>'");
      sendChatMessage(sender, "Available commands:");
      sendChatMessage(sender, "- list [<world-#>]: lists current and available treekeeping modes.");
      sendChatMessage(sender, "- info <mode-name> : information on treekeeping mode.");
      sendChatMessage(sender, "- set [<world-#>] <mode-name>: set treekeeping mode for world.");
      sendChatMessage(sender, "- save [<world-#>] <player-name>: save treekeeping statistics for the given player.");
    }
  }

  private void saveStatistics(ICommandSender sender, String[] arguments)
  {
    String newLine = System.getProperty("line.separator");
    World world = getWorld(sender, arguments);

    String player = arguments[1];
    Collection statistics = new ArrayList();

    statistics.add(String.format("Treekeeping statistics for %s on %s:", new Object[] { player, DateFormat.getInstance().format(new Date()) }));
    statistics.add("");
    statistics.add("MODE: " + PluginArboriculture.treeInterface.getTreekeepingMode(world).getName());
    statistics.add("");

    IArboristTracker tracker = PluginArboriculture.treeInterface.getBreedingTracker(world, player);
    if (tracker == null) {
      statistics.add("No statistics found.");
    } else {
      statistics.add("BRED:");
      statistics.add("-----");
      statistics.add("");

      Collection species = new ArrayList();
      for (IAllele allele : AlleleManager.alleleRegistry.getRegisteredAlleles().values()) {
        if ((allele instanceof IAlleleTreeSpecies))
          species.add((IAlleleTreeSpecies)allele);
      }
      statistics.add(String.format("SPECIES (%s):", new Object[] { Integer.valueOf(species.size()) }));
      statistics.add("-------------");
      statistics.add("");

      for (IAlleleTreeSpecies allele : species) {
        statistics.add(generateSpeciesListEntry(allele, tracker));
      }
    }
    File file = new File(Proxies.common.getForestryRoot(), "config/" + "Forestry".toLowerCase(Locale.ENGLISH) + "/stats/" + player + ".log");
    try
    {
      if (file.getParentFile() != null) {
        file.getParentFile().mkdirs();
      }
      if ((!file.exists()) && (!file.createNewFile())) {
        sendChatMessage(sender, "Log file could not be created. Failed to save statistics.");
        return;
      }

      if (!file.canWrite()) {
        sendChatMessage(sender, "Cannot write to log file. Failed to save statistics.");
        return;
      }

      FileOutputStream fileout = new FileOutputStream(file);
      BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fileout, "UTF-8"));

      writer.write("# Forestry" + newLine + "# " + Version.getVersion() + newLine);

      for (String line : statistics) {
        writer.write(line + newLine);
      }
      writer.close();
    }
    catch (Exception ex) {
      sendChatMessage(sender, "Write operation threw an exception. Failed to save statistics.");
      ex.printStackTrace();
    }

    sendChatMessage(sender, "Saved statistics for player " + player);
  }

  private String generateSpeciesListEntry(IAlleleTreeSpecies species, IArboristTracker tracker) {
    String discovered = "[   ]";
    if (tracker.isDiscovered(species))
      discovered = "[ X ]";
    String blacklisted = "[    ]";
    if (AlleleManager.alleleRegistry.isBlacklisted(species.getUID()))
      blacklisted = "[ BL ]";
    String notcounted = "[    ]";
    if (!species.isCounted()) {
      notcounted = "[ NC ]";
    }
    return String.format("%s %s %s\t%-40s %-20s %-20s", new Object[] { discovered, blacklisted, notcounted, species.getUID(), species.getName(), species.getAuthority() });
  }

  private void listModes(ICommandSender sender, String[] arguments) {
    World world = getWorld(sender, arguments);

    sendChatMessage(sender, "Current: " + PluginArboriculture.treeInterface.getTreekeepingMode(world).getName() + " (#" + world.getWorldInfo().getSaveVersion() + ")");

    String help = "";
    for (ITreekeepingMode mode : PluginArboriculture.treeInterface.getTreekeepingModes()) {
      if (!help.isEmpty())
        help = help + ", ";
      help = help + mode.getName();
    }
    sendChatMessage(sender, "Available modes: " + help);
  }

  private void listModeInfo(ICommandSender sender, String[] arguments)
  {
    if (arguments.length <= 1) {
      throw new WrongUsageException("/" + getCommandName() + " info <mode-name>", new Object[0]);
    }
    ITreekeepingMode found = null;
    for (ITreekeepingMode mode : PluginArboriculture.treeInterface.getTreekeepingModes()) {
      if (mode.getName().equalsIgnoreCase(arguments[1])) {
        found = mode;
        break;
      }
    }
    if (found == null) {
      throw new CommandException("No treekeeping mode called '%s' is available.", new Object[] { arguments[1] });
    }
    sendChatMessage(sender, "§aMode: " + found.getName());
    for (String desc : found.getDescription())
      sendChatMessage(sender, StringUtil.localize(desc));
  }

  public boolean canCommandSenderUseCommand(ICommandSender sender)
  {
    if ((sender instanceof EntityPlayer)) {
      return Proxies.common.isOp((EntityPlayer)sender);
    }
    return sender.canCommandSenderUseCommand(4, getCommandName());
  }

  public List addTabCompletionOptions(ICommandSender sender, String[] incomplete)
  {
    return getListOfStringsMatchingLastWord(incomplete, modeStrings);
  }
}