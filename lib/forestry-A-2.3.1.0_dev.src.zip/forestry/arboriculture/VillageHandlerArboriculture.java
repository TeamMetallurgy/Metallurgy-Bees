package forestry.arboriculture;

import cpw.mods.fml.common.registry.VillagerRegistry.IVillageTradeHandler;
import forestry.api.arboriculture.EnumGermlingType;
import forestry.api.arboriculture.ITreeRoot;
import forestry.core.config.ForestryBlock;
import forestry.core.config.ForestryItem;
import forestry.plugins.PluginArboriculture;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;

public class VillageHandlerArboriculture
  implements VillagerRegistry.IVillageTradeHandler
{
  public void manipulateTradesForVillager(EntityVillager villager, MerchantRecipeList recipeList, Random random)
  {
    recipeList.add(new MerchantRecipe(new ItemStack(Item.emerald, 8), PluginArboriculture.treeInterface.getMemberStack(PluginArboriculture.treeInterface.getTree(villager.worldObj, PluginArboriculture.treeInterface.templateAsGenome(PluginArboriculture.treeInterface.getRandomTemplate(random))), EnumGermlingType.SAPLING.ordinal())));

    recipeList.add(new MerchantRecipe(new ItemStack(Item.emerald, 2), ForestryItem.grafterProven.getItemStack()));

    WoodType sells = WoodType.VALUES[random.nextInt(WoodType.VALUES.length)];
    int meta;
    Block plankBlock;
    int meta;
    if (!sells.hasPlank) {
      Block plankBlock = ForestryBlock.planks1;
      meta = 0;
    }
    else
    {
      int meta;
      if (sells.ordinal() > 15) {
        Block plankBlock = ForestryBlock.planks2;
        meta = sells.ordinal() - 16;
      } else {
        plankBlock = ForestryBlock.planks1;
        meta = sells.ordinal();
      }
    }
    recipeList.add(new MerchantRecipe(new ItemStack(Item.emerald, 1), new ItemStack(plankBlock, 32, meta)));
  }
}