package forestry.arboriculture.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.arboriculture.EnumGermlingType;
import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.core.Tabs;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IPollinatable;
import forestry.api.recipes.IVariableFermentable;
import forestry.arboriculture.genetics.Tree;
import forestry.core.config.Config;
import forestry.core.genetics.ItemGE;
import forestry.core.network.PacketFXSignal.SoundFXType;
import forestry.core.network.PacketFXSignal.VisualFXType;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.render.SpriteSheet;
import forestry.core.utils.Utils;
import forestry.plugins.PluginArboriculture;
import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.World;

public class ItemGermlingGE extends ItemGE
  implements IVariableFermentable
{
  private EnumGermlingType type;

  public ItemGermlingGE(int id, EnumGermlingType type)
  {
    super(id);
    this.type = type;
    setCreativeTab(Tabs.tabArboriculture);
  }

  protected IIndividual getIndividual(ItemStack itemstack)
  {
    return new Tree(itemstack.getTagCompound());
  }

  private IAlleleTreeSpecies getPrimarySpecies(ItemStack itemstack) {
    ITree tree = PluginArboriculture.treeInterface.getMember(itemstack);
    if (tree == null) {
      return (IAlleleTreeSpecies)PluginArboriculture.treeInterface.getDefaultTemplate()[forestry.api.arboriculture.EnumTreeChromosome.SPECIES.ordinal()];
    }
    return tree.getGenome().getPrimary();
  }

  protected int getDefaultPrimaryColour()
  {
    return 0;
  }

  protected int getDefaultSecondaryColour()
  {
    return 0;
  }

  public String getItemDisplayName(ItemStack itemstack)
  {
    if (!itemstack.hasTagCompound())
      return "Unknown";
    IIndividual individual = getIndividual(itemstack);
    return individual.getDisplayName() + " " + type.getName();
  }

  public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    addCreativeItems(itemList, true);
  }

  public void addCreativeItems(List itemList, boolean hideSecrets) {
    for (IIndividual individual : PluginArboriculture.treeInterface.getIndividualTemplates())
    {
      if ((!hideSecrets) || (!individual.isSecret()) || (Config.isDebug))
      {
        itemList.add(PluginArboriculture.treeInterface.getMemberStack((ITree)individual, type.ordinal()));
      }
    }
  }

  public int getColorFromItemStack(ItemStack itemstack, int renderPass) {
    return getPrimarySpecies(itemstack).getGermlingColour(type, renderPass);
  }

  public boolean requiresMultipleRenderPasses()
  {
    return true;
  }

  public int getRenderPasses(int metadata)
  {
    return 2;
  }

  public int getSpriteNumber()
  {
    return type == EnumGermlingType.SAPLING ? SpriteSheet.BLOCKS.getSheetOrdinal() : SpriteSheet.ITEMS.getSheetOrdinal();
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(ItemStack itemstack, int renderPass)
  {
    IAlleleTreeSpecies species = getPrimarySpecies(itemstack);
    return species.getGermlingIcon(type, renderPass);
  }

  public boolean onItemUse(ItemStack itemstack, EntityPlayer player, World world, int x, int y, int z, int par7, float facingX, float facingY, float facingZ)
  {
    if (!Proxies.common.isSimulating(world)) {
      return false;
    }
    ITree tree = PluginArboriculture.treeInterface.getMember(itemstack);
    if (tree == null) {
      return false;
    }
    if (type == EnumGermlingType.SAPLING)
    {
      int yShift;
      int yShift;
      if (!Utils.isReplaceableBlock(world, x, y, z)) {
        if (!world.isAirBlock(x, y + 1, z))
          return false;
        yShift = 1;
      } else {
        yShift = 0;
      }
      if (!tree.canStay(world, x, y + yShift, z)) {
        return false;
      }
      if (PluginArboriculture.treeInterface.plantSapling(world, tree, player.username, x, y + yShift, z)) {
        Proxies.common.addBlockPlaceEffects(world, x, y, z, world.getBlockId(x, y + yShift, z), 0);
        if (!player.capabilities.isCreativeMode)
          itemstack.stackSize -= 1;
        return true;
      }
      return false;
    }if (type == EnumGermlingType.POLLEN)
    {
      TileEntity target = world.getBlockTileEntity(x, y, z);
      if (!(target instanceof IPollinatable)) {
        return false;
      }
      IPollinatable pollinatable = (IPollinatable)target;
      if (!pollinatable.canMateWith(tree)) {
        return false;
      }
      pollinatable.mateWith(tree);
      Proxies.common.sendFXSignal(PacketFXSignal.VisualFXType.BLOCK_DESTROY, PacketFXSignal.SoundFXType.LEAF, world, x, y, z, world.getBlockId(x, y, z), 0);

      if (!player.capabilities.isCreativeMode)
        itemstack.stackSize -= 1;
      return true;
    }

    return false;
  }

  public float getFermentationModifier(ItemStack itemstack)
  {
    ITree tree = PluginArboriculture.treeInterface.getMember(itemstack);
    if (tree == null) {
      return 1.0F;
    }
    return tree.getGenome().getSappiness() * 10.0F;
  }
}