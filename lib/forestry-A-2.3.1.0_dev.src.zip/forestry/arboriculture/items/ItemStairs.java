package forestry.arboriculture.items;

import forestry.arboriculture.WoodType;
import forestry.arboriculture.gadgets.TileStairs;
import forestry.core.config.ForestryBlock;
import forestry.core.items.ItemForestryBlock;
import forestry.core.utils.StringUtil;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class ItemStairs extends ItemForestryBlock
{
  public ItemStairs(int i)
  {
    super(i);
  }

  public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata)
  {
    WoodType type = WoodType.getFromCompound(stack.getTagCompound());
    return placeStairs(world, player, stack, type, x, y, z, metadata);
  }

  private boolean placeStairs(World world, EntityPlayer player, ItemStack stack, WoodType type, int x, int y, int z, int metadata)
  {
    boolean placed = world.setBlock(x, y, z, ForestryBlock.stairs.blockID, metadata, 2);
    if (!placed) {
      return false;
    }
    if (world.getBlockId(x, y, z) != ForestryBlock.stairs.blockID) {
      return false;
    }
    Block.blocksList[world.getBlockId(x, y, z)].onBlockPlacedBy(world, x, y, z, player, stack);
    Block.blocksList[world.getBlockId(x, y, z)].onPostBlockPlaced(world, x, y, z, metadata);

    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if (!(tile instanceof TileStairs)) {
      world.setBlock(x, y, z, 0, 0, 2);
      return false;
    }

    ((TileStairs)tile).setType(type);
    return true;
  }

  private String getWoodNameIS(WoodType type) {
    return StringUtil.localize("wood." + type.ordinal());
  }

  public String getItemDisplayName(ItemStack itemstack)
  {
    WoodType type = WoodType.getFromCompound(itemstack.getTagCompound());

    return getWoodNameIS(type) + " " + StringUtil.localize(getUnlocalizedName());
  }
}