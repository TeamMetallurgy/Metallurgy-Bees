package forestry.arboriculture.items;

import forestry.api.arboriculture.IToolGrafter;
import forestry.api.core.Tabs;
import forestry.core.items.ItemForestry;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;

public class ItemGrafter extends ItemForestry
  implements IToolGrafter
{
  private float efficiencyOnProperMaterial;

  public ItemGrafter(int i, int maxDamage)
  {
    super(i);
    setMaxStackSize(1);
    efficiencyOnProperMaterial = 4.0F;
    setMaxDamage(maxDamage);
    setCreativeTab(Tabs.tabArboriculture);
  }

  public float getStrVsBlock(ItemStack itemstack, Block block)
  {
    return 1.0F;
  }

  public float getStrVsBlock(ItemStack itemstack, Block block, int md)
  {
    if (ForgeHooks.isToolEffective(itemstack, block, md)) {
      return efficiencyOnProperMaterial;
    }
    return getStrVsBlock(itemstack, block);
  }

  public boolean onBlockDestroyed(ItemStack itemstack, World world, int i, int j, int k, int l, EntityLivingBase entityliving)
  {
    return true;
  }

  public float getDamageVsEntity(Entity entity, ItemStack itemstack)
  {
    return 1.0F;
  }

  public boolean isFull3D() {
    return true;
  }

  public float getSaplingModifier(ItemStack stack, World world, EntityPlayer player, int x, int y, int z)
  {
    return 100.0F;
  }
}