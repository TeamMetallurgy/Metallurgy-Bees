package forestry.arboriculture;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.arboriculture.IFruitProvider;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.genetics.IFruitFamily;
import forestry.core.render.TextureManager;
import java.util.HashMap;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.ItemStack;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class FruitProviderNone
  implements IFruitProvider
{
  private static HashMap<String, OverlayType> overlayTypes = new HashMap();
  String key;
  IFruitFamily family = null;

  int ripeningPeriod = 10;

  OverlayType overlay = null;

  public FruitProviderNone(String key, IFruitFamily family) {
    this.key = key;
    this.family = family;
  }

  public IFruitProvider setOverlay(String ident) {
    overlay = ((OverlayType)overlayTypes.get(ident));
    return this;
  }

  public IFruitFamily getFamily()
  {
    return family;
  }

  public ItemStack[] getFruits(ITreeGenome genome, World world, int x, int y, int z, int ripeningTime)
  {
    return new ItemStack[0];
  }

  public boolean requiresFruitBlocks()
  {
    return false;
  }

  public boolean trySpawnFruitBlock(ITreeGenome genome, World world, int x, int y, int z)
  {
    return false;
  }

  public int getColour(ITreeGenome genome, IBlockAccess world, int x, int y, int z, int ripeningTime)
  {
    return 16777215;
  }

  public boolean markAsFruitLeaf(ITreeGenome genome, World world, int x, int y, int z)
  {
    return false;
  }

  public int getRipeningPeriod()
  {
    return ripeningPeriod;
  }

  public ItemStack[] getProducts()
  {
    return new ItemStack[0];
  }

  public ItemStack[] getSpecialty()
  {
    return new ItemStack[0];
  }

  public String getDescription()
  {
    return "fruits." + key;
  }

  public short getIconIndex(ITreeGenome genome, IBlockAccess world, int x, int y, int z, int ripeningTime, boolean fancy)
  {
    if (overlay != null) {
      return overlay.texUID;
    }
    return -1;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    if (overlay != null)
      TextureManager.getInstance().registerTexUID(register, overlay.texUID, "leaves/fruits." + overlay.ident);
  }

  static
  {
    overlayTypes.put("berries", new OverlayType("berries", (short)1000));
    overlayTypes.put("pomes", new OverlayType("pomes", (short)1001));
    overlayTypes.put("nuts", new OverlayType("nuts", (short)1002));
    overlayTypes.put("citrus", new OverlayType("citrus", (short)1003));
    overlayTypes.put("plums", new OverlayType("plums", (short)1004));
  }

  private static class OverlayType
  {
    public final String ident;
    public final short texUID;

    public OverlayType(String ident, short texUID)
    {
      this.ident = ident;
      this.texUID = texUID;
    }
  }
}