package forestry.arboriculture;

public abstract interface IWoodTyped
{
  public abstract WoodType getWoodType(int paramInt);

  public abstract String getBlockKind();
}