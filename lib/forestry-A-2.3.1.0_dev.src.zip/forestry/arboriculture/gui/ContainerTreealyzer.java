package forestry.arboriculture.gui;

import forestry.arboriculture.items.ItemGermlingGE;
import forestry.arboriculture.items.ItemTreealyzer.TreealyzerInventory;
import forestry.core.config.ForestryItem;
import forestry.core.gui.ContainerItemInventory;
import forestry.core.gui.slots.SlotCustom;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;

public class ContainerTreealyzer extends ContainerItemInventory
{
  ItemTreealyzer.TreealyzerInventory inventory;

  public ContainerTreealyzer(InventoryPlayer inventoryplayer, ItemTreealyzer.TreealyzerInventory inventory)
  {
    super(inventory, inventoryplayer.player);

    this.inventory = inventory;

    addSlot(new SlotCustom(inventory, 5, 172, 8, new Object[] { ForestryItem.honeydew, ForestryItem.honeyDrop }));

    addSlot(new SlotCustom(inventory, 0, 172, 26, new Object[] { ItemGermlingGE.class, Block.sapling }));

    addSlot(new SlotCustom(inventory, 1, 172, 57, new Object[] { ItemGermlingGE.class }));
    addSlot(new SlotCustom(inventory, 2, 172, 75, new Object[] { ItemGermlingGE.class }));
    addSlot(new SlotCustom(inventory, 3, 172, 93, new Object[] { ItemGermlingGE.class }));
    addSlot(new SlotCustom(inventory, 4, 172, 111, new Object[] { ItemGermlingGE.class }));
    addSlot(new SlotCustom(inventory, 6, 172, 129, new Object[] { ItemGermlingGE.class }));

    for (int i1 = 0; i1 < 3; i1++) {
      for (int l1 = 0; l1 < 9; l1++)
        addSecuredSlot(inventoryplayer, l1 + i1 * 9 + 9, 18 + l1 * 18, 156 + i1 * 18);
    }
    for (int j1 = 0; j1 < 9; j1++)
      addSecuredSlot(inventoryplayer, j1, 18 + j1 * 18, 214);
  }

  public void onContainerClosed(EntityPlayer entityplayer)
  {
    if (!Proxies.common.isSimulating(entityplayer.worldObj)) {
      return;
    }

    for (int i = 0; i < inventory.getSizeInventory(); i++)
      if (i != 5)
      {
        ItemStack stack = inventory.getStackInSlot(i);
        if (stack != null)
        {
          Proxies.common.dropItemPlayer(entityplayer, stack);
          inventory.setInventorySlotContents(i, null);
        }
      }
    inventory.onGuiSaved(entityplayer);
  }

  protected boolean isAcceptedItem(EntityPlayer player, ItemStack stack)
  {
    return true;
  }
}