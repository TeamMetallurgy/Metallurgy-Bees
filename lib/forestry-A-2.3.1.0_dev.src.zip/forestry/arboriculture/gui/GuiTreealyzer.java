package forestry.arboriculture.gui;

import forestry.api.arboriculture.EnumTreeChromosome;
import forestry.api.arboriculture.IAlleleFruit;
import forestry.api.arboriculture.IAlleleGrowth;
import forestry.api.arboriculture.IAlleleLeafEffect;
import forestry.api.arboriculture.IAlleleTreeSpecies;
import forestry.api.arboriculture.IFruitProvider;
import forestry.api.arboriculture.IGrowthProvider;
import forestry.api.arboriculture.ITree;
import forestry.api.arboriculture.ITreeGenome;
import forestry.api.arboriculture.ITreeRoot;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleEffect;
import forestry.api.genetics.IAlleleFloat;
import forestry.api.genetics.IAlleleInteger;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IFruitFamily;
import forestry.arboriculture.items.ItemGermlingGE;
import forestry.arboriculture.items.ItemTreealyzer.TreealyzerInventory;
import forestry.core.config.ForestryItem;
import forestry.core.genetics.Allele;
import forestry.core.genetics.AllelePlantType;
import forestry.core.gui.GuiAlyzer;
import forestry.core.utils.FontColour;
import forestry.core.utils.StringUtil;
import forestry.plugins.PluginArboriculture;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.EnumPlantType;

public class GuiTreealyzer extends GuiAlyzer
{
  private ItemStack[] tempProductList;

  public GuiTreealyzer(EntityPlayer player, ItemTreealyzer.TreealyzerInventory inventory)
  {
    super(AlleleManager.alleleRegistry.getSpeciesRoot("rootTrees"), player, new ContainerTreealyzer(player.inventory, inventory), inventory, 1, inventory.getSizeInventory());

    xSize = 196;
    ySize = 238;

    ArrayList treeList = new ArrayList();
    ((ItemGermlingGE)ForestryItem.sapling.item()).addCreativeItems(treeList, false);
    for (ItemStack beeStack : treeList)
      iconStacks.put(PluginArboriculture.treeInterface.getMember(beeStack).getIdent(), beeStack);
  }

  protected void drawGuiContainerBackgroundLayer(float var1, int mouseX, int mouseY)
  {
    super.drawGuiContainerBackgroundLayer(var1, mouseX, mouseY);

    int page = 0;
    ITree tree = null;
    for (int k = 1; k < 7; k++)
      if (k != 5)
      {
        if (inventory.getStackInSlot(k) != null)
        {
          tree = PluginArboriculture.treeInterface.getMember(inventory.getStackInSlot(k));
          if ((tree != null) && (tree.isAnalyzed()))
          {
            page = k;
            break;
          }
        }
      }
    switch (page) {
    case 1:
      drawAnalyticsPage1(tree);
      break;
    case 2:
      drawAnalyticsPage2(tree);
      break;
    case 3:
      drawAnalyticsPage3(tree);
      break;
    case 4:
      drawAnalyticsPage4(tree);
      break;
    case 6:
      drawAnalyticsPageClassification(tree);
      break;
    case 5:
    default:
      drawAnalyticsOverview();
    }
  }

  private void drawAnalyticsOverview()
  {
    startPage();

    newLine();
    String title = StringUtil.localize("gui.treealyzer").toUpperCase();
    drawCenteredLine(title, 8, 158);
    newLine();

    fontRenderer.drawSplitString(StringUtil.localize("gui.treealyzer.help"), (int)((guiLeft + 12 + 4) * (1.0F / factor)), (int)((guiTop + 42) * (1.0F / factor)), (int)(158.0F * (1.0F / factor)), fontColor.get("gui.screen"));

    newLine();
    newLine();
    newLine();
    newLine();

    drawLine(StringUtil.localize("gui.treealyzer.overview") + ":", 16);
    newLine();
    drawLine("I  : " + StringUtil.localize("gui.general"), 16);
    newLine();
    drawLine("II : " + StringUtil.localize("gui.environment"), 16);
    newLine();
    drawLine("III: " + StringUtil.localize("gui.produce"), 16);
    newLine();
    drawLine("IV : " + StringUtil.localize("gui.evolution"), 16);

    endPage();
  }

  private void drawAnalyticsPage1(ITree tree)
  {
    startPage(12, 52, 108);

    drawLine(StringUtil.localize("gui.active"), 52);
    drawLine(StringUtil.localize("gui.inactive"), 108);

    newLine();
    newLine();

    drawSpeciesRow(StringUtil.localize("gui.species"), tree, EnumTreeChromosome.SPECIES);
    newLine();

    drawLine(StringUtil.localize("gui.saplings"), 12);
    drawLine(tree.getGenome().getActiveAllele(EnumTreeChromosome.FERTILITY.ordinal()).getName(), 52, tree, EnumTreeChromosome.FERTILITY, false);
    drawLine(tree.getGenome().getInactiveAllele(EnumTreeChromosome.FERTILITY.ordinal()).getName(), 108, tree, EnumTreeChromosome.FERTILITY, true);

    newLine();

    drawRow(StringUtil.localize("gui.maturity"), tree.getGenome().getActiveAllele(EnumTreeChromosome.MATURATION.ordinal()).getName(), tree.getGenome().getInactiveAllele(EnumTreeChromosome.MATURATION.ordinal()).getName(), tree, EnumTreeChromosome.MATURATION);

    drawLine(StringUtil.localize("gui.height"), 12);
    drawLine(tree.getGenome().getActiveAllele(EnumTreeChromosome.HEIGHT.ordinal()).getName(), 52, tree, EnumTreeChromosome.HEIGHT, false);
    drawLine(tree.getGenome().getInactiveAllele(EnumTreeChromosome.HEIGHT.ordinal()).getName(), 108, tree, EnumTreeChromosome.HEIGHT, true);

    newLine();

    drawLine(StringUtil.localize("gui.girth"), 12);
    drawLine(String.format("%sx%s", new Object[] { Integer.valueOf(tree.getGenome().getGirth()), Integer.valueOf(tree.getGenome().getGirth()) }), 52, tree, EnumTreeChromosome.FERTILITY, false);
    int secondGirth = ((IAlleleInteger)tree.getGenome().getInactiveAllele(EnumTreeChromosome.GIRTH.ordinal())).getValue();
    drawLine(String.format("%sx%s", new Object[] { Integer.valueOf(secondGirth), Integer.valueOf(secondGirth) }), 108, tree, EnumTreeChromosome.FERTILITY, true);

    newLine();

    drawLine(StringUtil.localize("gui.yield"), 12);
    drawLine(tree.getGenome().getActiveAllele(EnumTreeChromosome.YIELD.ordinal()).getName(), 52, tree, EnumTreeChromosome.YIELD, false);
    drawLine(tree.getGenome().getInactiveAllele(EnumTreeChromosome.YIELD.ordinal()).getName(), 108, tree, EnumTreeChromosome.YIELD, true);

    newLine();

    drawLine(StringUtil.localize("gui.sappiness"), 12);
    drawLine(tree.getGenome().getActiveAllele(EnumTreeChromosome.SAPPINESS.ordinal()).getName(), 52, tree, EnumTreeChromosome.SAPPINESS, false);

    IAllele sappiness = tree.getGenome().getInactiveAllele(EnumTreeChromosome.SAPPINESS.ordinal());
    String sap;
    String sap;
    if ((sappiness instanceof IAlleleFloat))
      sap = sappiness.getName();
    else {
      sap = Allele.saplingsLowest.getName();
    }
    drawLine(sap, 108, tree, EnumTreeChromosome.SAPPINESS, true);

    newLine();

    drawRow(StringUtil.localize("gui.effect"), StringUtil.localize(tree.getGenome().getEffect().getName()), StringUtil.localize(((IAlleleEffect)tree.getGenome().getInactiveAllele(EnumTreeChromosome.EFFECT.ordinal())).getName()), tree, EnumTreeChromosome.EFFECT);

    newLine();
    newLine();

    endPage();
  }

  private void drawAnalyticsPage2(ITree tree)
  {
    startPage();

    int speciesDominance0 = getColorCoding(tree.getGenome().getPrimary().isDominant());
    int speciesDominance1 = getColorCoding(tree.getGenome().getSecondary().isDominant());

    drawLine(StringUtil.localize("gui.active"), 52);
    drawLine(StringUtil.localize("gui.inactive"), 108);

    newLine();
    newLine();

    drawLine(StringUtil.localize("gui.growth"), 12);
    drawLine(tree.getGenome().getGrowthProvider().getDescription(), 52, tree, EnumTreeChromosome.GROWTH, false);
    drawLine(((IAlleleGrowth)tree.getGenome().getInactiveAllele(EnumTreeChromosome.GROWTH.ordinal())).getProvider().getDescription(), 108, tree, EnumTreeChromosome.GROWTH, true);

    newLine();

    drawLine(StringUtil.localize("gui.native"), 12);
    drawLine(StringUtil.localize("gui." + tree.getGenome().getPrimary().getPlantType().toString().toLowerCase(Locale.ENGLISH)), 52, speciesDominance0);

    drawLine(StringUtil.localize("gui." + tree.getGenome().getSecondary().getPlantType().toString().toLowerCase(Locale.ENGLISH)), 108, speciesDominance1);

    newLine();

    drawLine(StringUtil.localize("gui.tolerated"), 12);

    EnumPlantType[] tolerated0 = (EnumPlantType[])tree.getGenome().getPlantTypes().toArray(new EnumPlantType[0]);
    EnumPlantType[] tolerated1 = new EnumPlantType[0];
    IAllele allele1 = tree.getGenome().getInactiveAllele(EnumTreeChromosome.PLANT.ordinal());
    if ((allele1 instanceof AllelePlantType)) {
      tolerated1 = (EnumPlantType[])((AllelePlantType)allele1).getPlantTypes().toArray(new EnumPlantType[0]);
    }
    int max = tolerated0.length > tolerated1.length ? tolerated0.length : tolerated1.length;
    for (int i = 0; i < max; i++) {
      if (i > 0)
        newLine();
      if (tolerated0.length > i)
        drawLine(StringUtil.localize("gui." + tolerated0[i].toString().toLowerCase(Locale.ENGLISH)), 52, tree, EnumTreeChromosome.PLANT, false);
      if (tolerated1.length > i)
        drawLine(StringUtil.localize("gui." + tolerated1[i].toString().toLowerCase(Locale.ENGLISH)), 108, tree, EnumTreeChromosome.PLANT, true);
    }
    newLine();

    drawLine(StringUtil.localize("gui.supports"), 12);
    IFruitFamily[] families0 = (IFruitFamily[])tree.getGenome().getPrimary().getSuitableFruit().toArray(new IFruitFamily[0]);
    IFruitFamily[] families1 = (IFruitFamily[])tree.getGenome().getPrimary().getSuitableFruit().toArray(new IFruitFamily[0]);

    max = families0.length > families1.length ? families0.length : families1.length;
    for (int i = 0; i < max; i++) {
      if (i > 0) {
        newLine();
      }
      if (families0.length > i)
        drawLine(StringUtil.localize(families0[i].getName()), 52, speciesDominance0);
      if (families1.length > i) {
        drawLine(StringUtil.localize(families1[i].getName()), 108, speciesDominance1);
      }
    }

    newLine();
    newLine();

    int fruitDominance0 = getColorCoding(tree.getGenome().getActiveAllele(EnumTreeChromosome.FRUITS.ordinal()).isDominant());
    int fruitDominance1 = getColorCoding(tree.getGenome().getInactiveAllele(EnumTreeChromosome.FRUITS.ordinal()).isDominant());

    drawLine(StringUtil.localize("gui.fruits"), 12);
    String strike = "";
    IAllele fruit0 = tree.getGenome().getActiveAllele(EnumTreeChromosome.FRUITS.ordinal());
    if ((!tree.canBearFruit()) && (fruit0 != Allele.fruitNone))
      strike = "§m";
    drawLine(strike + StringUtil.localize(tree.getGenome().getFruitProvider().getDescription()), 52, fruitDominance0);

    strike = "";
    IAllele fruit1 = tree.getGenome().getInactiveAllele(EnumTreeChromosome.FRUITS.ordinal());
    if ((!tree.getGenome().getSecondary().getSuitableFruit().contains(((IAlleleFruit)fruit1).getProvider().getFamily())) && (fruit1 != Allele.fruitNone))
      strike = "§m";
    drawLine(strike + StringUtil.localize(((IAlleleFruit)fruit1).getProvider().getDescription()), 108, fruitDominance1);

    newLine();

    drawLine(StringUtil.localize("gui.family"), 12);
    IFruitFamily primary = tree.getGenome().getFruitProvider().getFamily();
    IFruitFamily secondary = ((IAlleleFruit)tree.getGenome().getInactiveAllele(EnumTreeChromosome.FRUITS.ordinal())).getProvider().getFamily();

    if (primary != null)
      drawLine(StringUtil.localize(primary.getName()), 52, fruitDominance0);
    if (secondary != null) {
      drawLine(StringUtil.localize(secondary.getName()), 108, fruitDominance1);
    }
    endPage();
  }

  private void drawAnalyticsPage3(ITree tree)
  {
    tempProductList = tree.getProduceList();

    startPage(12, 52, 108);

    drawLine(StringUtil.localize("gui.beealyzer.produce") + ":", 12);
    newLine();

    int x = 12;
    for (ItemStack stack : tempProductList) {
      itemRenderer.renderItemIntoGUI(fontRenderer, mc.renderEngine, stack, (int)((guiLeft + x) * (1.0F / factor)), (int)((guiTop + getLineY()) * (1.0F / factor)));

      x += 18;
      if (x > adjustToFactor(148)) {
        x = 12;
        newLine();
      }
    }

    newLine();
    newLine();

    drawLine(StringUtil.localize("gui.beealyzer.specialty") + ":", 12);
    newLine();

    x = 12;
    for (ItemStack stack : tree.getSpecialtyList()) {
      itemRenderer.renderItemIntoGUI(fontRenderer, mc.renderEngine, stack, (int)((guiLeft + x) * (1.0F / factor)), (int)((guiTop + getLineY()) * (1.0F / factor)));

      x += 18;
      if (x > adjustToFactor(148)) {
        x = 12;
        newLine();
      }
    }

    endPage();
  }
}