package forestry.apiculture;

import forestry.api.genetics.IAlleleSpecies;
import net.minecraft.command.CommandException;

public class TemplateNotFoundException extends CommandException
{
  private static final long serialVersionUID = 1L;

  public TemplateNotFoundException(IAlleleSpecies species)
  {
    super("Could not find template for species %s with UID %s", new Object[] { species.getName(), species.getUID() });
  }
}