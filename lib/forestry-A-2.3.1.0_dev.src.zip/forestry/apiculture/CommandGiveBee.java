package forestry.apiculture;

import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IAlleleSpecies;
import forestry.core.utils.CommandMC;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class CommandGiveBee extends CommandMC
{
  EnumBeeType type;

  public CommandGiveBee(EnumBeeType type)
  {
    this.type = type;
  }

  public String getCommandName() {
    return "give" + type.toString().toLowerCase();
  }

  public String getCommandUsage(ICommandSender par1ICommandSender) {
    return "/" + getCommandName() + " <player-name> <species-name>";
  }

  public void processCommand(ICommandSender sender, String[] arguments) {
    if (arguments.length >= 2)
    {
      EntityPlayer player = getPlayerFromName(arguments[0]);

      String parameter = arguments[1];

      IAlleleBeeSpecies species = null;

      for (String uid : AlleleManager.alleleRegistry.getRegisteredAlleles().keySet())
      {
        if (uid.equals(parameter))
        {
          if ((AlleleManager.alleleRegistry.getAllele(uid) instanceof IAlleleBeeSpecies)) {
            species = (IAlleleBeeSpecies)AlleleManager.alleleRegistry.getAllele(uid);
            break;
          }
        }
      }
      if (species == null) {
        for (IAllele allele : AlleleManager.alleleRegistry.getRegisteredAlleles().values())
          if (((allele instanceof IAlleleBeeSpecies)) && 
            (((IAlleleBeeSpecies)allele).getName().equals(parameter))) {
            species = (IAlleleBeeSpecies)allele;
            break;
          }
      }
      if (species == null) {
        throw new SpeciesNotFoundException(parameter);
      }
      IAllele[] template = PluginApiculture.beeInterface.getTemplate(species.getUID());

      if (template == null) {
        throw new TemplateNotFoundException(species);
      }
      IBeeGenome genome = PluginApiculture.beeInterface.templateAsGenome(template);

      IBee bee = PluginApiculture.beeInterface.getBee(player.worldObj, genome);

      ItemStack beestack = PluginApiculture.beeInterface.getMemberStack(bee, type.ordinal());
      player.dropPlayerItem(beestack);
      notifyAdmins(sender, "Player %s was given a %s bee.", new Object[] { player.getEntityName(), ((IAlleleSpecies)template[0]).getName() });
    } else {
      throw new WrongUsageException("/" + getCommandName() + " <player-name> <species-name>", new Object[0]);
    }
  }

  public List addTabCompletionOptions(ICommandSender sender, String[] parameters)
  {
    if (parameters.length == 1)
      return getListOfStringsMatchingLastWord(parameters, getPlayers());
    if (parameters.length == 2) {
      return getListOfStringsMatchingLastWord(parameters, getSpecies());
    }
    return null;
  }

  protected String[] getSpecies() {
    List species = new ArrayList();

    for (IAllele allele : AlleleManager.alleleRegistry.getRegisteredAlleles().values()) {
      if ((allele instanceof IAlleleBeeSpecies))
        species.add(((IAlleleSpecies)allele).getName());
    }
    return (String[])species.toArray(new String[0]);
  }
}