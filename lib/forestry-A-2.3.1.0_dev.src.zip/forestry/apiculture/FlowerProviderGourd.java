package forestry.apiculture;

import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IPollinatable;
import forestry.core.utils.StringUtil;
import java.util.EnumSet;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.EnumPlantType;

public class FlowerProviderGourd
  implements IFlowerProvider
{
  public boolean isAcceptedFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);
    return (blockid == Block.pumpkinStem.blockID) || (blockid == Block.melonStem.blockID);
  }

  public boolean isAcceptedPollinatable(World world, IPollinatable pollinatable)
  {
    EnumSet types = pollinatable.getPlantType();
    return (types.size() > 1) || (!types.contains(EnumPlantType.Nether));
  }

  public boolean growFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);

    if ((blockid != Block.pumpkinStem.blockID) && (blockid != Block.melonStem.blockID)) {
      return false;
    }
    int meta = world.getBlockMetadata(x, y, z);
    if (meta > 6) {
      return false;
    }
    if (meta < 6)
      meta += 2;
    else {
      meta = 7;
    }
    world.setBlockMetadataWithNotify(x, y, z, meta, 2);
    return true;
  }

  public String getDescription()
  {
    return StringUtil.localize("flowers.gourd");
  }

  public ItemStack[] affectProducts(World world, IIndividual individual, int x, int y, int z, ItemStack[] products)
  {
    return products;
  }

  public ItemStack[] getItemStacks()
  {
    return new ItemStack[] { new ItemStack(Block.crops, 1, 8) };
  }
}