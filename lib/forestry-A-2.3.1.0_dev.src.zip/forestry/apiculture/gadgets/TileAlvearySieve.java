package forestry.apiculture.gadgets;

import forestry.api.apiculture.IAlvearyComponent;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeListener;
import forestry.api.arboriculture.EnumGermlingType;
import forestry.api.core.ForestryAPI;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.ISpeciesRoot;
import forestry.core.interfaces.ICrafter;
import forestry.core.network.GuiId;
import forestry.core.utils.InventoryAdapter;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class TileAlvearySieve extends TileAlveary
  implements ICrafter, IBeeListener
{
  public static final int BLOCK_META = 7;
  public static final int SLOT_POLLEN_1 = 0;
  public static final int SLOTS_POLLEN_COUNT = 4;
  public static final int SLOT_SIEVE = 4;
  InventoryAdapter inventory = new InventoryAdapter(5, "Items", 1);

  public TileAlvearySieve() {
    super(7);
  }

  public void openGui(EntityPlayer player)
  {
    player.openGui(ForestryAPI.instance, GuiId.AlvearySieveGUI.ordinal(), worldObj, xCoord, yCoord, zCoord);
  }

  public String getInvName()
  {
    return "tile.alveary.7";
  }

  public boolean hasFunction()
  {
    return true;
  }

  public void initialize()
  {
    super.initialize();

    if ((!hasMaster()) || (!isIntegratedIntoStructure())) {
      return;
    }
    ((IAlvearyComponent)getCentralTE()).registerBeeListener(this);
  }

  protected void updateServerSide()
  {
    super.updateServerSide();
    if (worldObj.getTotalWorldTime() % 200L != 0L) {
      return;
    }
    if ((!hasMaster()) || (!isIntegratedIntoStructure())) {
      return;
    }
    ((IAlvearyComponent)getCentralTE()).registerBeeListener(this);
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);
    inventory.readFromNBT(nbttagcompound);
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);
    inventory.writeToNBT(nbttagcompound);
  }

  public int getBlockTexture(int side, int metadata)
  {
    if ((side == 0) || (side == 1))
      return 2;
    return 13;
  }

  private void destroySieve() {
    inventory.setInventorySlotContents(4, null);
  }
  private void destroyPollen() {
    for (int i = 0; i < 4; i++)
      inventory.setInventorySlotContents(i, null);
  }

  private boolean canStorePollen()
  {
    if (inventory.getStackInSlot(4) == null) {
      return false;
    }
    for (int i = 0; i < 4; i++) {
      if (inventory.getStackInSlot(i) == null) {
        return true;
      }
    }
    return false;
  }

  private void storePollenStack(ItemStack itemstack) {
    for (int i = 0; i < 4; i++)
      if (inventory.getStackInSlot(i) == null) {
        inventory.setInventorySlotContents(i, itemstack);
        return;
      }
  }

  public InventoryAdapter getInternalInventory()
  {
    return inventory;
  }

  public boolean canTakeStack(int slotIndex)
  {
    return true;
  }

  public ItemStack takenFromSlot(int slotIndex, boolean consumeRecipe, EntityPlayer player)
  {
    if (slotIndex == 4) {
      destroyPollen();
      return inventory.getStackInSlot(4);
    }
    destroySieve();
    return inventory.getStackInSlot(slotIndex);
  }

  public ItemStack getResult()
  {
    return null;
  }
  public void onQueenChange(ItemStack queen) {
  }
  public void wearOutEquipment(int amount) {
  }
  public void onQueenDeath(IBee queen) {
  }
  public void onPostQueenDeath(IBee queen) {
  }

  public boolean onPollenRetrieved(IBee queen, IIndividual pollen, boolean isHandled) {
    if (isHandled)
      return isHandled;
    if (!canStorePollen()) {
      return false;
    }
    storePollenStack(AlleleManager.alleleRegistry.getSpeciesRoot(pollen.getClass()).getMemberStack(pollen, EnumGermlingType.POLLEN.ordinal()));
    return true;
  }

  public boolean onEggLaid(IBee queen)
  {
    return false;
  }
}