package forestry.apiculture.gadgets;

import buildcraft.api.inventory.ISpecialInventory;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeeListener;
import forestry.api.apiculture.IBeeModifier;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.apiculture.IBeekeepingLogic;
import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import forestry.api.core.ForestryAPI;
import forestry.api.core.ITileStructure;
import forestry.api.genetics.IIndividual;
import forestry.apiculture.gui.ContainerAlveary;
import forestry.core.EnumErrorCode;
import forestry.core.config.Config;
import forestry.core.config.ForestryItem;
import forestry.core.interfaces.IClimatised;
import forestry.core.interfaces.IErrorSource;
import forestry.core.interfaces.IHintSource;
import forestry.core.network.GuiId;
import forestry.core.network.PacketInventoryStack;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.proxy.ProxyNetwork;
import forestry.core.utils.InventoryAdapter;
import forestry.core.utils.TileInventoryAdapter;
import forestry.plugins.PluginApiculture;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.ForgeDirection;

public class TileAlvearyPlain extends TileAlveary
  implements ISidedInventory, ISpecialInventory, IBeeHousing, IClimatised, IHintSource
{
  public static final int SLOT_QUEEN = 0;
  public static final int SLOT_DRONE = 1;
  public static final int SLOT_PRODUCT_1 = 2;
  public static final int SLOT_PRODUCTION_COUNT = 7;
  protected IBeekeepingLogic beekeepingLogic;
  protected int biomeId;
  protected float temperature;
  protected float humidity;
  protected float tempChange = 0.0F;
  protected float humidChange = 0.0F;
  private int displayHealthMax = 0;
  private int displayHealth = 0;

  private Set<IBeeModifier> modifiers = new LinkedHashSet();
  private Set<IBeeListener> eventHandlers = new LinkedHashSet();

  public TileAlvearyPlain()
  {
    super(0);
  }

  public void openGui(EntityPlayer player)
  {
    if (isMaster())
      player.openGui(ForestryAPI.instance, GuiId.AlvearyGUI.ordinal(), worldObj, xCoord, yCoord, zCoord);
    else if (hasMaster())
      player.openGui(ForestryAPI.instance, GuiId.AlvearyGUI.ordinal(), worldObj, masterX, masterY, masterZ);
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    tempChange = nbttagcompound.getFloat("TempChange");
    humidChange = nbttagcompound.getFloat("HumidChange");

    if (inventory != null)
      inventory.readFromNBT(nbttagcompound);
    if (beekeepingLogic != null)
      beekeepingLogic.readFromNBT(nbttagcompound);
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    nbttagcompound.setFloat("TempChange", tempChange);
    nbttagcompound.setFloat("HumidChange", humidChange);

    if (inventory != null)
      inventory.writeToNBT(nbttagcompound);
    if (beekeepingLogic != null)
      beekeepingLogic.writeToNBT(nbttagcompound);
  }

  public void initialize()
  {
    super.initialize();
    BiomeGenBase biome = worldObj.getBiomeGenForCoordsBody(xCoord, zCoord);
    biomeId = biome.biomeID;
    temperature = biome.temperature;
    humidity = biome.rainfall;
    setErrorState(EnumErrorCode.OK);
  }

  protected void updateServerSide()
  {
    if (beekeepingLogic == null)
      return;
    if (!isMaster()) {
      return;
    }
    beekeepingLogic.update();

    equalizeTemperature();
    equalizeHumidity();

    IBee queen = beekeepingLogic.getQueen();
    if (queen == null) {
      return;
    }

    if (worldObj.getTotalWorldTime() % 200L * 10L == 0L)
      onQueenChange(inventory.getStackInSlot(0));
    if (getErrorState() == EnumErrorCode.OK) {
      queen.doFX(beekeepingLogic.getEffectData(), this);
    }
    if ((getErrorState() == EnumErrorCode.OK) && (worldObj.getTotalWorldTime() % 50L == 0L)) {
      float f = xCoord + 0.5F;
      float f1 = yCoord + 0.0F + worldObj.rand.nextFloat() * 6.0F / 16.0F;
      float f2 = zCoord + 0.5F;
      float f3 = 0.52F;
      float f4 = worldObj.rand.nextFloat() * 0.6F - 0.3F;

      Proxies.common.addEntitySwarmFX(worldObj, f - f3, f1, f2 + f4, 0.0F, 0.0F, 0.0F);
      Proxies.common.addEntitySwarmFX(worldObj, f + f3, f1, f2 + f4, 0.0F, 0.0F, 0.0F);
      Proxies.common.addEntitySwarmFX(worldObj, f + f4, f1, f2 - f3, 0.0F, 0.0F, 0.0F);
      Proxies.common.addEntitySwarmFX(worldObj, f + f4, f1, f2 + f3, 0.0F, 0.0F, 0.0F);
    }
  }

  protected void updateClientSide()
  {
    if (!isMaster()) {
      return;
    }
    if (inventory == null) {
      return;
    }

    if ((PluginApiculture.beeInterface.isMated(inventory.getStackInSlot(0))) && 
      (getErrorState() == EnumErrorCode.OK) && (worldObj.getTotalWorldTime() % 2L == 0L)) {
      IBee displayQueen = PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0));
      displayQueen.doFX(beekeepingLogic.getEffectData(), this);
    }
  }

  private void equalizeTemperature()
  {
    if (tempChange == 0.0F) {
      return;
    }
    tempChange -= 0.05F * tempChange;
    if ((tempChange <= 0.001F) && (tempChange >= -0.001F))
      tempChange = 0.0F;
  }

  private void equalizeHumidity() {
    if (humidChange == 0.0F) {
      return;
    }
    humidChange -= 0.05F * humidChange;
    if ((humidChange <= 0.001F) && (humidChange >= 0.001F))
      humidChange = 0.0F;
  }

  private int getHealthDisplay()
  {
    if ((inventory == null) || (inventory.getStackInSlot(0) == null)) {
      return 0;
    }
    if (PluginApiculture.beeInterface.isMated(inventory.getStackInSlot(0)))
      return PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0)).getHealth();
    if (!PluginApiculture.beeInterface.isDrone(inventory.getStackInSlot(0))) {
      return displayHealth;
    }
    return 0;
  }

  private int getMaxHealthDisplay() {
    if ((inventory == null) || (inventory.getStackInSlot(0) == null)) {
      return 0;
    }
    if (PluginApiculture.beeInterface.isMated(inventory.getStackInSlot(0)))
      return PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0)).getMaxHealth();
    if (!PluginApiculture.beeInterface.isDrone(inventory.getStackInSlot(0))) {
      return displayHealthMax;
    }
    return 0;
  }

  public int getHealthScaled(int i) {
    if (getMaxHealthDisplay() == 0) {
      return 0;
    }
    return getHealthDisplay() * i / getMaxHealthDisplay();
  }

  public boolean allowsInteraction(EntityPlayer player)
  {
    if (!super.allowsInteraction(player)) {
      return false;
    }
    return isIntegratedIntoStructure();
  }

  protected void createInventory()
  {
    inventory = new TileInventoryAdapter(this, 9, "Items");
  }

  public void makeMaster()
  {
    super.makeMaster();
    if (beekeepingLogic == null)
      beekeepingLogic = PluginApiculture.beeInterface.createBeekeepingLogic(this);
  }

  public void onStructureReset()
  {
    super.onStructureReset();
    modifiers.clear();
    eventHandlers.clear();
  }

  public void registerBeeModifier(IBeeModifier modifier)
  {
    modifiers.add(modifier);
  }

  public void removeBeeModifier(IBeeModifier modifier)
  {
    modifiers.remove(modifier);
  }

  public void registerBeeListener(IBeeListener modifier)
  {
    eventHandlers.add(modifier);
  }

  public void removeBeeListener(IBeeListener modifier)
  {
    eventHandlers.remove(modifier);
  }

  public void addTemperatureChange(float change, float boundaryDown, float boundaryUp)
  {
    tempChange = Math.min(boundaryUp - temperature, Math.max(boundaryDown - temperature, tempChange + change));
  }

  public void addHumidityChange(float change, float boundaryDown, float boundaryUp)
  {
    humidChange = Math.min(boundaryUp - humidity, Math.max(boundaryDown - humidity, humidChange + change));
  }

  public int getXCoord()
  {
    return xCoord;
  }

  public int getYCoord()
  {
    return yCoord;
  }

  public int getZCoord()
  {
    return zCoord;
  }

  public ItemStack getQueen()
  {
    return getStackInSlot(0);
  }

  public ItemStack getDrone()
  {
    return getStackInSlot(1);
  }

  public void setQueen(ItemStack itemstack)
  {
    setInventorySlotContents(0, itemstack);
  }

  public void setDrone(ItemStack itemstack)
  {
    setInventorySlotContents(1, itemstack);
  }

  public int getBiomeId()
  {
    return biomeId;
  }

  public EnumTemperature getTemperature()
  {
    if ((EnumTemperature.isBiomeHellish(biomeId)) && (tempChange >= 0.0F)) {
      return EnumTemperature.HELLISH;
    }
    return EnumTemperature.getFromValue(getExactTemperature());
  }

  public EnumHumidity getHumidity()
  {
    return EnumHumidity.getFromValue(getExactHumidity());
  }

  public float getTerritoryModifier(IBeeGenome genome, float currentModifier)
  {
    float mod = 2.0F;
    for (IBeeModifier modifier : modifiers) {
      mod *= modifier.getTerritoryModifier(genome, mod);
    }
    return mod;
  }

  public float getProductionModifier(IBeeGenome genome, float currentModifier)
  {
    float mod = 1.0F;
    for (IBeeModifier modifier : modifiers) {
      mod *= modifier.getProductionModifier(genome, mod);
    }
    return mod;
  }

  public float getMutationModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    float mod = 1.0F;
    for (IBeeModifier modifier : modifiers) {
      mod *= modifier.getMutationModifier(genome, mate, mod);
    }
    return mod;
  }

  public float getLifespanModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    float mod = 1.0F;
    for (IBeeModifier modifier : modifiers) {
      mod *= modifier.getLifespanModifier(genome, mate, mod);
    }
    return mod;
  }

  public float getFloweringModifier(IBeeGenome genome, float currentModifier)
  {
    float mod = 1.0F;
    for (IBeeModifier modifier : modifiers) {
      mod *= modifier.getFloweringModifier(genome, mod);
    }
    return mod;
  }

  public float getGeneticDecay(IBeeGenome genome, float currentModifier)
  {
    float mod = 1.0F;
    for (IBeeModifier modifier : modifiers) {
      mod *= modifier.getGeneticDecay(genome, mod);
    }
    return mod;
  }

  public World getWorld()
  {
    return worldObj;
  }

  public void setErrorState(int state)
  {
    setErrorState(EnumErrorCode.values()[state]);
  }

  public int getErrorOrdinal()
  {
    return getErrorState().ordinal();
  }

  public boolean canBreed()
  {
    return true;
  }

  public boolean addProduct(ItemStack product, boolean all)
  {
    if (inventory == null) {
      return false;
    }
    return inventory.tryAddStack(product, 2, inventory.getSizeInventory() - 2, all);
  }

  public void wearOutEquipment(int amount)
  {
    for (IBeeListener eventHandler : eventHandlers)
      eventHandler.wearOutEquipment(amount);
  }

  public void onQueenChange(ItemStack queenStack)
  {
    if (!Proxies.common.isSimulating(worldObj)) {
      return;
    }
    Proxies.net.sendNetworkPacket(new PacketInventoryStack(3, xCoord, yCoord, zCoord, 0, queenStack), xCoord, yCoord, zCoord);

    for (IBeeListener eventHandler : eventHandlers)
      eventHandler.onQueenChange(queenStack);
  }

  public void onQueenDeath(IBee queen)
  {
    for (IBeeListener eventHandler : eventHandlers)
      eventHandler.onQueenDeath(queen);
  }

  public void onPostQueenDeath(IBee queen)
  {
    for (IBeeListener eventHandler : eventHandlers)
      eventHandler.onPostQueenDeath(queen);
  }

  public boolean onPollenRetrieved(IBee queen, IIndividual pollen, boolean isHandled)
  {
    for (IBeeListener eventHandler : eventHandlers) {
      if (eventHandler.onPollenRetrieved(queen, pollen, isHandled)) {
        isHandled = true;
      }
    }
    return isHandled;
  }

  public boolean onEggLaid(IBee queen)
  {
    for (IBeeListener eventHandler : eventHandlers) {
      if (eventHandler.onEggLaid(queen)) {
        return true;
      }
    }
    return false;
  }

  public boolean isSealed()
  {
    for (IBeeModifier modifier : modifiers) {
      if (modifier.isSealed())
        return true;
    }
    return false;
  }

  public boolean isSelfLighted()
  {
    for (IBeeModifier modifier : modifiers) {
      if (modifier.isSelfLighted())
        return true;
    }
    return false;
  }

  public boolean isSunlightSimulated()
  {
    for (IBeeModifier modifier : modifiers) {
      if (modifier.isSunlightSimulated())
        return true;
    }
    return false;
  }

  public boolean isHellish()
  {
    for (IBeeModifier modifier : modifiers) {
      if (modifier.isHellish())
        return true;
    }
    return false;
  }

  public InventoryAdapter getInternalInventory()
  {
    return (InventoryAdapter)getStructureInventory();
  }

  private IInventory getStructureInventory()
  {
    if (inventory != null) {
      if ((isMaster()) || (!Proxies.common.isSimulating(worldObj)))
        return inventory;
    } else if (hasMaster()) {
      ITileStructure central = getCentralTE();
      if (central != null) {
        return central.getInventory();
      }
    }
    return null;
  }

  public int getSizeInventory()
  {
    IInventory inv = getStructureInventory();
    if (inv != null) {
      return inv.getSizeInventory();
    }
    return 0;
  }

  public ItemStack getStackInSlot(int slotIndex)
  {
    IInventory inv = getStructureInventory();
    if (inv != null) {
      return inv.getStackInSlot(slotIndex);
    }
    return null;
  }

  public ItemStack decrStackSize(int slotIndex, int amount)
  {
    IInventory inv = getStructureInventory();
    if (inv != null) {
      return inv.decrStackSize(slotIndex, amount);
    }
    return null;
  }

  public ItemStack getStackInSlotOnClosing(int slotIndex)
  {
    IInventory inv = getStructureInventory();
    if (inv != null) {
      return inv.getStackInSlotOnClosing(slotIndex);
    }
    return null;
  }

  public void setInventorySlotContents(int slotIndex, ItemStack itemstack)
  {
    if ((inventory == null) && (!Proxies.common.isSimulating(worldObj))) {
      createInventory();
    }
    IInventory inv = getStructureInventory();
    if (inv != null)
      inv.setInventorySlotContents(slotIndex, itemstack);
  }

  public String getInvName()
  {
    return "alveary.0";
  }

  public int getInventoryStackLimit()
  {
    IInventory inv = getStructureInventory();
    if (inv != null) {
      return inv.getInventoryStackLimit();
    }
    return 0;
  }

  protected boolean canTakeStackFromSide(int slotIndex, ItemStack itemstack, int side)
  {
    if (!super.canTakeStackFromSide(slotIndex, itemstack, side)) {
      return false;
    }
    if ((slotIndex != 0) && (slotIndex != 1)) {
      return true;
    }
    return false;
  }

  protected boolean canPutStackFromSide(int slotIndex, ItemStack itemstack, int side)
  {
    if (!super.canPutStackFromSide(slotIndex, itemstack, side)) {
      return false;
    }
    if ((slotIndex == 0) && (PluginApiculture.beeInterface.isMember(itemstack)) && (!PluginApiculture.beeInterface.isDrone(itemstack)))
    {
      return true;
    }if ((slotIndex == 1) && (PluginApiculture.beeInterface.isDrone(itemstack))) {
      return true;
    }
    return false;
  }

  public void openChest()
  {
  }

  public void closeChest()
  {
  }

  public int addItem(ItemStack stack, boolean doAdd, ForgeDirection from)
  {
    IInventory inv = getStructureInventory();
    if (inv == null) {
      return 0;
    }

    if (((ForestryItem.beePrincessGE.isItemEqual(stack)) || (ForestryItem.beeQueenGE.isItemEqual(stack))) && 
      (inv.getStackInSlot(0) == null)) {
      if (doAdd) {
        inv.setInventorySlotContents(0, stack.copy());
        inv.getStackInSlot(0).stackSize = 1;
      }
      return 1;
    }

    if (ForestryItem.beeDroneGE.isItemEqual(stack))
    {
      ItemStack droneStack = inv.getStackInSlot(1);
      if (droneStack == null) {
        if (doAdd)
          inv.setInventorySlotContents(1, stack.copy());
        return stack.stackSize;
      }
      if (!droneStack.isItemEqual(stack))
        return 0;
      if (!ItemStack.areItemStackTagsEqual(droneStack, stack))
        return 0;
      int space = droneStack.getMaxStackSize() - droneStack.stackSize;
      if (space <= 0) {
        return 0;
      }
      int added = space > stack.stackSize ? stack.stackSize : space;
      if (doAdd)
        droneStack.stackSize += added;
      return added;
    }

    return 0;
  }

  public ItemStack[] extractItem(boolean doRemove, ForgeDirection from, int maxItemCount)
  {
    IInventory inv = getStructureInventory();
    if (inv == null) {
      return new ItemStack[0];
    }
    ItemStack product = null;

    for (int i = 2; i < inv.getSizeInventory(); i++) {
      if (inv.getStackInSlot(i) != null)
      {
        ItemStack stack = inv.getStackInSlot(i);

        if (doRemove) {
          product = inv.decrStackSize(i, 1); break;
        }
        product = stack.copy();
        product.stackSize = 1;

        break;
      }
    }
    return new ItemStack[] { product };
  }

  public void getGUINetworkData(int i, int j)
  {
    switch (i) {
    case 0:
      displayHealth = j;
      break;
    case 1:
      displayHealthMax = j;
      break;
    case 2:
      temperature = (j / 100.0F);
      break;
    case 3:
      humidity = (j / 100.0F);
      break;
    case 4:
      tempChange = (j / 100.0F);
      break;
    case 5:
      humidChange = (j / 100.0F);
      break;
    case 6:
      biomeId = j;
    }
  }

  public void sendGUINetworkData(ContainerAlveary container, ICrafting iCrafting)
  {
    if (beekeepingLogic == null) {
      return;
    }
    iCrafting.sendProgressBarUpdate(container, 0, beekeepingLogic.getBreedingTime());
    iCrafting.sendProgressBarUpdate(container, 1, beekeepingLogic.getTotalBreedingTime());
    iCrafting.sendProgressBarUpdate(container, 2, Math.round(temperature * 100.0F));
    iCrafting.sendProgressBarUpdate(container, 3, Math.round(humidity * 100.0F));
    iCrafting.sendProgressBarUpdate(container, 4, Math.round(tempChange * 100.0F));
    iCrafting.sendProgressBarUpdate(container, 5, Math.round(humidChange * 100.0F));
    iCrafting.sendProgressBarUpdate(container, 6, biomeId);
  }

  public EnumErrorCode getErrorState()
  {
    if (hasMaster()) {
      ITileStructure tile = getCentralTE();
      if (tile != null) {
        return ((IErrorSource)tile).getErrorState();
      }
    }
    return errorState;
  }

  public boolean isClimatized()
  {
    return true;
  }

  public float getExactTemperature()
  {
    return temperature + tempChange;
  }

  public float getExactHumidity()
  {
    return humidity + humidChange;
  }

  public boolean hasHints()
  {
    return ((String[])Config.hints.get("alveary")).length > 0;
  }

  public String[] getHints()
  {
    return (String[])Config.hints.get("alveary");
  }

  public boolean isOwnable()
  {
    return true;
  }
}