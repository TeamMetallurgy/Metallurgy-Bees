package forestry.apiculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.core.ForestryClient;
import forestry.core.render.TextureManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockTorch;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.oredict.OreDictionary;

public class BlockCandle extends BlockTorch
{
  private static ArrayList<Integer> lightingItemIDs = new ArrayList();

  @SideOnly(Side.CLIENT)
  private Icon litStump;

  @SideOnly(Side.CLIENT)
  private Icon litTip;

  @SideOnly(Side.CLIENT)
  private Icon unlitStump;

  @SideOnly(Side.CLIENT)
  private Icon unlitTip;
  private static final String[] dyes = { "dyeWhite", "dyeOrange", "dyeMagenta", "dyeLightBlue", "dyeYellow", "dyeLime", "dyePink", "dyeGray", "dyeLightGray", "dyeCyan", "dyePurple", "dyeBlue", "dyeBrown", "dyeGreen", "dyeRed", "dyeBlack" };

  private static final int[][] colours = { { 255, 255, 255 }, { 219, 125, 62 }, { 255, 20, 255 }, { 107, 138, 201 }, { 255, 255, 20 }, { 20, 255, 20 }, { 208, 132, 153 }, { 74, 74, 74 }, { 154, 161, 161 }, { 20, 255, 255 }, { 126, 61, 181 }, { 20, 20, 255 }, { 79, 50, 31 }, { 53, 70, 27 }, { 150, 52, 48 }, { 20, 20, 20 } };
  public static final String colourTagName = "colour";

  public BlockCandle(int id) { super(id);
    setHardness(0.0F);
    setStepSound(soundWoodFootstep);
    setCreativeTab(Tabs.tabApiculture);

    lightingItemIDs.add(Integer.valueOf(Item.flintAndSteel.itemID));
    lightingItemIDs.add(Integer.valueOf(Item.flint.itemID));
    lightingItemIDs.add(Integer.valueOf(Block.torchWood.blockID));
  }

  public boolean hasTileEntity(int metadata)
  {
    return true;
  }

  public TileEntity createTileEntity(World world, int metadata)
  {
    return new TileCandle();
  }

  public int getRenderType()
  {
    return ForestryClient.candleRenderId;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    String fileBase = getUnlocalizedName().replace("tile.", "");
    blockIcon = TextureManager.getInstance().registerTex(register, "stump");
    litStump = TextureManager.getInstance().registerTex(register, fileBase + "StumpLit");
    litTip = TextureManager.getInstance().registerTex(register, fileBase + "TipLit");
    unlitStump = TextureManager.getInstance().registerTex(register, fileBase + "StumpUnlit");
    unlitTip = TextureManager.getInstance().registerTex(register, fileBase + "TipUnlit");
  }

  public int getLightValue(IBlockAccess world, int x, int y, int z)
  {
    int meta = world.getBlockMetadata(x, y, z);
    return isLit(meta) ? 14 : 0;
  }

  @SideOnly(Side.CLIENT)
  public Icon getTextureFromPassAndMeta(int meta, int pass)
  {
    Icon i = unlitStump;
    if (pass == 0) {
      if (isLit(meta)) {
        i = litTip;
      }
      else {
        i = unlitTip;
      }

    }
    else if (isLit(meta)) {
      i = litStump;
    }
    else {
      i = unlitStump;
    }

    return i;
  }

  public int getColourFromItemStack(ItemStack stack) {
    int colour = 16777215;
    if (stack.hasTagCompound()) {
      NBTTagCompound tag = stack.getTagCompound();
      colour = tag.getByte("red") << 16 | tag.getByte("green") << 8 | tag.getByte("blue");
    }
    return colour;
  }

  public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    itemList.add(new ItemStack(this, 1, 0));
  }

  public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int facing, float facingX, float facingY, float facingZ)
  {
    boolean flag = false;
    int meta = world.getBlockMetadata(x, y, z);
    boolean toggleLitState = true;
    ItemStack held = player.getCurrentEquippedItem();

    if (!isLit(meta)) {
      if ((held == null) || (!lightingItemIDs.contains(Integer.valueOf(held.itemID)))) {
        toggleLitState = false;
      }
      else if ((held.itemID == blockID) && (isLit(held))) {
        toggleLitState = true;
      }
    }

    if (held != null)
    {
      TileCandle te = (TileCandle)world.getBlockTileEntity(x, y, z);
      if (te == null) {
        world.setBlockTileEntity(x, y, z, createTileEntity(world, meta));
      }

      if (held.itemID == blockID) {
        if (!isLit(held))
        {
          if ((held.hasTagCompound()) && (held.getTagCompound().hasKey("colour"))) {
            te.setColour(held.getTagCompound().getInteger("colour"));
          }
          else
          {
            te.setColour(16777215);
          }
        }
        else {
          toggleLitState = true;
        }
        flag = true;
      }
      else
      {
        boolean matched = false;
        for (int i = 0; i < dyes.length; i++) {
          for (ItemStack stack : OreDictionary.getOres(dyes[i])) {
            if (OreDictionary.itemMatches(stack, held, true)) {
              if (isLit(meta)) {
                te.setColour(colours[i][0], colours[i][1], colours[i][2]);
              }
              else {
                te.addColour(colours[i][0], colours[i][1], colours[i][2]);
              }
              world.markBlockForUpdate(x, y, z);
              matched = true;
              toggleLitState = false;
              flag = true;
              break;
            }
          }
          if (matched)
          {
            break;
          }
        }
      }
    }
    if (toggleLitState) {
      meta = toggleLitStatus(meta);
      world.setBlockMetadataWithNotify(x, y, z, meta, 3);
      flag = true;
    }
    return flag;
  }

  public void breakBlock(World world, int x, int y, int z, int blockId, int meta)
  {
    if (!world.isRemote) {
      TileCandle tc = (TileCandle)world.getBlockTileEntity(x, y, z);
      int newMeta = isLit(meta) ? 1 : 0;
      ItemStack stack = new ItemStack(this, 1, newMeta);
      if ((tc != null) && (tc.getColour() != 16777215))
      {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setInteger("colour", tc.getColour());
        stack.setTagCompound(tag);
      }
      dropBlockAsItem_do(world, x, y, z, stack);
    }
    super.breakBlock(world, x, y, z, blockId, meta);
  }

  public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase player, ItemStack itemStack)
  {
    TileCandle tc = (TileCandle)world.getBlockTileEntity(x, y, z);
    tc.setColour(getColourValueFromItemStack(itemStack));
    if (isLit(itemStack)) {
      int meta = world.getBlockMetadata(x, y, z);
      world.setBlockMetadataWithNotify(x, y, z, toggleLitStatus(meta), 3);
    }
  }

  public void dropBlockAsItemWithChance(World par1World, int par2, int par3, int par4, int par5, float par6, int par7)
  {
  }

  public void onBlockHarvested(World par1World, int par2, int par3, int par4, int par5, EntityPlayer par6EntityPlayer)
  {
  }

  protected boolean dropTorchIfCantStay(World world, int x, int y, int z)
  {
    if (!canPlaceBlockAt(world, x, y, z)) {
      if (world.getBlockId(x, y, z) == blockID) {
        world.setBlockToAir(x, y, z);
      }
      return false;
    }

    return true;
  }

  @SideOnly(Side.CLIENT)
  public void randomDisplayTick(World world, int x, int y, int z, Random random)
  {
    if (isLit(world.getBlockMetadata(x, y, z))) {
      int l = world.getBlockMetadata(x, y, z) & 0x7;
      double d0 = x + 0.5F;
      double d1 = y + 0.7F;
      double d2 = z + 0.5F;
      double d3 = 0.219999998807907D;
      double d4 = 0.2700000107288361D;

      if (l == 1)
      {
        world.spawnParticle("smoke", d0 - d4, d1 + d3, d2, 0.0D, 0.0D, 0.0D);
        world.spawnParticle("flame", d0 - d4, d1 + d3, d2, 0.0D, 0.0D, 0.0D);
      }
      else if (l == 2)
      {
        world.spawnParticle("smoke", d0 + d4, d1 + d3, d2, 0.0D, 0.0D, 0.0D);
        world.spawnParticle("flame", d0 + d4, d1 + d3, d2, 0.0D, 0.0D, 0.0D);
      }
      else if (l == 3)
      {
        world.spawnParticle("smoke", d0, d1 + d3, d2 - d4, 0.0D, 0.0D, 0.0D);
        world.spawnParticle("flame", d0, d1 + d3, d2 - d4, 0.0D, 0.0D, 0.0D);
      }
      else if (l == 4)
      {
        world.spawnParticle("smoke", d0, d1 + d3, d2 + d4, 0.0D, 0.0D, 0.0D);
        world.spawnParticle("flame", d0, d1 + d3, d2 + d4, 0.0D, 0.0D, 0.0D);
      }
      else
      {
        world.spawnParticle("smoke", d0, d1, d2, 0.0D, 0.0D, 0.0D);
        world.spawnParticle("flame", d0, d1, d2, 0.0D, 0.0D, 0.0D);
      }
    }
  }

  protected boolean func_94397_d(World par1World, int par2, int par3, int par4, int par5)
  {
    if (dropTorchIfCantStay(par1World, par2, par3, par4))
    {
      int i1 = par1World.getBlockMetadata(par2, par3, par4) & 0x7;
      boolean flag = false;

      if ((!par1World.isBlockSolidOnSide(par2 - 1, par3, par4, ForgeDirection.EAST, true)) && (i1 == 1))
      {
        flag = true;
      }

      if ((!par1World.isBlockSolidOnSide(par2 + 1, par3, par4, ForgeDirection.WEST, true)) && (i1 == 2))
      {
        flag = true;
      }

      if ((!par1World.isBlockSolidOnSide(par2, par3, par4 - 1, ForgeDirection.SOUTH, true)) && (i1 == 3))
      {
        flag = true;
      }

      if ((!par1World.isBlockSolidOnSide(par2, par3, par4 + 1, ForgeDirection.NORTH, true)) && (i1 == 4))
      {
        flag = true;
      }

      if ((!canPlaceTorchOn(par1World, par2, par3 - 1, par4)) && (i1 == 5))
      {
        flag = true;
      }

      if (flag)
      {
        dropBlockAsItem(par1World, par2, par3, par4, par1World.getBlockMetadata(par2, par3, par4), 0);
        par1World.setBlockToAir(par2, par3, par4);
        return true;
      }

      return false;
    }

    return true;
  }

  public boolean canPlaceTorchOn(World par1World, int par2, int par3, int par4)
  {
    if (par1World.doesBlockHaveSolidTopSurface(par2, par3, par4))
    {
      return true;
    }

    int l = par1World.getBlockId(par2, par3, par4);
    return (Block.blocksList[l] != null) && (Block.blocksList[l].canPlaceTorchOnTop(par1World, par2, par3, par4));
  }

  protected int getColourValueFromItemStack(ItemStack itemStack)
  {
    int value = 16777215;
    if (itemStack.hasTagCompound()) {
      NBTTagCompound tag = itemStack.getTagCompound();
      if (tag.hasKey("colour")) {
        value = tag.getInteger("colour");
      }
    }
    return value;
  }

  public static boolean isLit(int meta) {
    return (meta & 0x8) > 0;
  }

  public static boolean isLit(ItemStack itemStack) {
    return itemStack.getItemDamage() > 0;
  }

  protected int toggleLitStatus(int meta) {
    return meta ^ 0x8;
  }

  public void addIDToLightingList(int itemId) {
    if (!lightingItemIDs.contains(Integer.valueOf(itemId)))
      lightingItemIDs.add(Integer.valueOf(itemId));
  }
}