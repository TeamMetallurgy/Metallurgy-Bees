package forestry.apiculture.gadgets;

import forestry.api.apiculture.IAlvearyComponent;
import forestry.api.core.ForestryAPI;
import forestry.core.interfaces.ILiquidTankContainer;
import forestry.core.network.GuiId;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.ForestryTank;
import forestry.core.utils.InventoryAdapter;
import forestry.core.utils.LiquidHelper;
import forestry.core.utils.StackUtils;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.fluids.FluidContainerRegistry.FluidContainerData;
import net.minecraftforge.fluids.FluidStack;

public class TileAlvearyHygroregulator extends TileAlveary
  implements IInventory, ILiquidTankContainer
{
  public static final int BLOCK_META = 5;
  private HygroregulatorRecipe[] recipes;
  InventoryAdapter canInventory = new InventoryAdapter(1, "CanInv");
  private ForestryTank liquidTank = new ForestryTank(10000);
  private HygroregulatorRecipe currentRecipe;
  private int transferTime;

  public TileAlvearyHygroregulator()
  {
    super(5);

    recipes = new HygroregulatorRecipe[] { new HygroregulatorRecipe(new FluidStack(LiquidHelper.getFluid("water"), 1), 1, 0.01F, -0.005F), new HygroregulatorRecipe(new FluidStack(LiquidHelper.getFluid("lava"), 1), 10, -0.01F, 0.005F), new HygroregulatorRecipe(new FluidStack(LiquidHelper.getFluid("ice"), 1), 10, 0.02F, -0.01F) };
  }

  public void openGui(EntityPlayer player)
  {
    player.openGui(ForestryAPI.instance, GuiId.HygroregulatorGUI.ordinal(), worldObj, xCoord, yCoord, zCoord);
  }

  public String getInvName()
  {
    return "tile.alveary.5";
  }

  private HygroregulatorRecipe getRecipe(FluidStack liquid)
  {
    HygroregulatorRecipe recipe = null;
    for (HygroregulatorRecipe rec : recipes)
      if (rec.liquid.isFluidEqual(liquid)) {
        recipe = rec;
        break;
      }
    return recipe;
  }

  protected void updateServerSide()
  {
    super.updateServerSide();

    if ((transferTime <= 0) && (liquidTank.getFluidAmount() > 0)) {
      currentRecipe = getRecipe(liquidTank.getFluid());

      if (currentRecipe != null) {
        liquidTank.drain(currentRecipe.liquid.amount, true);
        transferTime = currentRecipe.transferTime;
      }
    }

    if (transferTime > 0)
    {
      transferTime -= 1;
      if (currentRecipe != null) {
        IAlvearyComponent component = (IAlvearyComponent)getCentralTE();
        if (component != null) {
          component.addHumidityChange(currentRecipe.humidChange, 0.0F, 1.0F);
          component.addTemperatureChange(currentRecipe.tempChange, 0.0F, 2.0F);
        }
      } else {
        transferTime = 0;
      }
    }
    if (worldObj.getTotalWorldTime() % 20L * 10L != 0L) {
      return;
    }

    if (canInventory.getStackInSlot(0) != null) {
      FluidContainerRegistry.FluidContainerData container = LiquidHelper.getLiquidContainer(canInventory.getStackInSlot(0));
      if ((container != null) && ((container.fluid.fluidID == Block.waterStill.blockID) || (container.fluid.fluidID == Block.lavaStill.blockID)))
      {
        canInventory.setInventorySlotContents(0, StackUtils.replenishByContainer(this, canInventory.getStackInSlot(0), container, liquidTank));
        if (canInventory.getStackInSlot(0).stackSize <= 0)
          canInventory.setInventorySlotContents(0, null);
      }
    }
  }

  public boolean hasFunction()
  {
    return true;
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    canInventory.readFromNBT(nbttagcompound);

    liquidTank = new ForestryTank(10000);
    if (nbttagcompound.hasKey("LiquidTank")) {
      liquidTank.readFromNBT(nbttagcompound.getCompoundTag("LiquidTank"));
    }
    transferTime = nbttagcompound.getInteger("TransferTime");

    if (nbttagcompound.hasKey("CurrentLiquid")) {
      FluidStack liquid = FluidStack.loadFluidStackFromNBT(nbttagcompound.getCompoundTag("CurrentLiquid"));
      currentRecipe = getRecipe(liquid);
    }
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    canInventory.writeToNBT(nbttagcompound);

    NBTTagCompound NBTresourceSlot = new NBTTagCompound();
    liquidTank.writeToNBT(NBTresourceSlot);
    nbttagcompound.setTag("LiquidTank", NBTresourceSlot);

    nbttagcompound.setInteger("TransferTime", transferTime);
    if (currentRecipe != null) {
      NBTTagCompound subcompound = new NBTTagCompound();
      currentRecipe.liquid.writeToNBT(subcompound);
      nbttagcompound.setTag("CurrentLiquid", subcompound);
    }
  }

  public int getBlockTexture(int side, int metadata)
  {
    return 11;
  }

  public IInventory getInventory()
  {
    return canInventory;
  }

  public int getSizeInventory()
  {
    if (canInventory != null) {
      return canInventory.getSizeInventory();
    }
    return 0;
  }

  public ItemStack getStackInSlot(int slotIndex)
  {
    if (canInventory != null) {
      return canInventory.getStackInSlot(slotIndex);
    }
    return null;
  }

  public ItemStack decrStackSize(int slotIndex, int amount)
  {
    if (canInventory != null) {
      return canInventory.decrStackSize(slotIndex, amount);
    }
    return null;
  }

  public ItemStack getStackInSlotOnClosing(int slotIndex)
  {
    if (canInventory != null) {
      return canInventory.getStackInSlotOnClosing(slotIndex);
    }
    return null;
  }

  public void setInventorySlotContents(int slotIndex, ItemStack itemstack)
  {
    if ((canInventory == null) && (!Proxies.common.isSimulating(worldObj))) {
      createInventory();
    }
    if (canInventory != null)
      canInventory.setInventorySlotContents(slotIndex, itemstack);
  }

  public int getInventoryStackLimit()
  {
    if (canInventory != null) {
      return canInventory.getInventoryStackLimit();
    }
    return 0;
  }

  public void openChest()
  {
  }

  public void closeChest()
  {
  }

  public int fill(ForgeDirection from, FluidStack resource, boolean doFill)
  {
    return liquidTank.fill(resource, doFill);
  }

  public FluidStack drain(ForgeDirection from, int maxDrain, boolean doDrain)
  {
    return liquidTank.drain(maxDrain, doDrain);
  }

  public ForestryTank[] getTanks()
  {
    return new ForestryTank[] { liquidTank };
  }

  public void getGUINetworkData(int i, int j)
  {
  }

  public void sendGUINetworkData(Container container, ICrafting iCrafting)
  {
  }

  private static class HygroregulatorRecipe
  {
    public final FluidStack liquid;
    public final int transferTime;
    public final float humidChange;
    public final float tempChange;

    public HygroregulatorRecipe(FluidStack liquid, int transferTime, float humidChange, float tempChange)
    {
      this.liquid = liquid;
      this.transferTime = transferTime;
      this.humidChange = humidChange;
      this.tempChange = tempChange;
    }
  }
}