package forestry.apiculture.gadgets;

public class TileAlvearyFan extends TileAlvearyClimatiser
{
  public static final int BLOCK_META = 3;

  public TileAlvearyFan()
  {
    super(new TileAlvearyClimatiser.ClimateControl(-0.01F, 0.05F, 2.5F), 9, 10, 3);
  }
}