package forestry.apiculture.gadgets;

import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAlleleRegistry;
import forestry.core.gadgets.TileNaturalistChest;
import forestry.core.network.GuiId;

public class TileApiaristChest extends TileNaturalistChest
{
  public TileApiaristChest()
  {
    super(AlleleManager.alleleRegistry.getSpeciesRoot("rootBees"), GuiId.ApiaristChestGUI.ordinal());
  }
}