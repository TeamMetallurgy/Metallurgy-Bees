package forestry.apiculture.gadgets;

import buildcraft.api.inventory.ISpecialInventory;
import forestry.api.apiculture.BeeManager;
import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IAlvearyComponent;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.ForestryAPI;
import forestry.apiculture.worldgen.WorldGenHive;
import forestry.apiculture.worldgen.WorldGenHiveSwamer;
import forestry.core.network.GuiId;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.TileInventoryAdapter;
import forestry.plugins.PluginApiculture;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Stack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public class TileAlvearySwarmer extends TileAlveary
  implements ISpecialInventory
{
  public static final int BLOCK_META = 2;
  TileInventoryAdapter swarmerInventory;
  private Stack<ItemStack> pendingSpawns = new Stack();

  public TileAlvearySwarmer() {
    super(2);
  }

  public void initialize()
  {
    super.initialize();
    if (swarmerInventory == null)
      createInventory();
  }

  public void openGui(EntityPlayer player)
  {
    player.openGui(ForestryAPI.instance, GuiId.AlvearySwarmerGUI.ordinal(), worldObj, xCoord, yCoord, zCoord);
  }

  protected void updateServerSide()
  {
    super.updateServerSide();

    if ((worldObj.getTotalWorldTime() % 100L != 0L) && 
      (pendingSpawns.size() > 0)) {
      trySpawnSwarm();
    }
    if (worldObj.getTotalWorldTime() % 500L != 0L) {
      return;
    }
    if (!hasMaster()) {
      return;
    }
    IAlvearyComponent master = (IAlvearyComponent)getCentralTE();
    if (!(master instanceof IBeeHousing)) {
      return;
    }
    IBeeHousing housing = (IBeeHousing)master;
    ItemStack queenstack = housing.getQueen();
    if (queenstack == null)
      return;
    if (!PluginApiculture.beeInterface.isMated(queenstack)) {
      return;
    }

    int slot = getInducerSlot();
    if (slot < 0)
      return;
    int chance = getChanceFor(swarmerInventory.getStackInSlot(slot));

    swarmerInventory.decrStackSize(slot, 1);

    if (worldObj.rand.nextInt(1000) >= chance) {
      return;
    }

    IBee spawn = PluginApiculture.beeInterface.getMember(queenstack);
    spawn.setIsNatural(false);
    pendingSpawns.push(PluginApiculture.beeInterface.getMemberStack(spawn, EnumBeeType.PRINCESS.ordinal()));
  }

  private int getChanceFor(ItemStack stack)
  {
    for (Map.Entry entry : BeeManager.inducers.entrySet()) {
      if (((ItemStack)entry.getKey()).isItemEqual(stack)) {
        return ((Integer)entry.getValue()).intValue();
      }
    }
    return 0;
  }

  private int getInducerSlot() {
    for (int i = 0; i < swarmerInventory.getSizeInventory(); i++) {
      if (swarmerInventory.getStackInSlot(i) != null)
      {
        for (Map.Entry entry : BeeManager.inducers.entrySet()) {
          if (((ItemStack)entry.getKey()).isItemEqual(swarmerInventory.getStackInSlot(i)))
            return i;
        }
      }
    }
    return -1;
  }

  private void trySpawnSwarm()
  {
    ItemStack toSpawn = (ItemStack)pendingSpawns.peek();
    WorldGenHive generator = new WorldGenHiveSwamer(new ItemStack[] { toSpawn });

    int i = 0;
    while (i < 10) {
      i++;
      int spawnX = xCoord + worldObj.rand.nextInt(80) - 40;
      int spawnY = yCoord + worldObj.rand.nextInt(40);
      int spawnZ = zCoord + worldObj.rand.nextInt(80) - 40;
      if (generator.generate(worldObj, worldObj.rand, spawnX, spawnY, spawnZ)) {
        pendingSpawns.pop();
        break;
      }
    }
  }

  public boolean hasFunction()
  {
    return true;
  }

  public int getBlockTexture(int side, int metadata)
  {
    if ((side == 0) || (side == 1)) {
      return 2;
    }
    if (pendingSpawns.size() > 0) {
      return 6;
    }
    return 5;
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);
    if (swarmerInventory == null)
      createInventory();
    swarmerInventory.readFromNBT(nbttagcompound);

    NBTTagList nbttaglist = nbttagcompound.getTagList("PendingSpawns");
    for (int i = 0; i < nbttaglist.tagCount(); i++) {
      NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.tagAt(i);
      pendingSpawns.add(ItemStack.loadItemStackFromNBT(nbttagcompound1));
    }
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);
    if (swarmerInventory != null) {
      swarmerInventory.writeToNBT(nbttagcompound);
    }
    NBTTagList nbttaglist = new NBTTagList();
    ItemStack[] offspring = (ItemStack[])pendingSpawns.toArray(new ItemStack[pendingSpawns.size()]);
    for (int i = 0; i < offspring.length; i++)
      if (offspring[i] != null) {
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.setByte("Slot", (byte)i);
        offspring[i].writeToNBT(nbttagcompound1);
        nbttaglist.appendTag(nbttagcompound1);
      }
    nbttagcompound.setTag("PendingSpawns", nbttaglist);
  }

  protected void createInventory()
  {
    swarmerInventory = new TileInventoryAdapter(this, 4, "SwarmInv");
  }

  public IInventory getInventory()
  {
    return swarmerInventory;
  }

  public int addItem(ItemStack stack, boolean doAdd, ForgeDirection from)
  {
    if (swarmerInventory != null) {
      return swarmerInventory.addStack(stack, false, doAdd);
    }
    return 0;
  }

  public ItemStack[] extractItem(boolean doRemove, ForgeDirection from, int maxItemCount)
  {
    return null;
  }

  public int getSizeInventory()
  {
    if (swarmerInventory != null) {
      return swarmerInventory.getSizeInventory();
    }
    return 0;
  }

  public ItemStack getStackInSlot(int slotIndex)
  {
    if (swarmerInventory != null) {
      return swarmerInventory.getStackInSlot(slotIndex);
    }
    return null;
  }

  public ItemStack decrStackSize(int slotIndex, int amount)
  {
    if (swarmerInventory != null) {
      return swarmerInventory.decrStackSize(slotIndex, amount);
    }
    return null;
  }

  public ItemStack getStackInSlotOnClosing(int slotIndex)
  {
    if (swarmerInventory != null) {
      return swarmerInventory.getStackInSlotOnClosing(slotIndex);
    }
    return null;
  }

  public void setInventorySlotContents(int slotIndex, ItemStack itemstack)
  {
    if ((swarmerInventory == null) && (!Proxies.common.isSimulating(worldObj))) {
      createInventory();
    }
    if (swarmerInventory != null)
      swarmerInventory.setInventorySlotContents(slotIndex, itemstack);
  }

  public String getInvName()
  {
    return "tile.alveary.2";
  }

  public int getInventoryStackLimit()
  {
    if (swarmerInventory != null) {
      return swarmerInventory.getInventoryStackLimit();
    }
    return 0;
  }

  public void openChest()
  {
  }

  public void closeChest()
  {
  }
}