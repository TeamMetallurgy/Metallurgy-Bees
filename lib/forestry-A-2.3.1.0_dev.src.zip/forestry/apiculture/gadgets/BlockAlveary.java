package forestry.apiculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.apiculture.MaterialBeehive;
import forestry.core.gadgets.BlockStructure;
import forestry.core.render.TextureManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockAlveary extends BlockStructure
{
  public static final int PLAIN = 0;
  public static final int ENTRANCE = 1;
  public static final int BOTTOM = 2;
  public static final int LEFT = 3;
  public static final int RIGHT = 4;
  public static final int TX_55_SWOF = 5;
  public static final int TX_56_SWON = 6;
  public static final int TX_57_HTOF = 7;
  public static final int TX_58_HTON = 8;
  public static final int TX_71_FNOF = 9;
  public static final int TX_72_FNON = 10;
  public static final int TX_73_VLVE = 11;
  public static final int STABILISER = 12;
  public static final int SIEVE = 13;

  @SideOnly(Side.CLIENT)
  private Icon[] icons;

  public BlockAlveary(int id)
  {
    super(id, new MaterialBeehive(false));
    setHardness(1.0F);
    if (id == 1382)
      setCreativeTab(Tabs.tabApiculture);
  }

  @SideOnly(Side.CLIENT)
  public void getSubBlocks(int id, CreativeTabs tab, List list) {
    if (id != 1382) {
      return;
    }
    for (int i = 0; i < 8; i++)
      if (i != 1)
      {
        list.add(new ItemStack(blockID, 1, i));
      }
  }

  public int getRenderType()
  {
    return 0;
  }

  public boolean renderAsNormalBlock()
  {
    return true;
  }

  public ArrayList<ItemStack> getBlockDropped(World world, int x, int y, int z, int metadata, int fortune)
  {
    ArrayList drop = new ArrayList();
    drop.add(new ItemStack(blockID, 1, metadata != 1 ? metadata : 0));
    return drop;
  }

  public int getDamageValue(World world, int x, int y, int z)
  {
    int meta = world.getBlockMetadata(x, y, z);
    return meta != 1 ? meta : 0;
  }

  public TileEntity createTileEntity(World world, int metadata)
  {
    switch (metadata) {
    case 2:
      return new TileAlvearySwarmer();
    case 3:
      return new TileAlvearyFan();
    case 4:
      return new TileAlvearyHeater();
    case 5:
      return new TileAlvearyHygroregulator();
    case 6:
      return new TileAlvearyStabiliser();
    case 7:
      return new TileAlvearySieve();
    }
    return new TileAlvearyPlain();
  }

  public TileEntity createNewTileEntity(World world)
  {
    return createTileEntity(world, 0);
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    icons = new Icon[14];
    icons[0] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.plain");
    icons[1] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.entrance");
    icons[2] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.bottom");
    icons[3] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.left");
    icons[4] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.right");
    icons[5] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.swarmer.off");
    icons[6] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.swarmer.on");
    icons[7] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.heater.off");
    icons[8] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.heater.on");
    icons[9] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.fan.off");
    icons[10] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.fan.on");
    icons[11] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.valve");
    icons[12] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.stabiliser");
    icons[13] = TextureManager.getInstance().registerTex(register, "apiculture/alveary.sieve");
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int side, int metadata)
  {
    if (((metadata <= 1) || (metadata == 7) || (metadata == 2) || (metadata == 6)) && ((side == 1) || (side == 0)))
    {
      return icons[2];
    }
    switch (metadata) {
    case 1:
      return icons[1];
    case 2:
      return icons[5];
    case 3:
      return icons[9];
    case 4:
      return icons[7];
    case 5:
      return icons[11];
    case 6:
      return icons[12];
    case 7:
      return icons[13];
    }
    return icons[0];
  }

  @SideOnly(Side.CLIENT)
  public Icon getBlockTexture(IBlockAccess world, int x, int y, int z, int side)
  {
    int meta = world.getBlockMetadata(x, y, z);

    if (meta == 1)
      return getIcon(side, meta);
    if (meta > 1) {
      return getBlockTextureFromSideAndTile(world, x, y, z, side);
    }
    int idXP = world.getBlockId(x + 1, y, z);
    int idXM = world.getBlockId(x - 1, y, z);

    if ((idXP == blockID) && (idXM != blockID))
    {
      if (world.getBlockMetadata(x + 1, y, z) == 1)
      {
        if (world.getBlockId(x, y, z + 1) != blockID) {
          return switchForSide(42, side);
        }
        return switchForSide(41, side);
      }

      return getIcon(side, meta);
    }
    if ((idXP != blockID) && (idXM == blockID)) {
      if (world.getBlockMetadata(x - 1, y, z) == 1)
      {
        if (world.getBlockId(x, y, z + 1) != blockID) {
          return switchForSide(41, side);
        }
        return switchForSide(42, side);
      }

      return getIcon(side, meta);
    }
    return getIcon(side, meta);
  }

  @SideOnly(Side.CLIENT)
  private Icon getBlockTextureFromSideAndTile(IBlockAccess world, int x, int y, int z, int side) {
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if ((tile == null) || (!(tile instanceof TileAlveary))) {
      return getIcon(side, 0);
    }
    return icons[((TileAlveary)tile).getBlockTexture(side, world.getBlockMetadata(x, y, z))];
  }

  @SideOnly(Side.CLIENT)
  private Icon switchForSide(int textureId, int side)
  {
    if ((side == 4) || (side == 5)) {
      if (textureId == 41) {
        return icons[3];
      }
      return icons[4];
    }if (textureId == 41) {
      return icons[4];
    }
    return icons[3];
  }
}