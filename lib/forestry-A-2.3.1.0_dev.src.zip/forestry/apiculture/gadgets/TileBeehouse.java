package forestry.apiculture.gadgets;

import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.apiculture.IBeekeepingLogic;
import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import forestry.api.core.ForestryAPI;
import forestry.api.genetics.IIndividual;
import forestry.core.EnumErrorCode;
import forestry.core.config.Config;
import forestry.core.config.ForestryItem;
import forestry.core.gadgets.TileBase;
import forestry.core.interfaces.IClimatised;
import forestry.core.network.GuiId;
import forestry.core.network.PacketInventoryStack;
import forestry.core.network.PacketTileUpdate;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.proxy.ProxyNetwork;
import forestry.core.utils.InventoryAdapter;
import forestry.core.utils.Utils;
import forestry.plugins.PluginApiculture;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ICrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;

public class TileBeehouse extends TileBase
  implements IBeeHousing, IClimatised
{
  public static final int SLOT_QUEEN = 0;
  public static final int SLOT_DRONE = 1;
  public static final int SLOT_INVENTORY_1 = 2;
  protected static int SLOT_PRODUCT_1 = 2;
  protected static int SLOT_PRODUCT_COUNT = 7;
  public static final int SLOT_FRAMES_1 = 9;
  public static final int SLOT_FRAMES_2 = 10;
  public static final int SLOT_FRAMES_3 = 11;
  public static final int SLOT_INVENTORY_COUNT = 7;
  public static final int SLOT_FRAMES_COUNT = 3;
  protected InventoryAdapter inventory = new InventoryAdapter(12, "Items");
  private final IBeekeepingLogic logic;
  private int biomeId = -1;
  private float temperature;
  private float humidity;
  private int displayHealthMax = 0;
  private int displayHealth = 0;

  public TileBeehouse() {
    setHints((String[])Config.hints.get("apiary"));
    logic = PluginApiculture.beeInterface.createBeekeepingLogic(this);
  }

  public String getInvName()
  {
    return "apiculture.2";
  }

  public void openGui(EntityPlayer player, TileBase tile)
  {
    player.openGui(ForestryAPI.instance, GuiId.BeehouseGUI.ordinal(), worldObj, xCoord, yCoord, zCoord);
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    nbttagcompound.setFloat("Temp", temperature);
    nbttagcompound.setFloat("Humidity", humidity);
    nbttagcompound.setInteger("BiomeId", biomeId);

    inventory.writeToNBT(nbttagcompound);
    if (logic != null)
      logic.writeToNBT(nbttagcompound);
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    temperature = nbttagcompound.getFloat("Temp");
    humidity = nbttagcompound.getFloat("Humidity");
    biomeId = nbttagcompound.getInteger("BiomeId");

    inventory.readFromNBT(nbttagcompound);
    logic.readFromNBT(nbttagcompound);
  }

  public void initialize()
  {
    super.initialize();
    updateBiome();
  }

  public void validate()
  {
    updateBiome();
  }

  public boolean isClimatized()
  {
    return true;
  }

  public EnumTemperature getTemperature()
  {
    if (EnumTemperature.isBiomeHellish(biomeId))
      return EnumTemperature.HELLISH;
    return EnumTemperature.getFromValue(temperature);
  }

  public EnumHumidity getHumidity()
  {
    return EnumHumidity.getFromValue(humidity);
  }

  public float getExactTemperature()
  {
    return temperature;
  }

  public float getExactHumidity()
  {
    return humidity;
  }

  public void updateClientSide()
  {
    if ((PluginApiculture.beeInterface.isMated(inventory.getStackInSlot(0))) && 
      (getErrorState() == EnumErrorCode.OK) && (worldObj.getTotalWorldTime() % 2L % 2L == 0L)) {
      IBee displayQueen = PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0));
      displayQueen.doFX(logic.getEffectData(), this);
    }
  }

  public void updateServerSide()
  {
    logic.update();

    IBee queen = logic.getQueen();
    if (queen == null) {
      return;
    }

    if (worldObj.getTotalWorldTime() % 200L * 10L == 0L)
      onQueenChange(inventory.getStackInSlot(0));
  }

  public boolean isWorking()
  {
    return getErrorState() == EnumErrorCode.OK;
  }

  public boolean addProduct(ItemStack product, boolean all)
  {
    return inventory.tryAddStack(product, SLOT_PRODUCT_1, SLOT_PRODUCT_COUNT, all, true);
  }

  public void onQueenChange(ItemStack queenStack)
  {
    if (!Proxies.common.isSimulating(worldObj)) {
      return;
    }
    Proxies.net.sendNetworkPacket(new PacketInventoryStack(3, xCoord, yCoord, zCoord, 0, queenStack), xCoord, yCoord, zCoord);

    Proxies.net.sendNetworkPacket(new PacketTileUpdate(this), xCoord, yCoord, zCoord);
  }

  private int getHealthDisplay()
  {
    if (inventory.getStackInSlot(0) == null) {
      return 0;
    }
    if (ForestryItem.beeQueenGE.isItemEqual(inventory.getStackInSlot(0)))
      return PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0)).getHealth();
    if (ForestryItem.beePrincessGE.isItemEqual(inventory.getStackInSlot(0))) {
      return displayHealth;
    }
    return 0;
  }

  private int getMaxHealthDisplay() {
    if (inventory.getStackInSlot(0) == null) {
      return 0;
    }
    if (ForestryItem.beeQueenGE.isItemEqual(inventory.getStackInSlot(0)))
      return PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0)).getMaxHealth();
    if (ForestryItem.beePrincessGE.isItemEqual(inventory.getStackInSlot(0))) {
      return displayHealthMax;
    }
    return 0;
  }

  public int getHealthScaled(int i)
  {
    if (getMaxHealthDisplay() == 0) {
      return 0;
    }
    return getHealthDisplay() * i / getMaxHealthDisplay();
  }

  public int getTemperatureScaled(int i) {
    return Math.round(i * (temperature / 2.0F));
  }

  public int getHumidityScaled(int i) {
    return Math.round(i * humidity);
  }

  public void updateBiome() {
    if (worldObj != null) {
      BiomeGenBase biome = Utils.getBiomeAt(worldObj, xCoord, zCoord);
      if (biome != null) {
        biomeId = biome.biomeID;
        temperature = biome.temperature;
        humidity = biome.rainfall;
        setErrorState(EnumErrorCode.OK);
      }
    }
  }

  public void getGUINetworkData(int i, int j)
  {
    if (logic == null) {
      return;
    }
    switch (i) {
    case 0:
      displayHealth = j;
      break;
    case 1:
      displayHealthMax = j;
    }
  }

  public void sendGUINetworkData(Container container, ICrafting iCrafting)
  {
    if (logic == null) {
      return;
    }
    iCrafting.sendProgressBarUpdate(container, 0, logic.getBreedingTime());
    iCrafting.sendProgressBarUpdate(container, 1, logic.getTotalBreedingTime());
  }

  public InventoryAdapter getInternalInventory()
  {
    return inventory;
  }

  public ItemStack getStackInSlot(int i) {
    return inventory.getStackInSlot(i);
  }

  public void setSlotContents(int i, ItemStack itemstack) {
    inventory.setInventorySlotContents(i, itemstack);
  }

  public int getXCoord()
  {
    return xCoord;
  }

  public int getYCoord()
  {
    return yCoord;
  }

  public int getZCoord()
  {
    return zCoord;
  }

  public int getBiomeId()
  {
    return biomeId;
  }

  public ItemStack getQueen()
  {
    return getStackInSlot(0);
  }

  public ItemStack getDrone()
  {
    return getStackInSlot(1);
  }

  public void setQueen(ItemStack itemstack)
  {
    setSlotContents(0, itemstack);
  }

  public void setDrone(ItemStack itemstack)
  {
    setSlotContents(1, itemstack);
  }

  public World getWorld()
  {
    return worldObj;
  }

  public void setErrorState(int state)
  {
    setErrorState(EnumErrorCode.values()[state]);
  }

  public int getErrorOrdinal()
  {
    return getErrorState().ordinal();
  }

  public boolean canBreed()
  {
    return true;
  }

  public float getTerritoryModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getProductionModifier(IBeeGenome genome, float currentModifier)
  {
    return 0.25F;
  }

  public float getMutationModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return 0.0F;
  }

  public float getLifespanModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return 3.0F;
  }

  public float getFloweringModifier(IBeeGenome genome, float currentModifier)
  {
    return 3.0F;
  }

  public float getGeneticDecay(IBeeGenome genome, float currentModifier)
  {
    return 0.0F;
  }

  public void wearOutEquipment(int amount)
  {
  }

  public boolean isSealed()
  {
    return false;
  }

  public boolean isSelfLighted()
  {
    return false;
  }

  public boolean isSunlightSimulated()
  {
    return false;
  }

  public boolean isHellish()
  {
    return false;
  }

  public void onQueenDeath(IBee queen)
  {
  }

  public void onPostQueenDeath(IBee queen)
  {
  }

  public boolean onPollenRetrieved(IBee queen, IIndividual pollen, boolean isHandled)
  {
    return false;
  }

  public boolean onEggLaid(IBee queen)
  {
    return false;
  }
}