package forestry.apiculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.core.config.ForestryBlock;
import forestry.core.render.TextureManager;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockTorch;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class BlockStump extends BlockTorch
{
  public BlockStump(int id)
  {
    super(id);
    setHardness(0.0F);
    setStepSound(soundWoodFootstep);
    setCreativeTab(Tabs.tabApiculture);
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    blockIcon = TextureManager.getInstance().registerTex(register, getUnlocalizedName().replace("tile.", ""));
  }

  public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    itemList.add(new ItemStack(this, 1, 0));
  }

  public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int facing, float facingX, float facingY, float facingZ)
  {
    ItemStack held = player.getCurrentEquippedItem();
    if ((held != null) && ((held.itemID == Item.flintAndSteel.itemID) || (held.itemID == Item.flint.itemID) || (held.itemID == Block.torchWood.blockID))) {
      world.setBlock(x, y, z, ForestryBlock.candle.blockID, world.getBlockMetadata(x, y, z) | 0x8, 2);
      TileCandle tc = new TileCandle();
      tc.setColour(0);
      world.setBlockTileEntity(x, y, z, tc);
      return true;
    }

    return false;
  }

  @SideOnly(Side.CLIENT)
  public int getRenderColor(int par1)
  {
    return 15597568;
  }

  public void randomDisplayTick(World par1World, int par2, int par3, int par4, Random par5Random)
  {
  }
}