package forestry.apiculture.gadgets;

public class TileAlvearyHeater extends TileAlvearyClimatiser
{
  public static final int TEXTURE_OFF = 57;
  public static final int TEXTURE_ON = 58;
  public static final int BLOCK_META = 4;

  public TileAlvearyHeater()
  {
    super(new TileAlvearyClimatiser.ClimateControl(0.01F, 0.0F, 2.5F), 7, 8, 4);
  }
}