package forestry.apiculture.gadgets;

import buildcraft.api.gates.ITrigger;
import forestry.api.apiculture.IAlvearyComponent;
import forestry.api.apiculture.IBeeListener;
import forestry.api.apiculture.IBeeModifier;
import forestry.api.core.IStructureLogic;
import forestry.api.core.ITileStructure;
import forestry.core.config.ForestryBlock;
import forestry.core.gadgets.TileForestry;
import forestry.core.network.PacketPayload;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.proxy.ProxyLog;
import forestry.core.triggers.ForestryTrigger;
import forestry.core.utils.TileInventoryAdapter;
import forestry.core.utils.Utils;
import java.util.LinkedList;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public abstract class TileAlveary extends TileForestry
  implements IAlvearyComponent
{
  protected TileInventoryAdapter inventory;
  protected final int componentBlockMeta;
  IStructureLogic structureLogic;
  private boolean isMaster;
  protected int masterX;
  protected int masterZ;
  protected int masterY = -99;

  public TileAlveary(int componentBlockMeta)
  {
    structureLogic = new StructureLogicAlveary(this);
    this.componentBlockMeta = componentBlockMeta;
  }

  public void initialize()
  {
    int blockid = worldObj.getBlockId(xCoord, yCoord, zCoord);
    if (blockid != ForestryBlock.alveary.blockID) {
      Proxies.log.info("Updating alveary block at %s/%s/%s.", new Object[] { Integer.valueOf(xCoord), Integer.valueOf(yCoord), Integer.valueOf(zCoord) });
      worldObj.setBlock(xCoord, yCoord, zCoord, ForestryBlock.alveary.blockID, componentBlockMeta, 2);
      validate();
      worldObj.setBlockTileEntity(xCoord, yCoord, zCoord, this);
    }
  }

  public void updateEntity()
  {
    if (!Proxies.common.isSimulating(worldObj)) {
      updateClientSide();
    } else {
      if (!isInited) {
        initialize();
        isInited = true;
      }

      if ((worldObj.getTotalWorldTime() % 200L == 0L) && ((!isIntegratedIntoStructure()) || (isMaster()))) {
        validateStructure();
      }
      updateServerSide();
    }
  }

  protected void updateServerSide()
  {
  }

  protected void updateClientSide() {
  }

  public int getBlockTexture(int side, int metadata) {
    return 0;
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);

    isMaster = nbttagcompound.getBoolean("IsMaster");
    masterX = nbttagcompound.getInteger("MasterX");
    masterY = nbttagcompound.getInteger("MasterY");
    masterZ = nbttagcompound.getInteger("MasterZ");

    if (isMaster) {
      makeMaster();
    }
    structureLogic.readFromNBT(nbttagcompound);
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);

    nbttagcompound.setBoolean("IsMaster", isMaster);
    nbttagcompound.setInteger("MasterX", masterX);
    nbttagcompound.setInteger("MasterY", masterY);
    nbttagcompound.setInteger("MasterZ", masterZ);

    structureLogic.writeToNBT(nbttagcompound);
  }

  protected void createInventory()
  {
  }

  public void fromPacketPayload(PacketPayload payload) {
  }

  public PacketPayload getPacketPayload() {
    return null;
  }

  public String getTypeUID()
  {
    return structureLogic.getTypeUID();
  }

  public void validateStructure()
  {
    structureLogic.validateStructure();
  }

  public void makeMaster()
  {
    setCentralTE(null);
    isMaster = true;

    if (inventory == null)
      createInventory();
  }

  public void onStructureReset()
  {
    setCentralTE(null);
    if (worldObj.getBlockMetadata(xCoord, yCoord, zCoord) == 1)
      worldObj.setBlockMetadataWithNotify(xCoord, yCoord, zCoord, 0, 0);
    isMaster = false;
    worldObj.markBlockForUpdate(xCoord, yCoord, zCoord);
  }

  public ITileStructure getCentralTE()
  {
    if (!isIntegratedIntoStructure()) {
      return null;
    }
    if (!isMaster()) {
      TileEntity tile = worldObj.getBlockTileEntity(masterX, masterY, masterZ);
      if ((tile instanceof ITileStructure)) {
        ITileStructure master = (ITileStructure)worldObj.getBlockTileEntity(masterX, masterY, masterZ);
        if (master.isMaster()) {
          return master;
        }
        return null;
      }
      return null;
    }
    return this;
  }

  private boolean isSameTile(TileEntity tile)
  {
    return (tile.xCoord == xCoord) && (tile.yCoord == yCoord) && (tile.zCoord == zCoord);
  }

  public void setCentralTE(TileEntity tile)
  {
    if ((tile == null) || (tile == this) || (isSameTile(tile))) {
      masterX = (this.masterZ = 0);
      masterY = -99;
      return;
    }

    isMaster = false;
    masterX = tile.xCoord;
    masterY = tile.yCoord;
    masterZ = tile.zCoord;
  }

  public boolean isMaster()
  {
    return isMaster;
  }

  protected boolean hasMaster() {
    return masterY >= 0;
  }

  public boolean isIntegratedIntoStructure()
  {
    return (isMaster) || (masterY >= 0);
  }

  public IInventory getInventory()
  {
    return inventory;
  }

  public boolean hasFunction()
  {
    return false;
  }

  public void addTemperatureChange(float change, float boundaryDown, float boundaryUp)
  {
  }

  public void addHumidityChange(float change, float boundaryDown, float boundaryUp)
  {
  }

  public void registerBeeModifier(IBeeModifier modifier)
  {
  }

  public void removeBeeModifier(IBeeModifier modifier)
  {
  }

  public void registerBeeListener(IBeeListener event)
  {
  }

  public void removeBeeListener(IBeeListener event)
  {
  }

  public LinkedList<ITrigger> getCustomTriggers()
  {
    LinkedList res = new LinkedList();
    res.add(ForestryTrigger.missingQueen);
    res.add(ForestryTrigger.missingDrone);
    return res;
  }

  public boolean isUseableByPlayer(EntityPlayer player)
  {
    return Utils.isUseableByPlayer(player, this, worldObj, xCoord, yCoord, zCoord);
  }
}