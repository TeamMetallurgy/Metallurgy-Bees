package forestry.apiculture.gadgets;

import forestry.api.apiculture.IAlvearyComponent;
import forestry.api.core.ITileStructure;
import forestry.core.config.ForestryBlock;
import forestry.core.gadgets.BlockStructure.EnumStructureState;
import forestry.core.gadgets.StructureLogic;
import forestry.core.utils.Schemata;
import forestry.core.utils.Schemata.EnumStructureBlock;
import forestry.core.utils.Vect;
import java.util.HashMap;
import java.util.HashSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHalfSlab;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class StructureLogicAlveary extends StructureLogic
{
  public static final String UID_ALVEARY = "alveary";
  public static final Schemata SCHEMATA_ALVEARY = new Schemata("alveary3x3", 5, 6, 5, new String[] { "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FAAAF", "FAAAF", "FABAF", "FCCCF", "FFFFF", "FFFFF", "FAAAF", "FAAAF", "FBMBF", "FCCCF", "FFFFF", "FFFFF", "FAAAF", "FAAAF", "FABAF", "FCCCF", "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FFFFF", "FFFFF" }).setOffsets(-2, -3, -2);

  public static HashSet<Integer> slabIds = new HashSet();

  public StructureLogicAlveary(ITileStructure structure)
  {
    super("alveary", structure);
    schematas = new Schemata[] { SCHEMATA_ALVEARY };
    metaOnValid.put(Schemata.EnumStructureBlock.BLOCK_B, Integer.valueOf(1));
  }

  protected BlockStructure.EnumStructureState determineMasterState(Schemata schemata, boolean rotate)
  {
    Vect dimensions = schemata.getDimensions(rotate);
    int offsetX = schemata.getxOffset();
    int offsetZ = schemata.getzOffset();
    if (rotate) {
      offsetX = schemata.getzOffset();
      offsetZ = schemata.getxOffset();
    }

    for (int i = 0; i < dimensions.x; i++)
      for (int j = 0; j < schemata.getHeight(); j++)
        for (int k = 0; k < dimensions.z; k++) {
          int x = structureTile.xCoord + i + offsetX;
          int y = structureTile.yCoord + j + schemata.getyOffset();
          int z = structureTile.zCoord + k + offsetZ;

          if (!structureTile.worldObj.blockExists(x, y, z)) {
            return BlockStructure.EnumStructureState.INDETERMINATE;
          }
          Schemata.EnumStructureBlock required = schemata.getAt(i, j, k, rotate);
          if (required != Schemata.EnumStructureBlock.ANY)
          {
            TileEntity tile = structureTile.worldObj.getBlockTileEntity(x, y, z);
            int blockid = structureTile.worldObj.getBlockId(x, y, z);

            switch (1.$SwitchMap$forestry$core$utils$Schemata$EnumStructureBlock[required.ordinal()]) {
            case 1:
              if (blockid != 0)
                return BlockStructure.EnumStructureState.INVALID;
              break;
            case 2:
              if ((tile == null) || (!(tile instanceof IAlvearyComponent)))
                return BlockStructure.EnumStructureState.INVALID;
              if (!((ITileStructure)tile).getTypeUID().equals("alveary"))
                return BlockStructure.EnumStructureState.INVALID;
              break;
            case 3:
            case 4:
              if ((tile == null) || (!(tile instanceof TileAlvearyPlain)))
                return BlockStructure.EnumStructureState.INVALID;
              break;
            case 5:
              if (!slabIds.contains(Integer.valueOf(blockid)))
                return BlockStructure.EnumStructureState.INVALID;
              if ((structureTile.worldObj.getBlockMetadata(x, y, z) & 0x8) != 0)
                return BlockStructure.EnumStructureState.INVALID;
              break;
            case 6:
              if (blockid != Block.stairsWoodSpruce.blockID)
                return BlockStructure.EnumStructureState.INVALID;
              break;
            case 7:
              if ((tile instanceof ITileStructure))
                return BlockStructure.EnumStructureState.INVALID;
              break;
            default:
              return BlockStructure.EnumStructureState.INDETERMINATE;
            }
          }
        }
    return BlockStructure.EnumStructureState.VALID;
  }

  static
  {
    slabIds.add(Integer.valueOf(Block.stoneSingleSlab.blockID));
    slabIds.add(Integer.valueOf(Block.woodSingleSlab.blockID));
    slabIds.add(Integer.valueOf(ForestryBlock.slabs1.blockID));
    slabIds.add(Integer.valueOf(ForestryBlock.slabs2.blockID));
    slabIds.add(Integer.valueOf(ForestryBlock.slabs3.blockID));
    if (ForestryBlock.slabs4 != null)
      slabIds.add(Integer.valueOf(ForestryBlock.slabs4.blockID));
  }
}