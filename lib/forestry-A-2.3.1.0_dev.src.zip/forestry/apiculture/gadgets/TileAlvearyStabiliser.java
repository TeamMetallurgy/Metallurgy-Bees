package forestry.apiculture.gadgets;

import forestry.api.apiculture.IAlvearyComponent;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeModifier;
import net.minecraft.world.World;

public class TileAlvearyStabiliser extends TileAlveary
  implements IBeeModifier
{
  public static final int BLOCK_META = 6;

  public TileAlvearyStabiliser()
  {
    super(6);
  }

  public void initialize()
  {
    super.initialize();

    if ((!hasMaster()) || (!isIntegratedIntoStructure())) {
      return;
    }
    ((IAlvearyComponent)getCentralTE()).registerBeeModifier(this);
  }

  protected void updateServerSide()
  {
    super.updateServerSide();
    if (worldObj.getTotalWorldTime() % 200L != 0L) {
      return;
    }
    if ((!hasMaster()) || (!isIntegratedIntoStructure())) {
      return;
    }
    ((IAlvearyComponent)getCentralTE()).registerBeeModifier(this);
  }

  public String getInvName()
  {
    return "tile.alveary.6";
  }

  public boolean hasFunction()
  {
    return true;
  }

  public int getBlockTexture(int side, int metadata)
  {
    if ((side == 0) || (side == 1)) {
      return 2;
    }
    return 12;
  }

  public float getMutationModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return 0.0F;
  }

  public float getTerritoryModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getLifespanModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return 1.0F;
  }

  public float getProductionModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getFloweringModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getGeneticDecay(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public boolean isSealed()
  {
    return false;
  }

  public boolean isSelfLighted()
  {
    return false;
  }

  public boolean isSunlightSimulated()
  {
    return false;
  }

  public boolean isHellish()
  {
    return false;
  }
}