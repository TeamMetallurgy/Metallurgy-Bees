package forestry.apiculture.gadgets;

import buildcraft.api.power.IPowerReceptor;
import buildcraft.api.power.PowerHandler;
import buildcraft.api.power.PowerHandler.PowerReceiver;
import buildcraft.api.power.PowerHandler.Type;
import forestry.api.apiculture.IAlvearyComponent;
import forestry.core.network.PacketPayload;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public abstract class TileAlvearyClimatiser extends TileAlveary
  implements IPowerReceptor
{
  PowerHandler powerProvider;
  ClimateControl climateControl;
  private int transferTime = 0;
  private int animationDelay = 0;
  private int textureOff;
  private int textureOn;

  public TileAlvearyClimatiser(ClimateControl control, int textureOff, int textureOn, int componentBlockMeta)
  {
    super(componentBlockMeta);
    climateControl = control;
    powerProvider = new PowerHandler(this, PowerHandler.Type.MACHINE);
    powerProvider.configure(10.0F, 100.0F, 25.0F, 200.0F);
    this.textureOff = textureOff;
    this.textureOn = textureOn;
  }

  public void openGui(EntityPlayer player)
  {
  }

  protected void updateServerSide()
  {
    super.updateServerSide();

    if (powerProvider != null) {
      powerProvider.update();
    }

    if (!hasMaster()) {
      return;
    }
    if (transferTime > 0) {
      transferTime -= 1;
      IAlvearyComponent component = (IAlvearyComponent)getCentralTE();
      if (component != null) {
        component.addTemperatureChange(climateControl.changePerTransfer, climateControl.boundaryDown, climateControl.boundaryUp);
      }
    }
    if (animationDelay > 0) {
      animationDelay -= 1;
      if (animationDelay <= 0)
        sendNetworkUpdate();
    }
  }

  public boolean hasFunction()
  {
    return true;
  }

  public int getBlockTexture(int side, int metadata)
  {
    if (animationDelay > 0) {
      return textureOn;
    }
    return textureOff;
  }

  public void doWork(PowerHandler workProvider)
  {
    if (!hasMaster()) {
      return;
    }
    if (powerProvider.useEnergy(powerProvider.getActivationEnergy(), powerProvider.getEnergyStored(), false) < powerProvider.getActivationEnergy()) {
      return;
    }
    transferTime = Math.round(powerProvider.useEnergy(powerProvider.getActivationEnergy(), powerProvider.getEnergyStored(), true));

    if (animationDelay <= 0) {
      animationDelay = 100;
      sendNetworkUpdate();
    } else {
      animationDelay = 100;
    }
  }

  public PowerHandler.PowerReceiver getPowerReceiver(ForgeDirection side) {
    return powerProvider.getPowerReceiver();
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);
    powerProvider.readFromNBT(nbttagcompound);
    transferTime = nbttagcompound.getInteger("Heating");
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);
    powerProvider.writeToNBT(nbttagcompound);
    nbttagcompound.setInteger("Heating", transferTime);
  }

  public String getInvName()
  {
    return "tile.alveary.climatiser";
  }

  public void fromPacketPayload(PacketPayload payload)
  {
    animationDelay = payload.shortPayload[0];
    worldObj.markBlockForRenderUpdate(xCoord, yCoord, zCoord);
  }

  public PacketPayload getPacketPayload()
  {
    PacketPayload payload = new PacketPayload(0, 1);
    payload.shortPayload[0] = ((short)animationDelay);
    return payload;
  }

  public static class ClimateControl
  {
    final float changePerTransfer;
    final float boundaryUp;
    final float boundaryDown;

    public ClimateControl(float changePerTransfer, float boundaryDown, float boundaryUp)
    {
      this.changePerTransfer = changePerTransfer;
      this.boundaryDown = boundaryDown;
      this.boundaryUp = boundaryUp;
    }
  }
}