package forestry.apiculture.gadgets;

import forestry.core.utils.InventoryAdapter;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;

public class TileSwarm extends TileEntity
{
  public InventoryAdapter contained = new InventoryAdapter(2, "Contained");

  public boolean canUpdate()
  {
    return false;
  }

  public TileSwarm setContained(ItemStack[] bees) {
    for (ItemStack itemstack : bees) {
      contained.addStack(itemstack, false, true);
    }
    return this;
  }

  public boolean containsBees() {
    for (int i = 0; i < contained.getSizeInventory(); i++) {
      if (contained.getStackInSlot(i) != null)
        return true;
    }
    return false;
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    super.readFromNBT(nbttagcompound);
    contained.readFromNBT(nbttagcompound);
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    super.writeToNBT(nbttagcompound);
    contained.writeToNBT(nbttagcompound);
  }
}