package forestry.apiculture.gadgets;

import buildcraft.api.gates.ITrigger;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.apiculture.IBeekeepingMode;
import forestry.api.apiculture.IHiveFrame;
import forestry.api.core.ForestryAPI;
import forestry.core.gadgets.TileBase;
import forestry.core.network.GuiId;
import forestry.core.triggers.ForestryTrigger;
import forestry.core.utils.InventoryAdapter;
import forestry.plugins.PluginApiculture;
import java.util.LinkedList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.ItemStack;

public class TileApiary extends TileBeehouse
  implements ISidedInventory
{
  public String getInvName()
  {
    return "apiculture.0";
  }

  public void openGui(EntityPlayer player, TileBase tile)
  {
    player.openGui(ForestryAPI.instance, GuiId.ApiaryGUI.ordinal(), worldObj, xCoord, yCoord, zCoord);
  }

  public float getTerritoryModifier(IBeeGenome genome, float currentModifier)
  {
    float mod = 1.0F;
    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
          mod *= ((IHiveFrame)inventory.getStackInSlot(i).getItem()).getTerritoryModifier(genome, mod);
      }
    return mod;
  }

  public float getProductionModifier(IBeeGenome genome, float currentModifier)
  {
    float mod = 0.1F;
    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
          mod *= ((IHiveFrame)inventory.getStackInSlot(i).getItem()).getProductionModifier(genome, mod);
      }
    return mod;
  }

  public float getMutationModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    float mod = 1.0F;
    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
          mod *= ((IHiveFrame)inventory.getStackInSlot(i).getItem()).getMutationModifier(genome, mate, mod);
      }
    return mod;
  }

  public float getLifespanModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    float mod = 1.0F;
    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
          mod *= ((IHiveFrame)inventory.getStackInSlot(i).getItem()).getLifespanModifier(genome, mate, mod);
      }
    return mod;
  }

  public float getFloweringModifier(IBeeGenome genome, float currentModifier)
  {
    float mod = 1.0F;
    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
          mod *= ((IHiveFrame)inventory.getStackInSlot(i).getItem()).getFloweringModifier(genome, mod);
      }
    return mod;
  }

  public float getGeneticDecay(IBeeGenome genome, float currentModifier)
  {
    float mod = 1.0F;
    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
          mod *= ((IHiveFrame)inventory.getStackInSlot(i).getItem()).getGeneticDecay(genome, mod);
      }
    return mod;
  }

  public void wearOutEquipment(int amount)
  {
    int wear = Math.round(amount * PluginApiculture.beeInterface.getBeekeepingMode(worldObj).getWearModifier());

    for (int i = 9; i < 12; i++)
      if (inventory.getStackInSlot(i) != null)
      {
        if ((inventory.getStackInSlot(i).getItem() instanceof IHiveFrame))
        {
          inventory.setInventorySlotContents(i, ((IHiveFrame)inventory.getStackInSlot(i).getItem()).frameUsed(this, inventory.getStackInSlot(i), PluginApiculture.beeInterface.getMember(inventory.getStackInSlot(0)), wear));
        }
      }
  }

  protected boolean canTakeStackFromSide(int slotIndex, ItemStack itemstack, int side)
  {
    if (!super.canTakeStackFromSide(slotIndex, itemstack, side)) {
      return false;
    }
    switch (slotIndex) {
    case 0:
    case 1:
    case 9:
    case 10:
    case 11:
      return false;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8: } return true;
  }

  protected boolean canPutStackFromSide(int slotIndex, ItemStack itemstack, int side)
  {
    if (!super.canPutStackFromSide(slotIndex, itemstack, side)) {
      return false;
    }
    if ((slotIndex == 0) && (PluginApiculture.beeInterface.isMember(itemstack)) && (!PluginApiculture.beeInterface.isDrone(itemstack)))
    {
      return true;
    }
    if ((slotIndex == 1) && (PluginApiculture.beeInterface.isDrone(itemstack))) {
      return true;
    }
    return false;
  }

  public void setInventorySlotContents(int i, ItemStack itemstack)
  {
    super.setSlotContents(i, itemstack);
  }

  public int getSizeInventory()
  {
    return inventory.getSizeInventory();
  }

  public ItemStack decrStackSize(int i, int j)
  {
    return inventory.decrStackSize(i, j);
  }

  public ItemStack getStackInSlotOnClosing(int slot)
  {
    return inventory.getStackInSlotOnClosing(slot);
  }

  public int getInventoryStackLimit()
  {
    return inventory.getInventoryStackLimit();
  }

  public void openChest()
  {
  }

  public void closeChest()
  {
  }

  public LinkedList<ITrigger> getCustomTriggers()
  {
    LinkedList res = new LinkedList();
    res.add(ForestryTrigger.missingQueen);
    res.add(ForestryTrigger.missingDrone);
    res.add(PluginApiculture.triggerNoFrames);
    return res;
  }
}