package forestry.apiculture.gadgets;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.INetworkManager;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.Packet132TileEntityData;
import net.minecraft.tileentity.TileEntity;

public class TileCandle extends TileEntity
{
  private int colour;

  public boolean canUpdate()
  {
    return false;
  }

  public Packet getDescriptionPacket()
  {
    Packet132TileEntityData packet = new Packet132TileEntityData();
    packet.actionType = 0;
    packet.xPosition = xCoord;
    packet.yPosition = yCoord;
    packet.zPosition = zCoord;
    NBTTagCompound nbt = new NBTTagCompound();
    writeToNBT(nbt);
    packet.data = nbt;

    return packet;
  }

  public void onDataPacket(INetworkManager net, Packet132TileEntityData pkt)
  {
    readFromNBT(pkt.data);
  }

  public void readFromNBT(NBTTagCompound tagRoot)
  {
    super.readFromNBT(tagRoot);
    setColour(tagRoot.getInteger("colour"));
  }

  public void writeToNBT(NBTTagCompound tagRoot)
  {
    super.writeToNBT(tagRoot);
    tagRoot.setInteger("colour", colour);
  }

  public int getColour() {
    return colour;
  }

  public void setColour(int value) {
    colour = value;
  }

  public void setColour(int red, int green, int blue) {
    colour = toIntColour(red, green, blue);
  }

  public void addColour(int red, int green, int blue)
  {
    int[] myColour = fromIntColour(colour);
    colour = toIntColour((red + myColour[0]) / 2, (green + myColour[0]) / 2, (blue + myColour[2]) / 2);
  }

  private static int[] fromIntColour(int value) {
    int[] cs = new int[3];
    cs[0] = ((value & 0xFF0000) >> 16);
    cs[1] = ((value & 0xFF00) >> 8);
    cs[2] = (value & 0xFF);
    return cs;
  }

  private static int toIntColour(int r, int g, int b) {
    return r << 16 | g << 8 | b;
  }
}