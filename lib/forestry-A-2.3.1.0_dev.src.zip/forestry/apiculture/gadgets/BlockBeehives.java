package forestry.apiculture.gadgets;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.IHiveDrop;
import forestry.api.core.Tabs;
import forestry.apiculture.MaterialBeehive;
import forestry.core.config.Config;
import forestry.core.render.TextureManager;
import forestry.core.utils.InventoryAdapter;
import forestry.core.utils.StackUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockContainer;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraft.world.World;

public class BlockBeehives extends BlockContainer
{

  @SideOnly(Side.CLIENT)
  private Icon[] icons;

  public BlockBeehives(int i)
  {
    super(i, new MaterialBeehive(true));
    setLightValue(0.8F);
    setHardness(1.0F);
    setCreativeTab(Tabs.tabApiculture);
  }

  public TileEntity createNewTileEntity(World world)
  {
    return new TileSwarm();
  }

  public boolean canDragonDestroy(World world, int x, int y, int z)
  {
    return false;
  }

  public boolean removeBlockByPlayer(World world, EntityPlayer player, int x, int y, int z)
  {
    if (canHarvestBlock(player, world.getBlockMetadata(x, y, z)))
    {
      TileEntity tile = world.getBlockTileEntity(x, y, z);

      if ((tile instanceof TileSwarm)) {
        TileSwarm swarm = (TileSwarm)tile;
        if (swarm.containsBees()) {
          for (ItemStack beeStack : swarm.contained.getStacks())
            if (beeStack != null)
              StackUtils.dropItemStackAsEntity(beeStack, world, x, y, z);
        }
      }
    }
    return world.setBlock(x, y, z, 0, 0, 3);
  }

  public ArrayList<ItemStack> getBlockDropped(World world, int x, int y, int z, int metadata, int fortune)
  {
    ArrayList ret = new ArrayList();

    if (metadata == 0) {
      ret.add(new ItemStack(this));
      return ret;
    }

    ArrayList dropList = forestry.api.apiculture.BeeManager.hiveDrops[(metadata - 1)];

    Collections.shuffle(dropList);

    int tries = 0;
    boolean hasPrincess = false;
    while ((tries <= 10) && (!hasPrincess)) {
      tries++;

      for (IHiveDrop drop : dropList) {
        if (world.rand.nextInt(100) < drop.getChance(world, x, y, z)) {
          ret.add(drop.getPrincess(world, x, y, z, fortune));
          hasPrincess = true;
          break;
        }
      }
    }

    for (IHiveDrop drop : dropList) {
      if (world.rand.nextInt(100) < drop.getChance(world, x, y, z)) {
        ret.addAll(drop.getDrones(world, x, y, z, fortune));
        break;
      }
    }
    for (IHiveDrop drop : dropList) {
      if (world.rand.nextInt(100) < drop.getChance(world, x, y, z)) {
        ret.addAll(drop.getAdditional(world, x, y, z, fortune));
        break;
      }
    }
    return ret;
  }

  public int damageDropped(int meta)
  {
    return meta;
  }

  public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    itemList.add(new ItemStack(this, 1, 1));
    itemList.add(new ItemStack(this, 1, 2));
    itemList.add(new ItemStack(this, 1, 3));
    itemList.add(new ItemStack(this, 1, 4));
    if (Config.isDebug) {
      itemList.add(new ItemStack(this, 1, 5));
    }
    itemList.add(new ItemStack(this, 1, 6));
    itemList.add(new ItemStack(this, 1, 7));
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    icons = new Icon[18];
    for (int i = 1; i < 9; i++) {
      icons[(i * 2)] = TextureManager.getInstance().registerTex(register, "beehives/beehive." + i + ".top");
      icons[(i * 2 + 1)] = TextureManager.getInstance().registerTex(register, "beehives/beehive." + i + ".side");
    }
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(int i, int j)
  {
    if ((i == 0) || (i == 1)) {
      if ((j * 2 < icons.length) && (icons[(j * 2)] != null)) {
        return icons[(j * 2)];
      }
      return icons[2];
    }if ((j * 2 + 1 < icons.length) && (icons[(j * 2 + 1)] != null)) {
      return icons[(j * 2 + 1)];
    }
    return icons[3];
  }
}