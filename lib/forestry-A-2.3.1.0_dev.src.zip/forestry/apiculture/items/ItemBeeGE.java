package forestry.apiculture.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.IIconProvider;
import forestry.api.core.Tabs;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IAlleleSpecies;
import forestry.api.genetics.IIndividual;
import forestry.apiculture.genetics.Bee;
import forestry.core.config.Config;
import forestry.core.genetics.ItemGE;
import forestry.core.utils.StringUtil;
import forestry.plugins.PluginApiculture;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.Icon;

public class ItemBeeGE extends ItemGE
{
  EnumBeeType type;

  public ItemBeeGE(int i, EnumBeeType type)
  {
    super(i);
    this.type = type;
    setCreativeTab(Tabs.tabApiculture);
    if (type != EnumBeeType.DRONE)
      setMaxStackSize(1);
  }

  protected IIndividual getIndividual(ItemStack itemstack)
  {
    return new Bee(itemstack.getTagCompound());
  }

  protected int getDefaultPrimaryColour()
  {
    return 16777215;
  }

  protected int getDefaultSecondaryColour()
  {
    return 16768022;
  }

  public String getItemDisplayName(ItemStack itemstack)
  {
    if (itemstack.getTagCompound() == null) {
      return StringUtil.localize(type.getName());
    }
    IBee individual = new Bee(itemstack.getTagCompound());
    return individual.getDisplayName() + StringUtil.localize(new StringBuilder().append(type.getName()).append(".adj.add").toString()) + " " + StringUtil.localize(type.getName());
  }

  public void addInformation(ItemStack itemstack, EntityPlayer player, List list, boolean flag)
  {
    if (!itemstack.hasTagCompound()) {
      return;
    }
    if (type != EnumBeeType.DRONE) {
      IBee individual = new Bee(itemstack.getTagCompound());
      if (individual.isNatural())
        list.add("§e§o" + StringUtil.localize("bees.stock.pristine"));
      else {
        list.add("§e" + StringUtil.localize("bees.stock.ignoble"));
      }
    }
    super.addInformation(itemstack, player, list, flag);
  }

  public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    if (type == EnumBeeType.QUEEN) {
      return;
    }
    addCreativeItems(itemList, true);
  }

  public void addCreativeItems(List itemList, boolean hideSecrets)
  {
    for (IIndividual individual : PluginApiculture.beeInterface.getIndividualTemplates())
    {
      if ((!hideSecrets) || (!individual.isSecret()) || (Config.isDebug))
      {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        ItemStack someStack = new ItemStack(this);
        individual.writeToNBT(nbttagcompound);
        someStack.setTagCompound(nbttagcompound);
        itemList.add(someStack);
      }
    }
  }

  public int getColorFromItemStack(ItemStack itemstack, int renderPass)
  {
    if (!itemstack.hasTagCompound()) {
      return super.getColorFromItemStack(itemstack, renderPass);
    }
    return getColourFromSpecies(PluginApiculture.beeInterface.getMember(itemstack).getGenome().getPrimary(), renderPass);
  }

  public int getColourFromSpecies(IAlleleSpecies species, int renderPass)
  {
    if ((species != null) && ((species instanceof IAlleleBeeSpecies))) {
      return ((IAlleleBeeSpecies)species).getIconColour(renderPass);
    }
    return 16777215;
  }

  public boolean requiresMultipleRenderPasses()
  {
    return true;
  }

  public int getRenderPasses(int metadata)
  {
    return 3;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    for (IAllele allele : AlleleManager.alleleRegistry.getRegisteredAlleles().values())
      if ((allele instanceof IAlleleBeeSpecies))
        ((IAlleleBeeSpecies)allele).getIconProvider().registerIcons(register);
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(ItemStack itemstack, int renderPass)
  {
    return getIconFromSpecies(PluginApiculture.beeInterface.getMember(itemstack).getGenome().getPrimary(), renderPass);
  }

  @SideOnly(Side.CLIENT)
  public Icon getIconFromSpecies(IAlleleBeeSpecies species, int renderPass) {
    if (species == null) {
      species = (IAlleleBeeSpecies)PluginApiculture.beeInterface.getDefaultTemplate()[forestry.api.apiculture.EnumBeeChromosome.SPECIES.ordinal()];
    }
    return species.getIcon(type, renderPass);
  }
}