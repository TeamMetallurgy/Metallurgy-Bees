package forestry.apiculture.items;

import forestry.core.interfaces.ICraftingPlan;
import forestry.core.items.ItemForestry;
import net.minecraft.item.ItemStack;

public class ItemWaxCast extends ItemForestry
  implements ICraftingPlan
{
  public ItemWaxCast(int id)
  {
    super(id);
    setMaxStackSize(1);
    setMaxDamage(10);
    setNoRepair();
  }

  public ItemStack planUsed(ItemStack plan, ItemStack result)
  {
    plan.setItemDamage(plan.getItemDamage() + result.stackSize);
    if (plan.getItemDamage() >= plan.getMaxDamage()) {
      return null;
    }
    return plan;
  }
}