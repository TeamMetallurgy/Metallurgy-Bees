package forestry.apiculture.items;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.ForestryAPI;
import forestry.api.core.Tabs;
import forestry.api.genetics.IAllele;
import forestry.apiculture.genetics.Bee;
import forestry.core.items.ItemForestry;
import forestry.core.network.GuiId;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import java.util.Map;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class ItemImprinter extends ItemForestry
{
  public ItemImprinter(int i)
  {
    super(i);
    setCreativeTab(Tabs.tabApiculture);
    setMaxStackSize(1);
  }

  public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
  {
    if (Proxies.common.isSimulating(world)) {
      entityplayer.openGui(ForestryAPI.instance, GuiId.ImprinterGUI.ordinal(), world, (int)entityplayer.posX, (int)entityplayer.posY, (int)entityplayer.posZ);
    }

    return itemstack;
  }

  public static class ImprinterInventory
    implements IInventory
  {
    private ItemStack[] inventoryStacks = new ItemStack[2];
    private short specimenSlot = 0;
    private short imprintedSlot = 1;

    private int primaryIndex = 0;
    private int secondaryIndex = 0;
    EntityPlayer player;

    public ImprinterInventory(EntityPlayer player)
    {
      this.player = player;
    }

    public void advancePrimary() {
      if (primaryIndex < PluginApiculture.beeInterface.getIndividualTemplates().size() - 1)
        primaryIndex += 1;
      else
        primaryIndex = 0;
    }

    public void advanceSecondary() {
      if (secondaryIndex < PluginApiculture.beeInterface.getIndividualTemplates().size() - 1)
        secondaryIndex += 1;
      else
        secondaryIndex = 0;
    }

    public void regressPrimary() {
      if (primaryIndex > 0)
        primaryIndex -= 1;
      else
        primaryIndex = (PluginApiculture.beeInterface.getIndividualTemplates().size() - 1);
    }

    public void regressSecondary() {
      if (secondaryIndex > 0)
        secondaryIndex -= 1;
      else
        secondaryIndex = (PluginApiculture.beeInterface.getIndividualTemplates().size() - 1);
    }

    public IAlleleBeeSpecies getPrimary() {
      return ((IBee)PluginApiculture.beeInterface.getIndividualTemplates().get(primaryIndex)).getGenome().getPrimary();
    }

    public IAlleleBeeSpecies getSecondary() {
      return ((IBee)PluginApiculture.beeInterface.getIndividualTemplates().get(secondaryIndex)).getGenome().getPrimary();
    }

    public IBee getSelectedBee() {
      return new Bee(PluginApiculture.beeInterface.templateAsGenome((IAllele[])PluginApiculture.beeInterface.getGenomeTemplates().get(((IBee)PluginApiculture.beeInterface.getIndividualTemplates().get(primaryIndex)).getIdent()), (IAllele[])PluginApiculture.beeInterface.getGenomeTemplates().get(((IBee)PluginApiculture.beeInterface.getIndividualTemplates().get(secondaryIndex)).getIdent())));
    }

    public int getPrimaryIndex()
    {
      return primaryIndex;
    }

    public int getSecondaryIndex() {
      return secondaryIndex;
    }

    public void setPrimaryIndex(int index) {
      primaryIndex = index;
    }

    public void setSecondaryIndex(int index) {
      secondaryIndex = index;
    }

    private void tryImprint()
    {
      if (inventoryStacks[specimenSlot] == null) {
        return;
      }

      if (!PluginApiculture.beeInterface.isMember(inventoryStacks[specimenSlot])) {
        return;
      }

      if (inventoryStacks[imprintedSlot] != null) {
        return;
      }
      IBee imprint = getSelectedBee();
      if (imprint == null) {
        return;
      }
      NBTTagCompound nbttagcompound = new NBTTagCompound();
      imprint.writeToNBT(nbttagcompound);
      inventoryStacks[specimenSlot].setTagCompound(nbttagcompound);

      inventoryStacks[imprintedSlot] = inventoryStacks[specimenSlot];
      inventoryStacks[specimenSlot] = null;
    }

    public ItemStack decrStackSize(int i, int j)
    {
      if (inventoryStacks[i] == null) {
        return null;
      }

      if (inventoryStacks[i].stackSize <= j) {
        ItemStack product = inventoryStacks[i];
        inventoryStacks[i] = null;
        return product;
      }
      ItemStack product = inventoryStacks[i].splitStack(j);
      if (inventoryStacks[i].stackSize == 0) {
        inventoryStacks[i] = null;
      }
      return product;
    }

    public void onInventoryChanged()
    {
      if (!Proxies.common.isSimulating(player.worldObj))
        return;
      tryImprint();
    }

    public void setInventorySlotContents(int i, ItemStack itemstack)
    {
      inventoryStacks[i] = itemstack;
    }

    public ItemStack getStackInSlot(int i)
    {
      return inventoryStacks[i];
    }

    public int getSizeInventory()
    {
      return inventoryStacks.length;
    }

    public String getInvName()
    {
      return "Imprinter";
    }

    public int getInventoryStackLimit()
    {
      return 64;
    }

    public boolean isUseableByPlayer(EntityPlayer entityplayer)
    {
      return true;
    }

    public void openChest()
    {
    }

    public void closeChest()
    {
    }

    public ItemStack getStackInSlotOnClosing(int slot)
    {
      if (inventoryStacks[slot] == null)
        return null;
      ItemStack toReturn = inventoryStacks[slot];
      inventoryStacks[slot] = null;
      return toReturn;
    }

    public boolean isInvNameLocalized()
    {
      return true;
    }

    public boolean isItemValidForSlot(int i, ItemStack itemstack)
    {
      return true;
    }
  }
}