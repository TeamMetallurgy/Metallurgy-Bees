package forestry.apiculture.items;

import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IHiveFrame;
import forestry.api.core.Tabs;
import forestry.core.items.ItemForestry;
import net.minecraft.item.ItemStack;

public class ItemHiveFrame extends ItemForestry
  implements IHiveFrame
{
  private float geneticDecay;

  public ItemHiveFrame(int id, int maxDamage, float geneticDecay)
  {
    super(id);
    setMaxStackSize(1);
    setMaxDamage(maxDamage);
    this.geneticDecay = geneticDecay;
    setCreativeTab(Tabs.tabApiculture);
  }

  public ItemStack frameUsed(IBeeHousing housing, ItemStack frame, IBee queen, int wear)
  {
    frame.setItemDamage(frame.getItemDamage() + wear);
    if (frame.getItemDamage() >= frame.getMaxDamage()) {
      return null;
    }
    return frame;
  }

  public float getTerritoryModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getMutationModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return 1.0F;
  }

  public float getLifespanModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return 1.0F;
  }

  public float getProductionModifier(IBeeGenome genome, float currentModifier)
  {
    return currentModifier < 10.0F ? 2.0F : 1.0F;
  }

  public float getFloweringModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getGeneticDecay(IBeeGenome genome, float currentModifier)
  {
    return geneticDecay;
  }

  public boolean isSealed()
  {
    return false;
  }

  public boolean isSelfLighted()
  {
    return false;
  }

  public boolean isSunlightSimulated()
  {
    return false;
  }

  public boolean isHellish()
  {
    return false;
  }

  public boolean isBookEnchantable(ItemStack itemstack1, ItemStack itemstack2)
  {
    return false;
  }
}