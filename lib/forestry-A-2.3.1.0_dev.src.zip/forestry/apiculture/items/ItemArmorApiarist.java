package forestry.apiculture.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.IArmorApiarist;
import forestry.api.core.IArmorNaturalist;
import forestry.api.core.Tabs;
import forestry.core.config.Defaults;
import forestry.core.config.ForestryItem;
import forestry.core.render.TextureManager;
import forestry.core.utils.StringUtil;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumArmorMaterial;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;

public class ItemArmorApiarist extends ItemArmor
  implements IArmorApiarist, IArmorNaturalist
{
  public ItemArmorApiarist(int id, int slot)
  {
    super(id, EnumArmorMaterial.CLOTH, 0, slot);
    setMaxDamage(100);
    setCreativeTab(Tabs.tabApiculture);
  }

  public String getArmorTexture(ItemStack stack, Entity entity, int slot, int layer)
  {
    if (ForestryItem.apiaristLegs.isItemEqual(stack)) {
      return Defaults.ID + ":" + "textures/items/apiarist_armor_2.png";
    }
    return Defaults.ID + ":" + "textures/items/apiarist_armor_1.png";
  }

  public String getItemDisplayName(ItemStack itemstack)
  {
    return StringUtil.localize(getUnlocalizedName(itemstack));
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    itemIcon = TextureManager.getInstance().registerTex(register, getUnlocalizedName().replace("item.", ""));
  }

  @SideOnly(Side.CLIENT)
  public Icon getIconFromDamageForRenderPass(int par1, int par2)
  {
    return itemIcon;
  }

  public boolean requiresMultipleRenderPasses()
  {
    return false;
  }

  public int getColorFromItemStack(ItemStack itemstack, int renderPass)
  {
    return 16777215;
  }

  public boolean hasColor(ItemStack itemstack)
  {
    return false;
  }

  public boolean protectPlayer(EntityPlayer player, ItemStack armor, String cause, boolean doProtect)
  {
    return true;
  }

  public boolean canSeePollination(EntityPlayer player, ItemStack armor, boolean doSee)
  {
    return armorType == 0;
  }

  public static boolean wearsHelmet(EntityPlayer player, String cause, boolean protect) {
    ItemStack armorItem = inventory.armorInventory[3];
    return (armorItem != null) && ((armorItem.getItem() instanceof IArmorNaturalist)) && (((IArmorNaturalist)armorItem.getItem()).protectPlayer(player, armorItem, cause, protect));
  }

  public static boolean wearsChest(EntityPlayer player, String cause, boolean protect)
  {
    ItemStack armorItem = inventory.armorInventory[2];
    return (armorItem != null) && ((armorItem.getItem() instanceof IArmorNaturalist)) && (((IArmorNaturalist)armorItem.getItem()).protectPlayer(player, armorItem, cause, protect));
  }

  public static boolean wearsLegs(EntityPlayer player, String cause, boolean protect)
  {
    ItemStack armorItem = inventory.armorInventory[1];
    return (armorItem != null) && ((armorItem.getItem() instanceof IArmorNaturalist)) && (((IArmorNaturalist)armorItem.getItem()).protectPlayer(player, armorItem, cause, protect));
  }

  public static boolean wearsBoots(EntityPlayer player, String cause, boolean protect)
  {
    ItemStack armorItem = inventory.armorInventory[0];
    return (armorItem != null) && ((armorItem.getItem() instanceof IArmorNaturalist)) && (((IArmorNaturalist)armorItem.getItem()).protectPlayer(player, armorItem, cause, protect));
  }

  public static int wearsItems(EntityPlayer player, String cause, boolean protect)
  {
    int count = 0;

    if (wearsHelmet(player, cause, protect))
      count++;
    if (wearsChest(player, cause, protect))
      count++;
    if (wearsLegs(player, cause, protect))
      count++;
    if (wearsBoots(player, cause, protect)) {
      count++;
    }
    return count;
  }
}