package forestry.apiculture.items;

import forestry.api.apiculture.IApiaristTracker;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.ForestryAPI;
import forestry.api.core.Tabs;
import forestry.core.EnumErrorCode;
import forestry.core.config.Config;
import forestry.core.config.ForestryItem;
import forestry.core.interfaces.IErrorSource;
import forestry.core.interfaces.IHintSource;
import forestry.core.items.ItemInventoried;
import forestry.core.network.GuiId;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.ItemInventory;
import forestry.plugins.PluginApiculture;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;

public class ItemBeealyzer extends ItemInventoried
{
  public ItemBeealyzer(int i)
  {
    super(i);
    setMaxStackSize(1);
    setCreativeTab(Tabs.tabApiculture);
  }

  public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
  {
    if (Proxies.common.isSimulating(world)) {
      entityplayer.openGui(ForestryAPI.instance, GuiId.BeealyzerGUI.ordinal(), world, (int)entityplayer.posX, (int)entityplayer.posY, (int)entityplayer.posZ);
    }

    return itemstack;
  }

  public static class BeealyzerInventory extends ItemInventory
    implements IErrorSource, IHintSource
  {
    public static final int SLOT_SPECIMEN = 0;
    public static final int SLOT_ANALYZE_1 = 1;
    public static final int SLOT_ANALYZE_2 = 2;
    public static final int SLOT_ANALYZE_3 = 3;
    public static final int SLOT_ANALYZE_4 = 4;
    public static final int SLOT_ANALYZE_5 = 6;
    public static final int SLOT_ENERGY = 5;
    EntityPlayer player;

    public BeealyzerInventory(EntityPlayer player)
    {
      super(7);
      this.player = player;
    }

    public BeealyzerInventory(EntityPlayer player, ItemStack itemStack) {
      super(7, itemStack);
      this.player = player;
    }

    public void writeToNBT(NBTTagCompound nbttagcompound)
    {
      NBTTagList nbttaglist = new NBTTagList();
      for (int i = 5; i < 6; i++)
        if (inventoryStacks[i] != null) {
          NBTTagCompound nbttagcompound1 = new NBTTagCompound();
          nbttagcompound1.setByte("Slot", (byte)i);
          inventoryStacks[i].writeToNBT(nbttagcompound1);
          nbttaglist.appendTag(nbttagcompound1);
        }
      nbttagcompound.setTag("Items", nbttaglist);
    }

    private boolean isEnergy(ItemStack itemstack)
    {
      if ((itemstack == null) || (itemstack.stackSize <= 0)) {
        return false;
      }
      return (ForestryItem.honeyDrop.isItemEqual(itemstack)) || (ForestryItem.honeydew.isItemEqual(itemstack));
    }

    private void tryAnalyze()
    {
      if ((inventoryStacks[1] != null) || (inventoryStacks[2] != null) || (inventoryStacks[3] != null) || (inventoryStacks[4] != null) || (inventoryStacks[6] != null))
      {
        return;
      }

      if (getStackInSlot(0) == null) {
        return;
      }
      IBee bee = PluginApiculture.beeInterface.getMember(getStackInSlot(0));

      if (bee == null) {
        return;
      }

      if (!bee.isAnalyzed())
      {
        if (!isEnergy(getStackInSlot(5))) {
          return;
        }
        bee.analyze();
        if (player != null) {
          PluginApiculture.beeInterface.getBreedingTracker(player.worldObj, player.username).registerSpecies(bee.getGenome().getPrimary());
          PluginApiculture.beeInterface.getBreedingTracker(player.worldObj, player.username).registerSpecies(bee.getGenome().getSecondary());
        }

        NBTTagCompound nbttagcompound = new NBTTagCompound("tag");
        bee.writeToNBT(nbttagcompound);
        getStackInSlot(0).setTagCompound(nbttagcompound);

        decrStackSize(5, 1);
      }

      setInventorySlotContents(1, getStackInSlot(0));
      setInventorySlotContents(0, null);
    }

    public void onInventoryChanged()
    {
      tryAnalyze();
    }

    public boolean hasHints()
    {
      return (Config.hints.get("beealyzer") != null) && (((String[])Config.hints.get("beealyzer")).length > 0);
    }

    public String[] getHints()
    {
      return (String[])Config.hints.get("beealyzer");
    }

    public boolean throwsErrors()
    {
      return true;
    }

    public EnumErrorCode getErrorState()
    {
      if ((PluginApiculture.beeInterface.isMember(inventoryStacks[0])) && (!isEnergy(getStackInSlot(5)))) {
        return EnumErrorCode.NOHONEY;
      }
      return EnumErrorCode.OK;
    }
  }
}