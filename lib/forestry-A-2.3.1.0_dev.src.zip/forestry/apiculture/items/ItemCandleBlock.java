package forestry.apiculture.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.apiculture.gadgets.BlockCandle;
import forestry.core.items.ItemForestryBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.Icon;

public class ItemCandleBlock extends ItemForestryBlock
{
  public ItemCandleBlock(int i)
  {
    super(i);
  }

  @SideOnly(Side.CLIENT)
  public int getColorFromItemStack(ItemStack stack, int pass)
  {
    int value = 16777215;
    if ((pass == 1) && (stack.hasTagCompound())) {
      NBTTagCompound tag = stack.getTagCompound();
      if (tag.hasKey("colour")) {
        value = tag.getInteger("colour");
      }
    }
    return value;
  }

  public String getUnlocalizedName(ItemStack itemStack)
  {
    String value = "tile.candle";
    if ((itemStack.hasTagCompound()) && (itemStack.getTagCompound().hasKey("colour"))) {
      value = value + ".dyed";
    }

    if (BlockCandle.isLit(itemStack)) {
      value = value + ".lit";
    }
    else {
      value = value + ".stump";
    }
    return value;
  }

  @SideOnly(Side.CLIENT)
  public Icon getIconFromDamageForRenderPass(int meta, int pass)
  {
    return ((BlockCandle)getBlock()).getTextureFromPassAndMeta(meta != 0 ? 8 : 0, pass);
  }

  @SideOnly(Side.CLIENT)
  public boolean requiresMultipleRenderPasses()
  {
    return true;
  }

  public int getRenderPasses(int metadata)
  {
    return 2;
  }
}