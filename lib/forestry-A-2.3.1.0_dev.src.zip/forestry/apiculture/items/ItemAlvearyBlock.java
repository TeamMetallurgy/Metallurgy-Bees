package forestry.apiculture.items;

import forestry.core.gadgets.IStructureBlockItem;
import forestry.core.items.ItemForestryBlock;

public class ItemAlvearyBlock extends ItemForestryBlock
  implements IStructureBlockItem
{
  public ItemAlvearyBlock(int id)
  {
    super(id);
  }
}