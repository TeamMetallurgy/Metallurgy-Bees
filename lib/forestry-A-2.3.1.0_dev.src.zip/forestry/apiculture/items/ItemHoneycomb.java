package forestry.apiculture.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.core.Tabs;
import forestry.core.config.Config;
import forestry.core.config.ForestryItem;
import forestry.core.items.ItemForestry;
import forestry.core.render.TextureManager;
import forestry.core.utils.StringUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;

public class ItemHoneycomb extends ItemForestry
{
  public CombInfo[] combs = { new CombInfo("honey", 15258986, 16752939), new CombInfo("cocoa", 6766614, 16758315).setIsSecret(), new CombInfo("simmering", 9967897, 16758315), new CombInfo("stringy", 13155943, 12429630), new CombInfo("frozen", 16383999, 10551295), new CombInfo("dripping", 14448147, 16776960), new CombInfo("silky", 5277959, 14548736), new CombInfo("parched", 14466579, 16776960), new CombInfo("mysterious", 1447446, 14719487).setIsSecret(), new CombInfo("irradiated", 15400947, 15662848).setIsSecret(), new CombInfo("powdery", 15000804, 16777215).setIsSecret(), new CombInfo("reddened", 4915200, 6422759).setIsSecret(), new CombInfo("darkened", 3487029, 3402699).setIsSecret(), new CombInfo("omega", 1644825, 7196662).setIsSecret(), new CombInfo("wheaten", 16711567, 16777215).setIsSecret(), new CombInfo("mossy", 2765587, 8296761), new CombInfo("mellow", 8937472, 16775520) };

  @SideOnly(Side.CLIENT)
  private Icon[] icons;

  public ItemHoneycomb(int i)
  {
    super(i);
    setMaxDamage(0);
    setHasSubtypes(true);
    setCreativeTab(Tabs.tabApiculture);
  }

  public boolean isDamageable()
  {
    return false;
  }

  public boolean isRepairable()
  {
    return false;
  }

  public String getItemDisplayName(ItemStack itemstack)
  {
    if ((itemstack.getItemDamage() < 0) || (itemstack.getItemDamage() >= combs.length)) {
      return null;
    }
    return StringUtil.localize("item.comb." + combs[itemstack.getItemDamage()].name);
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    icons = new Icon[2];
    icons[0] = TextureManager.getInstance().registerTex(register, getUnlocalizedName().replace("item.", "") + ".0");
    icons[1] = TextureManager.getInstance().registerTex(register, getUnlocalizedName().replace("item.", "") + ".1");
  }

  @SideOnly(Side.CLIENT)
  public Icon getIconFromDamageForRenderPass(int i, int j)
  {
    if (j > 0) {
      return icons[0];
    }
    return icons[1];
  }

  public boolean requiresMultipleRenderPasses()
  {
    return true;
  }

  public int getColorFromItemStack(ItemStack itemstack, int j)
  {
    if (j == 0) {
      return combs[itemstack.getItemDamage()].primaryColor;
    }
    return combs[itemstack.getItemDamage()].secondaryColor;
  }

  public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List itemList)
  {
    for (int i = 0; i < combs.length; i++)
      if ((!combs[i].isSecret) || (Config.isDebug))
        itemList.add(new ItemStack(this, 1, i));
  }

  public int getCombTypeCount()
  {
    return combs.length;
  }

  public int getRandomCombType(Random random, boolean includeSecret) {
    List validCombs = new ArrayList(getCombTypeCount());
    for (int i = 0; i < combs.length; i++) {
      if ((!combs[i].isSecret) || (includeSecret)) {
        validCombs.add(Integer.valueOf(i));
      }
    }
    if (validCombs.isEmpty()) {
      return 0;
    }
    return ((Integer)validCombs.get(random.nextInt(validCombs.size()))).intValue();
  }

  public static ItemStack getRandomComb(int qty, Random random, boolean includeSecret) {
    return ForestryItem.beeComb.getItemStack(qty, ((ItemHoneycomb)ForestryItem.beeComb.item()).getRandomCombType(random, includeSecret));
  }

  private static class CombInfo
  {
    public String name;
    public int primaryColor;
    public int secondaryColor;
    public boolean isSecret = false;

    public CombInfo(String name, int primaryColor, int secondaryColor) {
      this.name = name;
      this.primaryColor = primaryColor;
      this.secondaryColor = secondaryColor;
    }

    public CombInfo setIsSecret() {
      isSecret = true;
      return this;
    }
  }
}