package forestry.apiculture.items;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.ForestryAPI;
import forestry.api.core.Tabs;
import forestry.apiculture.render.TextureBiomefinder;
import forestry.core.EnumErrorCode;
import forestry.core.config.Config;
import forestry.core.config.ForestryItem;
import forestry.core.interfaces.IErrorSource;
import forestry.core.interfaces.IHintSource;
import forestry.core.items.ItemInventoried;
import forestry.core.network.GuiId;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.ItemInventory;
import forestry.core.utils.Vect;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;

public class ItemBiomefinder extends ItemInventoried
{
  public ItemBiomefinder(int id)
  {
    super(id);
    setMaxStackSize(1);
    setCreativeTab(Tabs.tabApiculture);
  }

  public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
  {
    if (Proxies.common.isSimulating(world)) {
      entityplayer.openGui(ForestryAPI.instance, GuiId.HabitatLocatorGUI.ordinal(), world, (int)entityplayer.posX, (int)entityplayer.posY, (int)entityplayer.posZ);
    }

    return itemstack;
  }

  public void startBiomeSearch(World world, EntityPlayer player, ArrayList<Integer> biomesToSearch)
  {
    ArrayList excludedBiomes = new ArrayList();
    excludedBiomes.add(Integer.valueOf(BiomeGenBase.ocean.biomeID));
    excludedBiomes.add(Integer.valueOf(BiomeGenBase.frozenOcean.biomeID));
    excludedBiomes.add(Integer.valueOf(BiomeGenBase.beach.biomeID));
    biomesToSearch.removeAll(excludedBiomes);

    BiomeGenBase biome = world.getBiomeGenForCoords((int)player.posX, (int)player.posZ);
    if (biomesToSearch.contains(Integer.valueOf(biome.biomeID))) {
      Proxies.common.setBiomefinderCoordinates(player, new ChunkCoordinates((int)player.posX, (int)player.posY, (int)player.posZ));
      return;
    }

    if ((Proxies.common.isSimulating(world)) && (biomesToSearch.size() > 0)) {
      ChunkCoordinates target = findNearestBiome(player, biomesToSearch);
      Proxies.common.setBiomefinderCoordinates(player, target);
    }
  }

  private ChunkCoordinates findNearestBiome(EntityPlayer player, ArrayList<Integer> biomesToSearch)
  {
    int loadChunkDistance = 25;
    ChunkCoordinates coordinates = null;
    Vect pos = new Vect((int)player.posX, (int)player.posY, (int)player.posZ);
    for (int i = 0; i < 100; i++)
    {
      if ((coordinates = getChunkCoordinates(pos.add(new Vect(10 * i, 0, 0)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }
      if ((coordinates = getChunkCoordinates(pos.add(new Vect(10 * i, 0, 10 * i)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }
      if ((coordinates = getChunkCoordinates(pos.add(new Vect(10 * i, 0, -10 * i)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }

      if ((coordinates = getChunkCoordinates(pos.add(new Vect(-10 * i, 0, 0)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }
      if ((coordinates = getChunkCoordinates(pos.add(new Vect(-10 * i, 0, 10 * i)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }
      if ((coordinates = getChunkCoordinates(pos.add(new Vect(-10 * i, 0, -10 * i)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }

      if ((coordinates = getChunkCoordinates(pos.add(new Vect(0, 0, 10 * i)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null) {
        return coordinates;
      }
      if ((coordinates = getChunkCoordinates(pos.add(new Vect(0, 0, -10 * i)), player.worldObj, biomesToSearch, i < loadChunkDistance)) != null)
        return coordinates;
    }
    return coordinates;
  }

  private ChunkCoordinates getChunkCoordinates(Vect pos, World world, ArrayList<Integer> biomesToSearch, boolean loadChunks)
  {
    BiomeGenBase biome = world.getBiomeGenForCoords(pos.x, pos.z);

    if (biomesToSearch.contains(Integer.valueOf(biome.biomeID))) {
      return new ChunkCoordinates(pos.x, pos.y, pos.z);
    }
    return null;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    if ((register instanceof TextureMap)) {
      TextureAtlasSprite texture = new TextureBiomefinder();
      ((TextureMap)register).setTextureEntry("forestry:biomefinder", texture);
      itemIcon = texture;
    }
  }

  public static class BiomefinderInventory extends ItemInventory
    implements IErrorSource, IHintSource
  {
    public ArrayList<Integer> biomesToSearch = new ArrayList();

    private short energySlot = 2;
    private short specimenSlot = 0;
    private short analyzeSlot = 1;

    public BiomefinderInventory() {
      super(3);
    }

    public BiomefinderInventory(ItemStack itemstack) {
      super(3, itemstack);
    }

    public void writeToNBT(NBTTagCompound nbttagcompound)
    {
      NBTTagList nbttaglist = new NBTTagList();
      for (int i = 2; i < inventoryStacks.length; i++)
        if (inventoryStacks[i] != null) {
          NBTTagCompound nbttagcompound1 = new NBTTagCompound();
          nbttagcompound1.setByte("Slot", (byte)i);
          inventoryStacks[i].writeToNBT(nbttagcompound1);
          nbttaglist.appendTag(nbttagcompound1);
        }
      nbttagcompound.setTag("Items", nbttaglist);
    }

    private boolean isEnergy(ItemStack itemstack)
    {
      if ((itemstack == null) || (itemstack.stackSize <= 0)) {
        return false;
      }
      return (ForestryItem.honeyDrop.isItemEqual(itemstack)) || (ForestryItem.honeydew.isItemEqual(itemstack));
    }

    private void tryAnalyze()
    {
      if (inventoryStacks[analyzeSlot] != null) {
        return;
      }

      if (getStackInSlot(specimenSlot) == null) {
        return;
      }
      IBee bee = PluginApiculture.beeInterface.getMember(getStackInSlot(specimenSlot));

      if (bee == null) {
        return;
      }

      if (!isEnergy(getStackInSlot(energySlot))) {
        return;
      }
      biomesToSearch = bee.getSuitableBiomeIds();

      decrStackSize(energySlot, 1);

      setInventorySlotContents(analyzeSlot, getStackInSlot(specimenSlot));
      setInventorySlotContents(specimenSlot, null);
    }

    public void onInventoryChanged()
    {
      tryAnalyze();
    }

    public boolean hasHints()
    {
      return (Config.hints.get("habitatlocator") != null) && (((String[])Config.hints.get("habitatlocator")).length > 0);
    }

    public String[] getHints()
    {
      return (String[])Config.hints.get("habitatlocator");
    }

    public boolean throwsErrors()
    {
      return true;
    }

    public EnumErrorCode getErrorState()
    {
      if ((PluginApiculture.beeInterface.isMember(inventoryStacks[specimenSlot])) && (!isEnergy(getStackInSlot(energySlot)))) {
        return EnumErrorCode.NOHONEY;
      }
      return EnumErrorCode.OK;
    }
  }
}