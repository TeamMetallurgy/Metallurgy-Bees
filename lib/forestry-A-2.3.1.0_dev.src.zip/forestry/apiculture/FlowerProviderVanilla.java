package forestry.apiculture;

import forestry.api.apiculture.FlowerManager;
import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IPollinatable;
import forestry.core.utils.StringUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockGrass;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.EnumPlantType;

public class FlowerProviderVanilla
  implements IFlowerProvider
{
  public boolean isAcceptedFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);
    int meta = world.getBlockMetadata(x, y, z);

    if (blockid == Block.flowerPot.blockID) {
      return checkFlowerPot(meta);
    }
    ItemStack flower = new ItemStack(blockid, 1, meta);

    for (ItemStack stack : FlowerManager.plainFlowers) {
      if (flower.isItemEqual(stack))
        return true;
    }
    return false;
  }

  public boolean isAcceptedPollinatable(World world, IPollinatable pollinatable)
  {
    EnumSet types = pollinatable.getPlantType();
    return (types.size() > 1) || (!types.contains(EnumPlantType.Nether));
  }

  private boolean checkFlowerPot(int meta) {
    if ((meta == 1) || (meta == 2)) {
      return true;
    }
    return false;
  }

  public boolean growFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);

    if (blockid != 0) {
      if ((blockid == Block.flowerPot.blockID) && (world.getBlockMetadata(x, y, z) == 0)) {
        return growInPot(world, x, y, z);
      }
      return false;
    }

    int groundid = world.getBlockId(x, y - 1, z);

    if ((groundid != Block.dirt.blockID) && (groundid != Block.grass.blockID)) {
      return false;
    }

    Collections.shuffle(FlowerManager.plainFlowers);
    ItemStack flower = (ItemStack)FlowerManager.plainFlowers.get(world.rand.nextInt(FlowerManager.plainFlowers.size() - 1));
    world.setBlock(x, y, z, flower.itemID, flower.getItemDamage(), 2);
    return true;
  }

  private boolean growInPot(World world, int x, int y, int z) {
    if (world.rand.nextBoolean())
      world.setBlock(x, y, z, Block.flowerPot.blockID, 1, 2);
    else
      world.setBlock(x, y, z, Block.flowerPot.blockID, 2, 2);
    return true;
  }

  public String getDescription()
  {
    return StringUtil.localize("flowers.vanilla");
  }

  public ItemStack[] affectProducts(World world, IIndividual individual, int x, int y, int z, ItemStack[] products)
  {
    return products;
  }

  public ItemStack[] getItemStacks()
  {
    return (ItemStack[])FlowerManager.plainFlowers.toArray(new ItemStack[0]);
  }
}