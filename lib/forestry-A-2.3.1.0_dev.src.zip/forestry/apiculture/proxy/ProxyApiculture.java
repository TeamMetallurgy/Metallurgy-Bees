package forestry.apiculture.proxy;

import forestry.core.interfaces.IBlockRenderer;
import net.minecraft.world.World;

public class ProxyApiculture
{
  public void addBeeHiveFX(String texture, World world, double xCoord, double yCoord, double zCoord, int color, int areaX, int areaY, int areaZ)
  {
  }

  public void addBeeSwarmFX(String texture, World world, double xCoord, double yCoord, double zCoord, int color)
  {
  }

  public IBlockRenderer getRendererAnalyzer(String string)
  {
    return null;
  }

  public void addLocalizations()
  {
  }

  public void initializeRendering()
  {
  }
}