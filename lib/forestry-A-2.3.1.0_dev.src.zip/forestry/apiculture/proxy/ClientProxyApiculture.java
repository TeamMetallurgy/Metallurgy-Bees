package forestry.apiculture.proxy;

import cpw.mods.fml.client.registry.RenderingRegistry;
import forestry.apiculture.entities.EntityBee;
import forestry.apiculture.render.BeeItemRenderer;
import forestry.apiculture.render.EntityBeeFX;
import forestry.apiculture.render.ParticleRenderer;
import forestry.apiculture.render.RenderBee;
import forestry.core.config.Config;
import forestry.core.config.ForestryItem;
import forestry.core.interfaces.IBlockRenderer;
import forestry.core.render.RenderAnalyzer;
import forestry.core.render.TextureManager;
import forestry.core.utils.Localization;
import forestry.plugins.PluginApiculture;
import java.util.Random;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.item.Item;
import net.minecraft.world.World;
import net.minecraftforge.client.MinecraftForgeClient;

public class ClientProxyApiculture extends ProxyApiculture
{
  public void initializeRendering()
  {
    if (PluginApiculture.fancyRenderedBees) {
      RenderingRegistry.registerEntityRenderingHandler(EntityBee.class, new RenderBee());

      MinecraftForgeClient.registerItemRenderer(ForestryItem.beeDroneGE.item().itemID, new BeeItemRenderer());
      MinecraftForgeClient.registerItemRenderer(ForestryItem.beePrincessGE.item().itemID, new BeeItemRenderer());
      MinecraftForgeClient.registerItemRenderer(ForestryItem.beeQueenGE.item().itemID, new BeeItemRenderer());
    }
  }

  public void addBeeHiveFX(String icon, World world, double xCoord, double yCoord, double zCoord, int color, int areaX, int areaY, int areaZ)
  {
    if (!Config.enableParticleFX)
      return;
    EntityFX fx;
    EntityFX fx;
    if (world.rand.nextBoolean()) {
      fx = new EntityBeeFX(world, xCoord + 0.5D, yCoord + 0.75D, zCoord + 0.5D, 0.0F, 0.0F, 0.0F, color);
    } else {
      double spawnX = xCoord + world.rand.nextInt(areaX * 2) - areaX;
      double spawnY = yCoord + world.rand.nextInt(areaY);
      double spawnZ = zCoord + world.rand.nextInt(areaZ * 2) - areaZ;

      fx = new EntityBeeFX(world, spawnX, spawnY, spawnZ, 0.0F, 0.0F, 0.0F, color);
    }

    fx.setParticleIcon(TextureManager.getInstance().getDefault(icon));
    ParticleRenderer.getInstance().addEffect(fx);
  }

  public void addBeeSwarmFX(String icon, World world, double xCoord, double yCoord, double zCoord, int color)
  {
    if (!Config.enableParticleFX)
      return;
    EntityFX fx;
    EntityFX fx;
    if (world.rand.nextBoolean()) {
      fx = new EntityBeeFX(world, xCoord, yCoord, zCoord, 0.0F, 0.0F, 0.0F, color);
    }
    else {
      double spawnX = xCoord + world.rand.nextInt(4) - 2.0D;
      double spawnY = yCoord + world.rand.nextInt(4) - 2.0D;
      double spawnZ = zCoord + world.rand.nextInt(4) - 2.0D;

      fx = new EntityBeeFX(world, spawnX, spawnY, spawnZ, 0.0F, 0.0F, 0.0F, color);
    }

    fx.setParticleIcon(TextureManager.getInstance().getDefault(icon));
    ParticleRenderer.getInstance().addEffect(fx);
  }

  public IBlockRenderer getRendererAnalyzer(String gfxBase)
  {
    return new RenderAnalyzer(gfxBase);
  }

  public void addLocalizations()
  {
    Localization.instance.addLocalization("/lang/forestry/apiculture/");
  }
}