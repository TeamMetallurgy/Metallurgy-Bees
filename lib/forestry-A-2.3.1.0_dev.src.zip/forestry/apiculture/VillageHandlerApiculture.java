package forestry.apiculture;

import cpw.mods.fml.common.registry.VillagerRegistry.IVillageCreationHandler;
import cpw.mods.fml.common.registry.VillagerRegistry.IVillageTradeHandler;
import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IBeeRoot;
import forestry.apiculture.genetics.BeeTemplates;
import forestry.apiculture.items.ItemHoneycomb;
import forestry.apiculture.worldgen.ComponentVillageBeeHouse;
import forestry.core.config.ForestryBlock;
import forestry.core.config.ForestryItem;
import forestry.plugins.PluginApiculture;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.gen.structure.ComponentVillageStartPiece;
import net.minecraft.world.gen.structure.MapGenStructureIO;
import net.minecraft.world.gen.structure.StructureVillagePieceWeight;

public class VillageHandlerApiculture
  implements VillagerRegistry.IVillageCreationHandler, VillagerRegistry.IVillageTradeHandler
{
  public static void registerVillageComponents()
  {
    try
    {
      MapGenStructureIO.func_143031_a(ComponentVillageBeeHouse.class, "Forestry:BeeHouse");
    }
    catch (Throwable e) {
    }
  }

  public void manipulateTradesForVillager(EntityVillager villager, MerchantRecipeList recipeList, Random random) {
    recipeList.add(new MerchantRecipe(ForestryItem.beePrincessGE.getItemStack(1, 32767), new ItemStack(Item.emerald, 1)));
    recipeList.add(new MerchantRecipe(new ItemStack(Item.wheat, 2), ItemHoneycomb.getRandomComb(1, random, false)));
    recipeList.add(new MerchantRecipe(new ItemStack(Block.wood, 24, 32767), new ItemStack(ForestryBlock.apiculture, 1, 0)));

    recipeList.add(new MerchantRecipe(new ItemStack(Item.emerald, 1), ForestryItem.frameProven.getItemStack(6)));
    recipeList.add(new MerchantRecipe(new ItemStack(Item.emerald, 12), ForestryItem.beePrincessGE.getItemStack(1, 32767), PluginApiculture.beeInterface.getMemberStack(PluginApiculture.beeInterface.getBee(villager.worldObj, PluginApiculture.beeInterface.templateAsGenome(BeeTemplates.getMonasticTemplate())), EnumBeeType.DRONE.ordinal())));
  }

  public StructureVillagePieceWeight getVillagePieceWeight(Random random, int size)
  {
    return new StructureVillagePieceWeight(ComponentVillageBeeHouse.class, 15, MathHelper.getRandomIntegerInRange(random, 0 + size, 1 + size));
  }

  public Class<?> getComponentClass()
  {
    return ComponentVillageBeeHouse.class;
  }

  public Object buildComponent(StructureVillagePieceWeight villagePiece, ComponentVillageStartPiece startPiece, List pieces, Random random, int p1, int p2, int p3, int p4, int p5)
  {
    return ComponentVillageBeeHouse.buildComponent(startPiece, pieces, random, p1, p2, p3, p4, p5);
  }
}