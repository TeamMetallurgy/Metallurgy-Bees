package forestry.apiculture.gui;

import forestry.apiculture.items.ItemBiomefinder.BiomefinderInventory;
import forestry.core.gui.GuiForestry;
import forestry.core.gui.WidgetManager;
import forestry.core.gui.widgets.Widget;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.render.SpriteSheet;
import forestry.core.render.TextureManager;
import forestry.core.utils.FontColour;
import forestry.core.utils.StringUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.Icon;
import net.minecraft.world.biome.BiomeGenBase;
import org.lwjgl.opengl.GL11;

public class GuiHabitatLocator extends GuiForestry
{
  private HabitatSlot[] habitatSlots = { new HabitatSlot(0, "Ocean"), new HabitatSlot(1, "Plains"), new HabitatSlot(2, "Desert"), new HabitatSlot(3, "Forest"), new HabitatSlot(4, "Jungle"), new HabitatSlot(5, "Taiga"), new HabitatSlot(6, "Hills"), new HabitatSlot(7, "Swampland"), new HabitatSlot(8, "Snow"), new HabitatSlot(9, "Mushroom"), new HabitatSlot(10, "Hell"), new HabitatSlot(11, "End") };

  private HashMap<Integer, HabitatSlot> biomeToHabitat = new HashMap();
  private int startX;
  private int startY;

  public GuiHabitatLocator(InventoryPlayer inventory, ItemBiomefinder.BiomefinderInventory item)
  {
    super("textures/gui/biomefinder.png", new ContainerHabitatLocator(inventory, item), item);

    xSize = 176;
    ySize = 184;

    for (HabitatSlot slot : habitatSlots)
    {
      int y;
      int x;
      int y;
      if (slot.slot > 5) {
        int x = 18 + (slot.slot - 6) * 20;
        y = 50;
      } else {
        x = 18 + slot.slot * 20;
        y = 32;
      }

      slot.setPosition(x, y);
      widgetManager.add(slot);
    }

    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.ocean.biomeID), habitatSlots[0]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.beach.biomeID), habitatSlots[0]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.plains.biomeID), habitatSlots[1]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.desert.biomeID), habitatSlots[2]);

    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.forest.biomeID), habitatSlots[3]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.forestHills.biomeID), habitatSlots[3]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.river.biomeID), habitatSlots[3]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.jungle.biomeID), habitatSlots[4]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.jungleHills.biomeID), habitatSlots[4]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.taiga.biomeID), habitatSlots[5]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.taigaHills.biomeID), habitatSlots[5]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.extremeHills.biomeID), habitatSlots[6]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.extremeHillsEdge.biomeID), habitatSlots[6]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.swampland.biomeID), habitatSlots[7]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.frozenOcean.biomeID), habitatSlots[8]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.frozenRiver.biomeID), habitatSlots[8]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.iceMountains.biomeID), habitatSlots[8]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.icePlains.biomeID), habitatSlots[8]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.mushroomIsland.biomeID), habitatSlots[9]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.mushroomIslandShore.biomeID), habitatSlots[9]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.hell.biomeID), habitatSlots[10]);
    biomeToHabitat.put(Integer.valueOf(BiomeGenBase.sky.biomeID), habitatSlots[11]);
  }

  protected void drawGuiContainerBackgroundLayer(float var1, int mouseX, int mouseY)
  {
    super.drawGuiContainerBackgroundLayer(var1, mouseX, mouseY);

    String str = StringUtil.localize("gui.habitatlocator").toUpperCase();
    fontRenderer.drawString(str, startX + 8 + getCenteredOffset(str, 138), startY + 16, fontColor.get("gui.screen"));

    str = "(" + StringUtil.localize("gui.closetosearch") + ")";
    fontRenderer.drawString(str, startX + 8 + getCenteredOffset(str, 138), startY + 76, fontColor.get("gui.table.header"));

    for (HabitatSlot slot : habitatSlots) {
      slot.isActive = false;
    }

    ArrayList biomeids = ((ContainerHabitatLocator)inventorySlots).inventory.biomesToSearch;
    for (Iterator i$ = biomeids.iterator(); i$.hasNext(); ) { int biomeid = ((Integer)i$.next()).intValue();
      if (biomeToHabitat.containsKey(Integer.valueOf(biomeid)))
      {
        ((HabitatSlot)biomeToHabitat.get(Integer.valueOf(biomeid))).isActive = true;
      }
    }
    for (HabitatSlot slot : habitatSlots)
      slot.draw(startX, startY);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
  }

  public void initGui()
  {
    super.initGui();

    startX = ((width - xSize) / 2);
    startY = ((height - ySize) / 2);
  }

  public class HabitatSlot extends Widget
  {
    private final int slot;
    private final String name;
    private final String iconIndex;
    public boolean isActive = false;

    public HabitatSlot(int slot, String name) {
      super(0, 0);
      this.slot = slot;
      this.name = name;
      iconIndex = ("habitats/" + name.toLowerCase(Locale.ENGLISH));
    }

    public String getLegacyTooltip(EntityPlayer player)
    {
      return name;
    }

    public Icon getIcon() {
      return TextureManager.getInstance().getDefault(iconIndex);
    }

    public void setPosition(int x, int y) {
      xPos = x;
      yPos = y;
    }

    public void draw(int startX, int startY)
    {
      if (getIcon() != null) {
        GL11.glDisable(2896);

        if (!isActive) {
          GL11.glColor4f(0.2F, 0.2F, 0.2F, 0.2F);
        }
        Proxies.common.bindTexture(SpriteSheet.ITEMS);
        manager.gui.drawTexturedModelRectFromIcon(startX + xPos, startY + yPos, getIcon(), 16, 16);
        GL11.glEnable(2896);
      }
    }
  }
}