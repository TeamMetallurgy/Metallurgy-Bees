package forestry.apiculture.gui;

import forestry.apiculture.gadgets.TileAlvearySieve;
import forestry.core.gui.GuiForestry;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiAlvearySieve extends GuiForestry
{
  public GuiAlvearySieve(InventoryPlayer inventory, TileAlvearySieve tile)
  {
    super("textures/gui/sieve.png", new ContainerAlvearySieve(inventory, tile));
  }
}