package forestry.apiculture.gui;

import forestry.apiculture.gadgets.TileAlvearyHygroregulator;
import forestry.core.gui.GuiForestry;
import forestry.core.gui.WidgetManager;
import forestry.core.gui.widgets.TankWidget;
import forestry.core.utils.FontColour;
import forestry.core.utils.StringUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiAlvearyHygroregulator extends GuiForestry
{
  public GuiAlvearyHygroregulator(InventoryPlayer inventory, TileAlvearyHygroregulator tile)
  {
    super("textures/gui/hygroregulator.png", new ContainerAlvearyHygroregulator(inventory, tile));

    widgetManager.add(new TankWidget(widgetManager, 104, 17, 0));
  }

  protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
  {
    super.drawGuiContainerForegroundLayer(mouseX, mouseY);
    String name = StringUtil.localize("tile.alveary.5");
    fontRenderer.drawString(name, getCenteredOffset(name), 6, fontColor.get("gui.title"));
  }
}