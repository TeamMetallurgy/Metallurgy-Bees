package forestry.apiculture.gui;

import forestry.apiculture.gadgets.TileAlvearySwarmer;
import forestry.core.gui.GuiForestry;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiAlvearySwarmer extends GuiForestry
{
  public GuiAlvearySwarmer(InventoryPlayer inventory, TileAlvearySwarmer tile)
  {
    super("textures/gui/swarmer.png", new ContainerAlvearySwarmer(inventory, tile));
  }
}