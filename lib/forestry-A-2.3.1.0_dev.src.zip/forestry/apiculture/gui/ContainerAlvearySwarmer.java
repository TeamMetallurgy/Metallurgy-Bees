package forestry.apiculture.gui;

import forestry.api.apiculture.BeeManager;
import forestry.apiculture.gadgets.TileAlvearySwarmer;
import forestry.core.gui.ContainerForestry;
import forestry.core.gui.slots.SlotCustom;
import java.util.HashMap;
import java.util.Set;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Slot;

public class ContainerAlvearySwarmer extends ContainerForestry
{
  public ContainerAlvearySwarmer(InventoryPlayer player, TileAlvearySwarmer tile)
  {
    super(tile);

    addSlot(new SlotCustom(tile, 0, 79, 52, getInducerItems()));
    addSlot(new SlotCustom(tile, 1, 100, 39, getInducerItems()));
    addSlot(new SlotCustom(tile, 2, 58, 39, getInducerItems()));
    addSlot(new SlotCustom(tile, 3, 79, 26, getInducerItems()));

    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 9; j++)
        addSlot(new Slot(player, j + i * 9 + 9, 8 + j * 18, 87 + i * 18));
    }
    for (int i = 0; i < 9; i++)
      addSlot(new Slot(player, i, 8 + i * 18, 145));
  }

  private Object[] getInducerItems()
  {
    return BeeManager.inducers.keySet().toArray(new Object[0]);
  }
}