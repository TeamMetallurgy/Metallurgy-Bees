package forestry.apiculture.gui;

import forestry.apiculture.items.ItemBeeGE;
import forestry.apiculture.items.ItemBiomefinder;
import forestry.apiculture.items.ItemBiomefinder.BiomefinderInventory;
import forestry.core.config.ForestryItem;
import forestry.core.gui.ContainerItemInventory;
import forestry.core.gui.slots.SlotCustom;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;

public class ContainerHabitatLocator extends ContainerItemInventory
{
  public ItemBiomefinder.BiomefinderInventory inventory;

  public ContainerHabitatLocator(InventoryPlayer inventoryplayer, ItemBiomefinder.BiomefinderInventory inventory)
  {
    super(inventory, inventoryplayer.player);

    this.inventory = inventory;

    addSlot(new SlotCustom(inventory, 2, 152, 8, new Object[] { ForestryItem.honeydew, ForestryItem.honeyDrop }));

    addSlot(new SlotCustom(inventory, 0, 152, 32, new Object[] { ItemBeeGE.class }));

    addSlot(new SlotCustom(inventory, 1, 152, 75, new Object[] { ItemBeeGE.class }));

    for (int i1 = 0; i1 < 3; i1++) {
      for (int l1 = 0; l1 < 9; l1++)
        addSecuredSlot(inventoryplayer, l1 + i1 * 9 + 9, 8 + l1 * 18, 102 + i1 * 18);
    }
    for (int j1 = 0; j1 < 9; j1++)
      addSecuredSlot(inventoryplayer, j1, 8 + j1 * 18, 160);
  }

  public void onContainerClosed(EntityPlayer entityplayer)
  {
    if (!Proxies.common.isSimulating(entityplayer.worldObj)) {
      return;
    }
    ((ItemBiomefinder)ForestryItem.biomeFinder.item()).startBiomeSearch(entityplayer.worldObj, entityplayer, inventory.biomesToSearch);

    for (int i = 0; i < inventory.getSizeInventory() - 1; i++) {
      ItemStack stack = inventory.getStackInSlot(i);
      if (stack != null)
      {
        Proxies.common.dropItemPlayer(entityplayer, stack);
        inventory.setInventorySlotContents(i, null);
      }
    }
    inventory.onGuiSaved(entityplayer);
  }

  protected boolean isAcceptedItem(EntityPlayer player, ItemStack stack)
  {
    return false;
  }
}