package forestry.apiculture.gui;

import forestry.apiculture.items.ItemBeeGE;
import forestry.apiculture.items.ItemImprinter.ImprinterInventory;
import forestry.core.gui.ContainerForestry;
import forestry.core.gui.IGuiSelectable;
import forestry.core.gui.slots.SlotCustom;
import forestry.core.network.PacketPayload;
import forestry.core.network.PacketUpdate;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.proxy.ProxyNetwork;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ContainerImprinter extends ContainerForestry
  implements IGuiSelectable
{
  public ItemImprinter.ImprinterInventory inventory;
  private boolean isNetSynched = false;

  public ContainerImprinter(InventoryPlayer inventoryplayer, ItemImprinter.ImprinterInventory inventory) {
    super(inventory);

    this.inventory = inventory;

    addSlot(new SlotCustom(inventory, 0, 152, 12, new Object[] { ItemBeeGE.class }));

    addSlot(new SlotCustom(inventory, 1, 152, 72, new Object[] { ItemBeeGE.class }));

    for (int i1 = 0; i1 < 3; i1++) {
      for (int l1 = 0; l1 < 9; l1++)
        addSlot(new Slot(inventoryplayer, l1 + i1 * 9 + 9, 8 + l1 * 18, 103 + i1 * 18));
    }
    for (int j1 = 0; j1 < 9; j1++)
      addSlot(new Slot(inventoryplayer, j1, 8 + j1 * 18, 161));
  }

  public void onContainerClosed(EntityPlayer entityplayer)
  {
    if (!Proxies.common.isSimulating(entityplayer.worldObj)) {
      return;
    }

    for (int i = 0; i < inventory.getSizeInventory(); i++) {
      ItemStack stack = inventory.getStackInSlot(i);
      if (stack != null)
      {
        Proxies.common.dropItemPlayer(entityplayer, stack);
        inventory.setInventorySlotContents(i, null);
      }
    }
  }

  public void advanceSelection(int index, World world) {
    PacketPayload payload = new PacketPayload(2, 0, 0);
    payload.intPayload[0] = index;
    payload.intPayload[1] = 0;
    sendSelectionChange(payload);
  }

  public void regressSelection(int index, World world) {
    PacketPayload payload = new PacketPayload(2, 0, 0);
    payload.intPayload[0] = index;
    payload.intPayload[1] = 1;
    sendSelectionChange(payload);
  }

  private void sendSelectionChange(PacketPayload payload) {
    PacketUpdate packet = new PacketUpdate(30, payload);
    Proxies.net.sendToServer(packet);
    isNetSynched = false;
  }

  public void setSelection(PacketUpdate packet)
  {
    inventory.setPrimaryIndex(packet.payload.intPayload[0]);
    inventory.setSecondaryIndex(packet.payload.intPayload[1]);
  }

  public void updateContainer(World world) {
    if ((!isNetSynched) && (!Proxies.common.isSimulating(world))) {
      isNetSynched = true;
      Proxies.net.sendToServer(new PacketUpdate(31));
    }
  }

  public void handleSelectionChange(EntityPlayer player, PacketUpdate packet)
  {
    if (packet.payload.intPayload[1] == 0) {
      if (packet.payload.intPayload[0] == 0)
        inventory.advancePrimary();
      else
        inventory.advanceSecondary();
    }
    else if (packet.payload.intPayload[0] == 0)
      inventory.regressPrimary();
    else
      inventory.regressSecondary();
  }

  public void sendSelection(EntityPlayer player) {
    PacketPayload payload = new PacketPayload(2, 0, 0);
    payload.intPayload[0] = inventory.getPrimaryIndex();
    payload.intPayload[1] = inventory.getSecondaryIndex();
    Proxies.net.sendToPlayer(new PacketUpdate(32, payload), player);
  }
}