package forestry.apiculture.gui;

import forestry.apiculture.gadgets.TileAlvearyHygroregulator;
import forestry.core.gui.ContainerLiquidTanks;
import forestry.core.gui.slots.SlotLiquidContainer;
import java.util.List;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;

public class ContainerAlvearyHygroregulator extends ContainerLiquidTanks
{
  TileAlvearyHygroregulator tile;

  public ContainerAlvearyHygroregulator(IInventory inventory, TileAlvearyHygroregulator tile)
  {
    super(inventory, tile);

    this.tile = tile;
    addSlot(new SlotLiquidContainer(tile, 0, 56, 38));

    for (int i = 0; i < 3; i++) {
      for (int var4 = 0; var4 < 9; var4++)
        addSlot(new Slot(inventory, var4 + i * 9 + 9, 8 + var4 * 18, 84 + i * 18));
    }
    for (int i = 0; i < 9; i++)
      addSlot(new Slot(inventory, i, 8 + i * 18, 142));
  }

  public void updateProgressBar(int i, int j)
  {
    tile.getGUINetworkData(i, j);
  }

  public void detectAndSendChanges()
  {
    super.detectAndSendChanges();

    for (int i = 0; i < crafters.size(); i++)
      tile.sendGUINetworkData(this, (ICrafting)crafters.get(i));
  }
}