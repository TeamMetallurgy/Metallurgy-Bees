package forestry.apiculture.gui;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeRoot;
import forestry.apiculture.items.ItemBeeGE;
import forestry.apiculture.items.ItemImprinter.ImprinterInventory;
import forestry.core.config.ForestryItem;
import forestry.core.gui.GuiForestry;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.FontColour;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;

public class GuiImprinter extends GuiForestry
{
  private ItemImprinter.ImprinterInventory inventory;
  private ContainerImprinter container;
  private int startX;
  private int startY;
  private HashMap<String, ItemStack> iconStacks = new HashMap();

  public GuiImprinter(InventoryPlayer inventoryplayer, ItemImprinter.ImprinterInventory inventory) {
    super("textures/gui/imprinter.png", new ContainerImprinter(inventoryplayer, inventory), inventory);

    this.inventory = inventory;
    container = ((ContainerImprinter)inventorySlots);

    xSize = 176;
    ySize = 185;

    ArrayList beeList = new ArrayList();
    ((ItemBeeGE)ForestryItem.beeDroneGE.item()).addCreativeItems(beeList, false);
    for (ItemStack beeStack : beeList)
      iconStacks.put(PluginApiculture.beeInterface.getMember(beeStack).getIdent(), beeStack);
  }

  protected void drawGuiContainerBackgroundLayer(float var1, int mouseX, int mouseY)
  {
    container.updateContainer(Proxies.common.getRenderWorld());
    super.drawGuiContainerBackgroundLayer(var1, mouseX, mouseY);

    int offset = (138 - fontRenderer.getStringWidth("GENOME IMPRINTER")) / 2;
    fontRenderer.drawString("GENOME IMPRINTER", startX + 8 + offset, startY + 16, fontColor.get("gui.screen"));

    IAlleleBeeSpecies primary = inventory.getPrimary();
    drawBeeSpeciesIcon(primary, startX + 12, startY + 32);
    fontRenderer.drawString(primary.getName(), startX + 32, startY + 36, fontColor.get("gui.screen"));

    IAlleleBeeSpecies secondary = inventory.getSecondary();
    drawBeeSpeciesIcon(secondary, startX + 12, startY + 52);
    fontRenderer.drawString(secondary.getName(), startX + 32, startY + 56, fontColor.get("gui.screen"));

    String youCheater = "(You Cheater!)";
    offset = (138 - fontRenderer.getStringWidth(youCheater)) / 2;
    fontRenderer.drawString(youCheater, startX + 8 + offset, startY + 76, fontColor.get("gui.screen"));
  }

  private void drawBeeSpeciesIcon(IAlleleBeeSpecies bee, int x, int y)
  {
  }

  private int getHabitatSlotAtPosition(int i, int j)
  {
    int[] xPos = { 12, 12 };
    int[] yPos = { 32, 52 };

    for (int l = 0; l < xPos.length; l++) {
      if ((i >= xPos[l]) && (i <= xPos[l] + 16) && (j >= yPos[l]) && (j <= yPos[l] + 16))
        return l;
    }
    return -1;
  }

  protected void mouseClicked(int i, int j, int k)
  {
    super.mouseClicked(i, j, k);

    int cornerX = (width - xSize) / 2;
    int cornerY = (height - ySize) / 2;

    int slot = 0;
    if ((slot = getHabitatSlotAtPosition(i - cornerX, j - cornerY)) < 0) {
      return;
    }
    if (k == 0)
      container.advanceSelection(slot, Proxies.common.getRenderWorld());
    else
      container.regressSelection(slot, Proxies.common.getRenderWorld());
  }

  public void initGui()
  {
    super.initGui();

    startX = ((width - xSize) / 2);
    startY = ((height - ySize) / 2);
  }
}