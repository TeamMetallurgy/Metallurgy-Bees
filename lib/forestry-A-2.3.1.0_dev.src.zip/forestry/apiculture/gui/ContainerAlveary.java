package forestry.apiculture.gui;

import forestry.apiculture.gadgets.TileAlvearyPlain;
import forestry.core.config.ForestryItem;
import forestry.core.gui.ContainerForestry;
import forestry.core.gui.slots.SlotClosed;
import forestry.core.gui.slots.SlotCustom;
import java.util.List;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.Slot;

public class ContainerAlveary extends ContainerForestry
{
  private TileAlvearyPlain tile;

  public ContainerAlveary(InventoryPlayer player, TileAlvearyPlain tile)
  {
    super(tile);

    this.tile = tile;
    tile.sendNetworkUpdate();

    addSlot(new SlotCustom(tile, 0, 29, 39, new Object[] { ForestryItem.beePrincessGE, ForestryItem.beeQueenGE }));

    addSlot(new SlotCustom(tile, 1, 29, 65, new Object[] { ForestryItem.beeDroneGE }));

    addSlot(new SlotClosed(tile, 2, 116, 52));
    addSlot(new SlotClosed(tile, 3, 137, 39));
    addSlot(new SlotClosed(tile, 4, 137, 65));
    addSlot(new SlotClosed(tile, 5, 116, 78));
    addSlot(new SlotClosed(tile, 6, 95, 65));
    addSlot(new SlotClosed(tile, 7, 95, 39));
    addSlot(new SlotClosed(tile, 8, 116, 26));

    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 9; j++)
        addSlot(new Slot(player, j + i * 9 + 9, 8 + j * 18, 108 + i * 18));
    }
    for (int i = 0; i < 9; i++)
      addSlot(new Slot(player, i, 8 + i * 18, 166));
  }

  public void updateProgressBar(int i, int j)
  {
    tile.getGUINetworkData(i, j);
  }

  public void detectAndSendChanges()
  {
    super.detectAndSendChanges();
    for (int i = 0; i < crafters.size(); i++)
      tile.sendGUINetworkData(this, (ICrafting)crafters.get(i));
  }
}