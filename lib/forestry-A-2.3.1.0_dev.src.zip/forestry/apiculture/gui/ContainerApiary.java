package forestry.apiculture.gui;

import forestry.api.apiculture.IHiveFrame;
import forestry.apiculture.gadgets.TileBeehouse;
import forestry.core.config.ForestryItem;
import forestry.core.gui.ContainerForestry;
import forestry.core.gui.slots.SlotClosed;
import forestry.core.gui.slots.SlotCustom;
import forestry.core.utils.Utils;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;

public class ContainerApiary extends ContainerForestry
{
  private TileBeehouse tile;

  public ContainerApiary(InventoryPlayer player, TileBeehouse tile, boolean hasFrames)
  {
    super(tile.getInternalInventory());

    this.tile = tile;
    tile.sendNetworkUpdate();
    IInventory inventory = tile.getInternalInventory();

    addSlot(new SlotCustom(inventory, 0, 29, 39, new Object[] { ForestryItem.beePrincessGE, ForestryItem.beeQueenGE }));

    addSlot(new SlotCustom(inventory, 1, 29, 65, new Object[] { ForestryItem.beeDroneGE }));

    if (hasFrames) {
      addSlot(new SlotCustom(inventory, 9, 66, 23, new Object[] { IHiveFrame.class }));
      addSlot(new SlotCustom(inventory, 10, 66, 52, new Object[] { IHiveFrame.class }));
      addSlot(new SlotCustom(inventory, 11, 66, 81, new Object[] { IHiveFrame.class }));
    }

    addSlot(new SlotClosed(inventory, 2, 116, 52));
    addSlot(new SlotClosed(inventory, 3, 137, 39));
    addSlot(new SlotClosed(inventory, 4, 137, 65));
    addSlot(new SlotClosed(inventory, 5, 116, 78));
    addSlot(new SlotClosed(inventory, 6, 95, 65));
    addSlot(new SlotClosed(inventory, 7, 95, 39));
    addSlot(new SlotClosed(inventory, 8, 116, 26));

    for (int i1 = 0; i1 < 3; i1++) {
      for (int l1 = 0; l1 < 9; l1++) {
        addSlot(new Slot(player, l1 + i1 * 9 + 9, 8 + l1 * 18, 108 + i1 * 18));
      }
    }

    for (int j1 = 0; j1 < 9; j1++)
      addSlot(new Slot(player, j1, 8 + j1 * 18, 166));
  }

  public void updateProgressBar(int i, int j)
  {
    tile.getGUINetworkData(i, j);
  }

  public void detectAndSendChanges()
  {
    super.detectAndSendChanges();
    for (int i = 0; i < crafters.size(); i++)
      tile.sendGUINetworkData(this, (ICrafting)crafters.get(i));
  }

  public boolean canInteractWith(EntityPlayer entityplayer)
  {
    return Utils.isUseableByPlayer(entityplayer, tile, tile.worldObj, tile.xCoord, tile.yCoord, tile.zCoord);
  }
}