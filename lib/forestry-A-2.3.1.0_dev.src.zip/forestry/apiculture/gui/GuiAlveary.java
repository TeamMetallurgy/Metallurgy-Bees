package forestry.apiculture.gui;

import forestry.apiculture.gadgets.TileAlvearyPlain;
import forestry.core.gadgets.TileForestry;
import forestry.core.gui.GuiForestry;
import forestry.core.utils.EnumTankLevel;
import forestry.core.utils.FontColour;
import forestry.core.utils.StringUtil;
import forestry.core.utils.Utils;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiAlveary extends GuiForestry
{
  public GuiAlveary(InventoryPlayer inventory, TileAlvearyPlain tile)
  {
    super("textures/gui/alveary.png", new ContainerAlveary(inventory, tile), tile);

    ySize = 190;
  }

  protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
  {
    super.drawGuiContainerForegroundLayer(mouseX, mouseY);
    String title = StringUtil.localize("tile." + tile.getInvName());
    fontRenderer.drawString(title, getCenteredOffset(title), 6, fontColor.get("gui.title"));
  }

  protected void drawGuiContainerBackgroundLayer(float var1, int mouseX, int mouseY)
  {
    super.drawGuiContainerBackgroundLayer(var1, mouseX, mouseY);

    TileAlvearyPlain machine = (TileAlvearyPlain)tile;
    drawHealthMeter(guiLeft + 20, guiTop + 37, machine.getHealthScaled(46), Utils.rateTankLevel(machine.getHealthScaled(100)));
  }

  private void drawHealthMeter(int x, int y, int height, EnumTankLevel rated) {
    int i = 176;
    int k = 0;
    switch (1.$SwitchMap$forestry$core$utils$EnumTankLevel[rated.ordinal()]) {
    case 1:
      break;
    case 2:
      i += 4;
      break;
    case 3:
      i += 8;
      break;
    case 4:
      i += 12;
      break;
    case 5:
      i += 16;
    }

    drawTexturedModalRect(x, y + 46 - height, i, k + 46 - height, 4, height);
  }
}