package forestry.apiculture;

import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IPollinatable;
import forestry.core.utils.StringUtil;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.EnumPlantType;

public class FlowerProviderCacti
  implements IFlowerProvider
{
  public boolean isAcceptedFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);

    if (blockid == Block.flowerPot.blockID) {
      return checkFlowerPot(world.getBlockMetadata(x, y, z));
    }
    return blockid == Block.cactus.blockID;
  }

  public boolean isAcceptedPollinatable(World world, IPollinatable pollinatable)
  {
    return pollinatable.getPlantType().contains(EnumPlantType.Desert);
  }

  private boolean checkFlowerPot(int meta) {
    if (meta == 9) {
      return true;
    }
    return false;
  }

  public boolean growFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);

    if ((blockid == Block.flowerPot.blockID) && (world.getBlockMetadata(x, y, z) == 0)) {
      return growInPot(world, x, y, z);
    }
    return false;
  }

  private boolean growInPot(World world, int x, int y, int z) {
    if (world.rand.nextBoolean())
      world.setBlock(x, y, z, Block.flowerPot.blockID, 9, 2);
    else
      world.setBlock(x, y, z, Block.flowerPot.blockID, 10, 2);
    return true;
  }

  public String getDescription()
  {
    return StringUtil.localize("flowers.cacti");
  }

  public ItemStack[] affectProducts(World world, IIndividual individual, int x, int y, int z, ItemStack[] products)
  {
    return products;
  }

  public ItemStack[] getItemStacks()
  {
    return new ItemStack[] { new ItemStack(Block.cactus) };
  }
}