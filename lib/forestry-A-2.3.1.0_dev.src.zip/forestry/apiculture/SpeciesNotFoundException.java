package forestry.apiculture;

import net.minecraft.command.CommandException;

public class SpeciesNotFoundException extends CommandException
{
  private static final long serialVersionUID = 1L;

  public SpeciesNotFoundException(String title)
  {
    super("Could not find bee species with Name or UID %s", new Object[] { title });
  }
}