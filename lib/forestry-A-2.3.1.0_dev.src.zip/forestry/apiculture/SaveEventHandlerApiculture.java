package forestry.apiculture;

import forestry.api.apiculture.IBeeRoot;
import forestry.core.interfaces.ISaveEventHandler;
import forestry.plugins.PluginApiculture;
import net.minecraft.world.World;

public class SaveEventHandlerApiculture
  implements ISaveEventHandler
{
  public void onWorldLoad(World world)
  {
    PluginApiculture.beeInterface.resetBeekeepingMode();
  }

  public void onWorldSave(World world)
  {
  }

  public void onWorldUnload(World world)
  {
  }
}