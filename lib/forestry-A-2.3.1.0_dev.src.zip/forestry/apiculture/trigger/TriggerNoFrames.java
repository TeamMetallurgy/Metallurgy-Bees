package forestry.apiculture.trigger;

import buildcraft.api.gates.ITriggerParameter;
import forestry.apiculture.gadgets.TileApiary;
import forestry.core.triggers.Trigger;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.ForgeDirection;

public class TriggerNoFrames extends Trigger
{
  public TriggerNoFrames(int id)
  {
    super(id, "noFrames");
  }

  public boolean isTriggerActive(ForgeDirection direction, TileEntity tile, ITriggerParameter parameter)
  {
    if (!(tile instanceof TileApiary)) {
      return false;
    }
    for (int i = 9; i < 12; i++)
      if (((TileApiary)tile).getStackInSlot(i) != null)
      {
        return false;
      }
    return true;
  }
}