package forestry.apiculture.entities;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.core.utils.ForestryResource;
import forestry.plugins.PluginApiculture;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityBee extends EntityCreature
  implements IAnimals
{
  private static final String DEFAULT_TEXTURE = "textures/entity/bees/honeyBee.png";
  IBee contained;
  IAlleleBeeSpecies species;
  EnumBeeType type = EnumBeeType.DRONE;

  private String beeTexture = "textures/entity/bees/honeyBee.png";
  private long lastUpdate;

  @SideOnly(Side.CLIENT)
  private ResourceLocation textureResource;
  private long lastTextureUpdate;

  public EntityBee(World world)
  {
    super(world);
  }

  private void resetAppearance() {
    beeTexture = species.getEntityTexture();
  }

  public EntityBee setIndividual(IBee bee) {
    if (bee != null)
      contained = bee;
    else {
      contained = PluginApiculture.beeInterface.templateAsIndividual(PluginApiculture.beeInterface.getDefaultTemplate());
    }

    setSpecies(contained.getGenome().getPrimary());

    return this;
  }

  public IBee getBee() {
    return contained;
  }

  public EntityBee setType(EnumBeeType type) {
    this.type = type;
    return this;
  }

  public EnumBeeType getType() {
    return type;
  }

  public EntityBee setSpecies(IAlleleBeeSpecies species) {
    this.species = species;
    resetAppearance();
    lastUpdate = worldObj.getTotalWorldTime();
    return this;
  }

  @SideOnly(Side.CLIENT)
  public ResourceLocation getTexture()
  {
    if ((textureResource == null) || (lastTextureUpdate != lastUpdate)) {
      textureResource = new ForestryResource(beeTexture);
    }
    return textureResource;
  }
}