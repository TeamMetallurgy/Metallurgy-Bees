package forestry.apiculture;

import forestry.api.apiculture.IApiaristTracker;
import forestry.api.apiculture.IBeeRoot;
import forestry.apiculture.gadgets.TileAlvearyHygroregulator;
import forestry.apiculture.gadgets.TileAlvearyPlain;
import forestry.apiculture.gadgets.TileAlvearySieve;
import forestry.apiculture.gadgets.TileAlvearySwarmer;
import forestry.apiculture.gadgets.TileApiary;
import forestry.apiculture.gadgets.TileBeehouse;
import forestry.apiculture.gui.ContainerAlveary;
import forestry.apiculture.gui.ContainerAlvearyHygroregulator;
import forestry.apiculture.gui.ContainerAlvearySieve;
import forestry.apiculture.gui.ContainerAlvearySwarmer;
import forestry.apiculture.gui.ContainerApiary;
import forestry.apiculture.gui.ContainerBeealyzer;
import forestry.apiculture.gui.ContainerHabitatLocator;
import forestry.apiculture.gui.ContainerImprinter;
import forestry.apiculture.gui.GuiAlveary;
import forestry.apiculture.gui.GuiAlvearyHygroregulator;
import forestry.apiculture.gui.GuiAlvearySieve;
import forestry.apiculture.gui.GuiAlvearySwarmer;
import forestry.apiculture.gui.GuiApiary;
import forestry.apiculture.gui.GuiBeealyzer;
import forestry.apiculture.gui.GuiHabitatLocator;
import forestry.apiculture.gui.GuiImprinter;
import forestry.apiculture.items.ItemBeealyzer.BeealyzerInventory;
import forestry.apiculture.items.ItemBiomefinder.BiomefinderInventory;
import forestry.apiculture.items.ItemImprinter.ImprinterInventory;
import forestry.core.GuiHandlerBase;
import forestry.core.network.GuiId;
import forestry.plugins.PluginApiculture;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class GuiHandlerApiculture extends GuiHandlerBase
{
  public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z)
  {
    int cleanId = decodeGuiID(id);
    int guiData = decodeGuiData(id);

    if (cleanId >= GuiId.values().length)
      return null;
    ItemStack equipped;
    switch (1.$SwitchMap$forestry$core$network$GuiId[GuiId.values()[cleanId].ordinal()])
    {
    case 1:
      return new GuiAlveary(player.inventory, (TileAlvearyPlain)getTileForestry(world, x, y, z));
    case 2:
      return new GuiAlvearySieve(player.inventory, (TileAlvearySieve)getTileForestry(world, x, y, z));
    case 3:
      return new GuiAlvearySwarmer(player.inventory, (TileAlvearySwarmer)getTileForestry(world, x, y, z));
    case 4:
      return getNaturalistChestGui("rootBees", player, world, x, y, z, guiData);
    case 5:
      return new GuiApiary(player.inventory, (TileApiary)getTileForestry(world, x, y, z));
    case 6:
      equipped = getEquippedItem(player);
      if (equipped == null) {
        return null;
      }
      return new GuiBeealyzer(player, new ItemBeealyzer.BeealyzerInventory(player, equipped));
    case 7:
      return new GuiApiary(player.inventory, (TileBeehouse)getTileForestry(world, x, y, z));
    case 8:
      equipped = getEquippedItem(player);
      if (equipped == null) {
        return null;
      }
      return new GuiHabitatLocator(player.inventory, new ItemBiomefinder.BiomefinderInventory(equipped));
    case 9:
      return new GuiAlvearyHygroregulator(player.inventory, (TileAlvearyHygroregulator)getTileForestry(world, x, y, z));
    case 10:
      return new GuiImprinter(player.inventory, new ItemImprinter.ImprinterInventory(player));
    }

    return null;
  }

  public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z)
  {
    int cleanId = decodeGuiID(id);
    int guiData = decodeGuiData(id);

    if (cleanId >= GuiId.values().length)
      return null;
    ItemStack equipped;
    switch (1.$SwitchMap$forestry$core$network$GuiId[GuiId.values()[cleanId].ordinal()])
    {
    case 1:
      synchApiaristTracker(world, player);
      return new ContainerAlveary(player.inventory, (TileAlvearyPlain)getTileForestry(world, x, y, z));
    case 2:
      return new ContainerAlvearySieve(player.inventory, (TileAlvearySieve)getTileForestry(world, x, y, z));
    case 3:
      return new ContainerAlvearySwarmer(player.inventory, (TileAlvearySwarmer)getTileForestry(world, x, y, z));
    case 4:
      return getNaturalistChestContainer("rootBees", player, world, x, y, z, guiData);
    case 5:
      synchApiaristTracker(world, player);
      return new ContainerApiary(player.inventory, (TileApiary)getTileForestry(world, x, y, z), true);
    case 6:
      equipped = getEquippedItem(player);
      if (equipped == null) {
        return null;
      }
      synchApiaristTracker(world, player);
      return new ContainerBeealyzer(player.inventory, new ItemBeealyzer.BeealyzerInventory(player, equipped));
    case 7:
      synchApiaristTracker(world, player);
      return new ContainerApiary(player.inventory, (TileBeehouse)getTileForestry(world, x, y, z), false);
    case 8:
      equipped = getEquippedItem(player);
      if (equipped == null) {
        return null;
      }
      return new ContainerHabitatLocator(player.inventory, new ItemBiomefinder.BiomefinderInventory(equipped));
    case 9:
      return new ContainerAlvearyHygroregulator(player.inventory, (TileAlvearyHygroregulator)getTileForestry(world, x, y, z));
    case 10:
      synchApiaristTracker(world, player);
      return new ContainerImprinter(player.inventory, new ItemImprinter.ImprinterInventory(player));
    }

    return null;
  }

  private void synchApiaristTracker(World world, EntityPlayer player)
  {
    PluginApiculture.beeInterface.getBreedingTracker(world, player.username).synchToPlayer(player);
  }
}