package forestry.apiculture;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public class MaterialBeehive extends Material
{
  public MaterialBeehive(boolean noHarvest)
  {
    super(MapColor.stoneColor);
    if (noHarvest)
      setRequiresTool();
    setImmovableMobility();
  }
}