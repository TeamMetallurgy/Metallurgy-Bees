package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.ai.EntityAITaskEntry;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class AlleleEffectRepulsion extends AlleleEffectThrottled
{
  public AlleleEffectRepulsion(String uid)
  {
    super(uid, "repulsion", false, 100, true, true);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    if (isHalted(storedData, housing)) {
      return storedData;
    }
    if ((housing.getOwnerName() == null) || (housing.getOwnerName().isEmpty())) {
      return storedData;
    }
    AxisAlignedBB hurtBox = getBounding(genome, housing, 1.0F);
    List list = housing.getWorld().getEntitiesWithinAABB(EntityMob.class, hurtBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      EntityMob mob = (EntityMob)obj;

      for (Iterator i$ = mob.tasks.taskEntries.iterator(); i$.hasNext(); ) { Object objT = i$.next();
        EntityAITaskEntry task = (EntityAITaskEntry)objT;
        if ((task.action instanceof AIAvoidPlayers)) {
          return storedData;
        }
      }
      mob.tasks.addTask(3, new AIAvoidPlayers(mob, 6.0F, 0.25F, 0.3F));
      mob.tasks.onUpdateTasks();
    }

    return storedData;
  }
}