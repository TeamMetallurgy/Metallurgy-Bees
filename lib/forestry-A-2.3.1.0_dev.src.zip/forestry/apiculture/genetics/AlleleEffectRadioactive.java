package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.gadgets.BlockAlveary;
import forestry.apiculture.gadgets.TileAlveary;
import forestry.apiculture.items.ItemArmorApiarist;
import forestry.core.utils.DamageSourceForestry;
import forestry.core.utils.Vect;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AABBPool;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class AlleleEffectRadioactive extends AlleleEffectThrottled
{
  public static DamageSource damageSourceBeeRadioactive = new DamageSourceForestry("bee.radioactive");

  public AlleleEffectRadioactive(String uid) {
    super(uid, "radioactive", true, 40, false, true);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    World world = housing.getWorld();

    if (isHalted(storedData, housing)) {
      return storedData;
    }
    int[] areaAr = genome.getTerritory();
    Vect area = new Vect(areaAr[0] * 2, areaAr[1] * 2, areaAr[2] * 2);
    Vect offset = new Vect(-Math.round(area.x / 2), -Math.round(area.y / 2), -Math.round(area.z / 2));

    Vect min = new Vect(housing.getXCoord() + offset.x, housing.getYCoord() + offset.y, housing.getZCoord() + offset.z);
    Vect max = new Vect(housing.getXCoord() + offset.x + area.x, housing.getYCoord() + offset.y + area.y, housing.getZCoord() + offset.z + area.z);

    AxisAlignedBB hurtBox = AxisAlignedBB.getAABBPool().getAABB(min.x, min.y, min.z, max.x, max.y, max.z);

    List list = housing.getWorld().getEntitiesWithinAABB(EntityLivingBase.class, hurtBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      EntityLivingBase entity = (EntityLivingBase)obj;

      int damage = 8;

      if ((entity instanceof EntityPlayer)) {
        int count = ItemArmorApiarist.wearsItems((EntityPlayer)entity, getUID(), true);

        if (count <= 3)
        {
          if (count > 2)
            damage = 1;
          else if (count > 1)
            damage = 2;
          else if (count > 0)
            damage = 3;
        }
      } else {
        entity.attackEntityFrom(damageSourceBeeRadioactive, damage);
      }
    }

    Random rand = housing.getWorld().rand;

    for (int i = 0; i < 20; i++)
    {
      Vect randomPos = new Vect(rand.nextInt(area.x), rand.nextInt(area.y), rand.nextInt(area.z));

      Vect posBlock = randomPos.add(new Vect(housing.getXCoord(), housing.getYCoord(), housing.getZCoord()));
      posBlock = posBlock.add(offset);

      if ((posBlock.y > 1) && (posBlock.y < housing.getWorld().getActualHeight()))
      {
        if ((posBlock.x != housing.getXCoord()) || (posBlock.z != housing.getZCoord()) || (posBlock.y > housing.getYCoord()))
        {
          if (!world.isAirBlock(posBlock.x, posBlock.y, posBlock.z))
          {
            int id = world.getBlockId(posBlock.x, posBlock.y, posBlock.z);
            Block block = Block.blocksList[id];
            if (block != null)
            {
              if (!(block instanceof BlockAlveary))
              {
                TileEntity tile = world.getBlockTileEntity(posBlock.x, posBlock.y, posBlock.z);
                if (!(tile instanceof IBeeHousing))
                {
                  if (!(tile instanceof TileAlveary))
                  {
                    if (block.getBlockHardness(world, posBlock.x, posBlock.y, posBlock.z) >= 0.0F)
                    {
                      world.setBlock(posBlock.x, posBlock.y, posBlock.z, 0, 0, 2);
                      break;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return storedData;
  }
}