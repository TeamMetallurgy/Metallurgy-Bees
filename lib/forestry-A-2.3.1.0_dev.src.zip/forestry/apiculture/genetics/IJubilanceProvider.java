package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;

public abstract interface IJubilanceProvider
{
  public abstract boolean isJubilant(IAlleleBeeSpecies paramIAlleleBeeSpecies, IBeeGenome paramIBeeGenome, IBeeHousing paramIBeeHousing);
}