package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.items.ItemArmorApiarist;
import forestry.core.genetics.EffectData;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class AlleleEffectCreeper extends AlleleEffectThrottled
{
  private int explosionChance = 50;
  byte defaultForce = 12;
  byte indexExplosionTimer = 1;
  byte indexExplosionForce = 2;

  public AlleleEffectCreeper(String uid) {
    super(uid, "creeper", true, 20, false, true);
  }

  public IEffectData validateStorage(IEffectData storedData)
  {
    if (!(storedData instanceof EffectData)) {
      return new EffectData(3, 0);
    }
    if (((EffectData)storedData).getIntSize() < 3) {
      return new EffectData(3, 0);
    }
    return storedData;
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    World world = housing.getWorld();

    if (isHalted(storedData, housing)) {
      return storedData;
    }

    if (storedData.getInteger(indexExplosionTimer) > 0) {
      progressExplosion(storedData, world, housing.getXCoord(), housing.getYCoord(), housing.getZCoord());
      return storedData;
    }

    AxisAlignedBB infectionBox = getBounding(genome, housing, 1.0F);

    List list = world.getEntitiesWithinAABB(EntityPlayer.class, infectionBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();

      EntityPlayer player = (EntityPlayer)obj;

      int chance = explosionChance;
      storedData.setInteger(indexExplosionForce, defaultForce);

      int count = ItemArmorApiarist.wearsItems(player, getUID(), true);

      if (count <= 3)
      {
        if (count > 2) {
          chance = 5;
          storedData.setInteger(indexExplosionForce, 6);
        } else if (count > 1) {
          chance = 20;
          storedData.setInteger(indexExplosionForce, 8);
        } else if (count > 0) {
          chance = 35;
          storedData.setInteger(indexExplosionForce, 10);
        }

        if (world.rand.nextInt(1000) < chance)
        {
          world.playSoundEffect(housing.getXCoord(), housing.getYCoord(), housing.getZCoord(), "mob.creeper", 4.0F, (1.0F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.2F) * 0.7F);

          storedData.setInteger(indexExplosionTimer, 2);
        }
      }
    }
    return storedData;
  }

  private void progressExplosion(IEffectData storedData, World world, int x, int y, int z)
  {
    int explosionTimer = storedData.getInteger(indexExplosionTimer);
    explosionTimer--;
    storedData.setInteger(indexExplosionTimer, explosionTimer);

    if (explosionTimer > 0) {
      return;
    }
    world.createExplosion(null, x, y, z, storedData.getInteger(indexExplosionForce), false);
  }
}