package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyRender;

public class AlleleEffectSnowing extends AlleleEffectThrottled
{
  public AlleleEffectSnowing(String uid)
  {
    super(uid, "snowing", false, 20, true, true);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    return storedData;
  }

  public IEffectData doFX(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    int[] area = getModifiedArea(genome, housing);

    Proxies.render.addSnowFX(housing.getWorld(), housing.getXCoord(), housing.getYCoord(), housing.getZCoord(), genome.getPrimary().getIconColour(0), area[0], area[1], area[2]);

    return storedData;
  }
}