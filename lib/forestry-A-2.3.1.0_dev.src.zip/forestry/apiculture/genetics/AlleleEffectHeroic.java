package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class AlleleEffectHeroic extends AlleleEffectThrottled
{
  public AlleleEffectHeroic(String uid)
  {
    super(uid, "heroic", false, 40, true, false);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    if (isHalted(storedData, housing)) {
      return storedData;
    }
    AxisAlignedBB hurtBox = getBounding(genome, housing, 1.0F);
    List list = housing.getWorld().getEntitiesWithinAABB(EntityMob.class, hurtBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      EntityMob mob = (EntityMob)obj;
      mob.attackEntityFrom(DamageSource.generic, 2.0F);
    }

    return storedData;
  }
}