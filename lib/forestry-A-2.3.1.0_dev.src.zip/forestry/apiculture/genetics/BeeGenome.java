package forestry.apiculture.genetics;

import forestry.api.apiculture.EnumBeeChromosome;
import forestry.api.apiculture.IAlleleBeeEffect;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.genetics.EnumTolerance;
import forestry.api.genetics.IAlleleFloat;
import forestry.api.genetics.IAlleleFlowers;
import forestry.api.genetics.IAlleleInteger;
import forestry.api.genetics.IChromosome;
import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.ISpeciesRoot;
import forestry.core.genetics.AlleleArea;
import forestry.core.genetics.AlleleBoolean;
import forestry.core.genetics.AlleleTolerance;
import forestry.core.genetics.Genome;
import forestry.core.utils.Vect;
import forestry.plugins.PluginApiculture;
import net.minecraft.nbt.NBTTagCompound;

public class BeeGenome extends Genome
  implements IBeeGenome
{
  public BeeGenome(NBTTagCompound nbttagcompound)
  {
    super(nbttagcompound);
  }

  public BeeGenome(IChromosome[] chromosomes) {
    super(chromosomes);
  }

  public IAlleleBeeSpecies getPrimary()
  {
    return (IAlleleBeeSpecies)getActiveAllele(EnumBeeChromosome.SPECIES.ordinal());
  }

  public IAlleleBeeSpecies getSecondary()
  {
    return (IAlleleBeeSpecies)getInactiveAllele(EnumBeeChromosome.SPECIES.ordinal());
  }

  public float getSpeed()
  {
    return ((IAlleleFloat)getActiveAllele(EnumBeeChromosome.SPEED.ordinal())).getValue();
  }

  public int getLifespan()
  {
    return ((IAlleleInteger)getActiveAllele(EnumBeeChromosome.LIFESPAN.ordinal())).getValue();
  }

  public int getFertility()
  {
    return ((IAlleleInteger)getActiveAllele(EnumBeeChromosome.FERTILITY.ordinal())).getValue();
  }

  public EnumTolerance getToleranceTemp()
  {
    return ((AlleleTolerance)getActiveAllele(EnumBeeChromosome.TEMPERATURE_TOLERANCE.ordinal())).getValue();
  }

  public boolean getNocturnal()
  {
    return ((AlleleBoolean)getActiveAllele(EnumBeeChromosome.NOCTURNAL.ordinal())).getValue();
  }

  public EnumTolerance getToleranceHumid()
  {
    return ((AlleleTolerance)getActiveAllele(EnumBeeChromosome.HUMIDITY_TOLERANCE.ordinal())).getValue();
  }

  public boolean getTolerantFlyer()
  {
    return ((AlleleBoolean)getActiveAllele(EnumBeeChromosome.TOLERANT_FLYER.ordinal())).getValue();
  }

  public boolean getCaveDwelling()
  {
    return ((AlleleBoolean)getActiveAllele(EnumBeeChromosome.CAVE_DWELLING.ordinal())).getValue();
  }

  public IFlowerProvider getFlowerProvider()
  {
    return ((IAlleleFlowers)getActiveAllele(EnumBeeChromosome.FLOWER_PROVIDER.ordinal())).getProvider();
  }

  public int getFlowering()
  {
    return ((IAlleleInteger)getActiveAllele(EnumBeeChromosome.FLOWERING.ordinal())).getValue();
  }

  public int[] getTerritory()
  {
    Vect area = ((AlleleArea)getActiveAllele(EnumBeeChromosome.TERRITORY.ordinal())).getArea();
    return new int[] { area.x, area.y, area.z };
  }

  public IAlleleBeeEffect getEffect()
  {
    return (IAlleleBeeEffect)getActiveAllele(EnumBeeChromosome.EFFECT.ordinal());
  }

  public ISpeciesRoot getSpeciesRoot()
  {
    return PluginApiculture.beeInterface;
  }
}