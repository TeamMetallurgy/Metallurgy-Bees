package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IGenome;
import java.util.Calendar;

public class MutationTimeLimited extends BeeMutation
{
  DayMonth start;
  DayMonth end;

  public MutationTimeLimited(IAllele allele0, IAllele allele1, IAllele[] template, int chance, DayMonth start)
  {
    this(allele0, allele1, template, chance, start, null);
  }

  public MutationTimeLimited(IAllele allele0, IAllele allele1, IAllele[] template, int chance, DayMonth start, DayMonth end) {
    super(allele0, allele1, template, chance);
    this.start = start;
    this.end = end;
  }

  public float getChance(IBeeHousing housing, IAllele allele0, IAllele allele1, IGenome genome0, IGenome genome1)
  {
    float chance = super.getChance(housing, allele0, allele1, genome0, genome1);

    if (chance == 0.0F) {
      return 0.0F;
    }
    if ((start == null) && (end == null)) {
      return chance;
    }
    DayMonth now = new DayMonth();

    if ((Calendar.getInstance().get(5) == start.day) && (Calendar.getInstance().get(2) + 1 == start.month)) {
      return chance;
    }

    if (end == null) {
      return 0.0F;
    }

    if ((Calendar.getInstance().get(5) == end.day) && (Calendar.getInstance().get(2) + 1 == end.month)) {
      return chance;
    }

    if ((start.before(now)) && (end.after(now))) {
      return chance;
    }

    return 0.0F;
  }

  public static class DayMonth
  {
    public int day;
    public int month;

    public DayMonth()
    {
      day = Calendar.getInstance().get(5);
      month = (Calendar.getInstance().get(2) + 1);
    }

    public DayMonth(int day, int month) {
      this.day = day;
      this.month = month;
    }

    public boolean before(DayMonth other)
    {
      if (other.month > month) {
        return true;
      }
      if (other.month < month) {
        return false;
      }
      return day < other.day;
    }

    public boolean after(DayMonth other)
    {
      if (other.month < month) {
        return true;
      }
      if (other.month > month) {
        return false;
      }
      return day > other.day;
    }

    public String toString()
    {
      return day + "." + month;
    }
  }
}