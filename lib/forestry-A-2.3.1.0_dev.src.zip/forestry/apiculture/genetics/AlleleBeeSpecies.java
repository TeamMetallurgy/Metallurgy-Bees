package forestry.apiculture.genetics;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import forestry.api.apiculture.EnumBeeChromosome;
import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.IIconProvider;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IClassification;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IMutation;
import forestry.core.genetics.AlleleSpecies;
import forestry.core.render.TextureManager;
import forestry.core.utils.StackUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraft.world.World;

public class AlleleBeeSpecies extends AlleleSpecies
  implements IAlleleBeeSpecies, IIconProvider
{
  public IJubilanceProvider jubilanceProvider;
  private IBeeRoot root;
  private HashMap<ItemStack, Integer> products = new HashMap();
  private HashMap<ItemStack, Integer> specialty = new HashMap();
  private String texture;
  private int primaryColour;
  private int secondaryColour;
  private String iconType = "default";

  @SideOnly(Side.CLIENT)
  private static Icon[][] icons;

  public AlleleBeeSpecies(String uid, boolean dominant, String name, IClassification branch, int primaryColor, int secondaryColor) { this(uid, dominant, name, branch, null, primaryColor, secondaryColor); }

  public AlleleBeeSpecies(String uid, boolean dominant, String name, IClassification branch, String binomial, int primaryColor, int secondaryColor)
  {
    this(uid, dominant, name, branch, binomial, primaryColor, secondaryColor, new JubilanceDefault());
  }

  public AlleleBeeSpecies(String uid, boolean dominant, String name, IClassification branch, String binomial, int primaryColor, int secondaryColor, IJubilanceProvider jubilanceProvider)
  {
    super(uid, dominant, name, branch, binomial);

    root = ((IBeeRoot)AlleleManager.alleleRegistry.getSpeciesRoot("rootBees"));
    primaryColour = primaryColor;
    secondaryColour = secondaryColor;
    this.jubilanceProvider = jubilanceProvider;
    texture = "textures/entity/bees/honeyBee.png";
  }

  public IBeeRoot getRoot()
  {
    return root;
  }

  public AlleleBeeSpecies setEntityTexture(String texture) {
    this.texture = ("textures/entity/bees/" + texture + ".png");
    return this;
  }

  public AlleleBeeSpecies addProduct(ItemStack product, int chance) {
    products.put(product, Integer.valueOf(chance));
    return this;
  }

  public AlleleBeeSpecies addSpecialty(ItemStack specialty, int chance) {
    this.specialty.put(specialty, Integer.valueOf(chance));
    return this;
  }

  public AlleleBeeSpecies setJubilanceProvider(IJubilanceProvider provider) {
    jubilanceProvider = provider;
    return this;
  }

  public int getComplexity()
  {
    return 1 + getGeneticAdvancement(this, new ArrayList());
  }

  private int getGeneticAdvancement(IAllele species, ArrayList<IAllele> exclude)
  {
    int own = 1;
    int highest = 0;
    exclude.add(species);

    for (IMutation mutation : getRoot().getPaths(species, EnumBeeChromosome.SPECIES.ordinal())) {
      if (!exclude.contains(mutation.getAllele0())) {
        int otherAdvance = getGeneticAdvancement(mutation.getAllele0(), exclude);
        if (otherAdvance > highest)
          highest = otherAdvance;
      }
      if (!exclude.contains(mutation.getAllele1())) {
        int otherAdvance = getGeneticAdvancement(mutation.getAllele1(), exclude);
        if (otherAdvance > highest) {
          highest = otherAdvance;
        }
      }
    }
    return own + (highest < 0 ? 0 : highest);
  }

  public float getResearchSuitability(ItemStack itemstack)
  {
    if (itemstack == null) {
      return 0.0F;
    }
    for (ItemStack stack : products.keySet())
      if (stack.isItemEqual(itemstack))
        return 1.0F;
    for (ItemStack stack : specialty.keySet()) {
      if (stack.isItemEqual(itemstack))
        return 1.0F;
    }
    return super.getResearchSuitability(itemstack);
  }

  public ItemStack[] getResearchBounty(World world, String researcher, IIndividual individual, int bountyLevel)
  {
    ArrayList bounty = new ArrayList();
    for (ItemStack stack : super.getResearchBounty(world, researcher, individual, bountyLevel)) {
      bounty.add(stack);
    }
    if (bountyLevel > 10) {
      for (ItemStack stack : specialty.keySet()) {
        bounty.add(StackUtils.copyWithRandomSize(stack, (int)(bountyLevel / 2.0F), world.rand));
      }
    }
    for (ItemStack stack : products.keySet()) {
      bounty.add(StackUtils.copyWithRandomSize(stack, (int)(bountyLevel / 2.0F), world.rand));
    }
    return (ItemStack[])bounty.toArray(StackUtils.EMPTY_STACK_ARRAY);
  }

  public boolean isNocturnal()
  {
    return false;
  }

  public HashMap<ItemStack, Integer> getProducts()
  {
    return products;
  }

  public HashMap<ItemStack, Integer> getSpecialty()
  {
    return specialty;
  }

  public boolean isJubilant(IBeeGenome genome, IBeeHousing housing)
  {
    return jubilanceProvider.isJubilant(this, genome, housing);
  }

  public String getEntityTexture()
  {
    return texture;
  }

  public int getIconColour(int renderPass)
  {
    if (renderPass == 0)
      return primaryColour;
    if (renderPass == 1)
      return secondaryColour;
    return 16777215;
  }

  @SideOnly(Side.CLIENT)
  public void registerIcons(IconRegister register)
  {
    icons = new Icon[EnumBeeType.values().length][3];

    Icon body1 = TextureManager.getInstance().registerTex(register, "bees/" + iconType + "/body1");

    for (int i = 0; i < EnumBeeType.values().length; i++)
      if (EnumBeeType.values()[i] != EnumBeeType.NONE)
      {
        icons[i][0] = TextureManager.getInstance().registerTex(register, "bees/" + iconType + "/" + EnumBeeType.values()[i].toString().toLowerCase(Locale.ENGLISH) + ".outline");
        icons[i][1] = (EnumBeeType.values()[i] != EnumBeeType.LARVAE ? body1 : TextureManager.getInstance().registerTex(register, "bees/" + iconType + "/" + EnumBeeType.values()[i].toString().toLowerCase(Locale.ENGLISH) + ".body"));

        icons[i][2] = TextureManager.getInstance().registerTex(register, "bees/" + iconType + "/" + EnumBeeType.values()[i].toString().toLowerCase(Locale.ENGLISH) + ".body2");
      }
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(EnumBeeType type, int renderPass)
  {
    return icons[type.ordinal()][renderPass];
  }

  @SideOnly(Side.CLIENT)
  public IIconProvider getIconProvider()
  {
    return this;
  }

  @SideOnly(Side.CLIENT)
  public Icon getIcon(short texUID)
  {
    return null;
  }
}