package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.core.utils.StackUtils;
import forestry.core.utils.Utils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class AlleleEffectResurrection extends AlleleEffectThrottled
{
  private List<Resurrectable> resurrectables;

  public static List<Resurrectable> getReanimationList()
  {
    ArrayList list = new ArrayList();
    list.add(new Resurrectable(new ItemStack(Item.bone), EntitySkeleton.class));
    list.add(new Resurrectable(new ItemStack(Item.arrow), EntitySkeleton.class));
    list.add(new Resurrectable(new ItemStack(Item.rottenFlesh), EntityZombie.class));
    list.add(new Resurrectable(new ItemStack(Item.blazeRod), EntityBlaze.class));
    return list;
  }

  public static List<Resurrectable> getResurrectionList() {
    ArrayList list = new ArrayList();
    list.add(new Resurrectable(new ItemStack(Item.gunpowder), EntityCreeper.class));
    list.add(new Resurrectable(new ItemStack(Item.enderPearl), EntityEnderman.class));
    list.add(new Resurrectable(new ItemStack(Item.silk), EntitySpider.class));
    list.add(new Resurrectable(new ItemStack(Item.spiderEye), EntitySpider.class));
    list.add(new Resurrectable(new ItemStack(Item.silk), EntityCaveSpider.class));
    list.add(new Resurrectable(new ItemStack(Item.spiderEye), EntityCaveSpider.class));
    list.add(new Resurrectable(new ItemStack(Item.ghastTear), EntityGhast.class));
    list.add(new Resurrectable(new ItemStack(Block.dragonEgg), EntityDragon.class));
    return list;
  }

  public AlleleEffectResurrection(String uid, String name, List<Resurrectable> resurrectables)
  {
    super(uid, name, true, 40, true, true);
    this.resurrectables = resurrectables;
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    if (isHalted(storedData, housing)) {
      return storedData;
    }
    AxisAlignedBB bounding = getBounding(genome, housing, 1.0F);
    List list = housing.getWorld().getEntitiesWithinAABB(EntityItem.class, bounding);

    if (list.size() > 0) {
      Collections.shuffle(resurrectables);
    }
    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      item = (EntityItem)obj;
      if (!item.isDead)
      {
        contained = item.getEntityItem();
        for (Resurrectable entry : resurrectables)
          if (StackUtils.isIdenticalItem(entry.res, contained)) {
            Utils.spawnEntity(housing.getWorld(), entry.risen, item.posX, item.posY, item.posZ);
            contained.stackSize -= 1;
            if (contained.stackSize > 0) break;
            item.setDead(); break;
          }
      }
    }
    EntityItem item;
    ItemStack contained;
    return storedData;
  }

  public static class Resurrectable
  {
    public final ItemStack res;
    public final Class<? extends EntityLiving> risen;

    public Resurrectable(ItemStack res, Class<? extends EntityLiving> risen)
    {
      this.res = res;
      this.risen = risen;
    }
  }
}