package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.items.ItemArmorApiarist;
import forestry.apiculture.proxy.ProxyApiculture;
import forestry.plugins.PluginApiculture;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class AlleleEffectMiasmic extends AlleleEffectThrottled
{
  private int infectionChance = 50;

  public AlleleEffectMiasmic(String uid) {
    super(uid, "misasmic", false, 50, false, false);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    World world = housing.getWorld();

    if (isHalted(storedData, housing)) {
      return storedData;
    }
    AxisAlignedBB infectionBox = getBounding(genome, housing, 1.0F);
    List list = world.getEntitiesWithinAABB(EntityPlayer.class, infectionBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();

      if (world.rand.nextInt(1000) < infectionChance)
      {
        EntityPlayer player = (EntityPlayer)obj;

        int duration = 800;

        int count = ItemArmorApiarist.wearsItems(player, getUID(), true);

        if (count <= 3)
        {
          if (count > 2)
            duration = 200;
          else if (count > 1)
            duration = 400;
          else if (count > 0) {
            duration = 600;
          }
          player.addPotionEffect(new PotionEffect(Potion.poison.id, duration, 0));
        }
      } }
    return storedData;
  }

  public IEffectData doFX(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    int[] area = getModifiedArea(genome, housing);

    if (housing.getWorld().rand.nextBoolean()) {
      PluginApiculture.proxy.addBeeHiveFX("particles/swarm_bee", housing.getWorld(), housing.getXCoord(), housing.getYCoord(), housing.getZCoord(), genome.getPrimary().getIconColour(0), area[0], area[1], area[2]);
    }
    else {
      PluginApiculture.proxy.addBeeHiveFX("particles/poison", housing.getWorld(), housing.getXCoord(), housing.getYCoord(), housing.getZCoord(), 16777215, area[0], area[1], area[2]);
    }
    return storedData;
  }
}