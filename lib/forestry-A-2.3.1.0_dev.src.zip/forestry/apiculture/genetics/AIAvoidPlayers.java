package forestry.apiculture.genetics;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntitySenses;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3Pool;
import net.minecraft.world.World;

public class AIAvoidPlayers extends EntityAIBase
{
  private EntityCreature mob;
  private float farSpeed;
  private float nearSpeed;
  private float minDistance;
  private PathEntity pathing;
  private PathNavigate pathNavigator;
  private EntityPlayer player;

  public AIAvoidPlayers(EntityCreature mob, float minDistance, float farSpeed, float nearSpeed)
  {
    this.mob = mob;
    this.minDistance = minDistance;
    this.farSpeed = farSpeed;
    this.nearSpeed = nearSpeed;
    pathNavigator = mob.getNavigator();
    setMutexBits(1);
  }

  public boolean shouldExecute()
  {
    player = mob.worldObj.getClosestPlayerToEntity(mob, minDistance);

    if (player == null) {
      return false;
    }
    if (!mob.getEntitySenses().canSee(player)) {
      return false;
    }
    Vec3 randomTarget = RandomPositionGenerator.findRandomTargetBlockAwayFrom(mob, 16, 7, mob.worldObj.getWorldVec3Pool().getVecFromPool(player.posX, player.posY, player.posZ));

    if (randomTarget == null) {
      return false;
    }
    if (player.getDistanceSq(randomTarget.xCoord, randomTarget.yCoord, randomTarget.zCoord) < player.getDistanceSqToEntity(mob)) {
      return false;
    }
    pathing = pathNavigator.getPathToXYZ(randomTarget.xCoord, randomTarget.yCoord, randomTarget.zCoord);
    return pathing == null ? false : pathing.isDestinationSame(randomTarget);
  }

  public boolean continueExecuting()
  {
    return !pathNavigator.noPath();
  }

  public void startExecuting()
  {
    pathNavigator.setPath(pathing, farSpeed);
  }

  public void resetTask()
  {
    player = null;
  }

  public void updateTask()
  {
    if (mob.getDistanceSqToEntity(player) < 49.0D)
      mob.getNavigator().setSpeed(nearSpeed);
    else
      mob.getNavigator().setSpeed(farSpeed);
  }
}