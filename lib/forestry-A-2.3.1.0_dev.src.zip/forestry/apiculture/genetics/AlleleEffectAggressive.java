package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.items.ItemArmorApiarist;
import forestry.core.utils.DamageSourceForestry;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class AlleleEffectAggressive extends AlleleEffectThrottled
{
  public static DamageSource damageSourceBeeAggressive = new DamageSourceForestry("bee.aggressive");

  public AlleleEffectAggressive(String uid) {
    super(uid, "aggressive", true, 40, false, false);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    if (isHalted(storedData, housing)) {
      return storedData;
    }
    AxisAlignedBB hurtBox = getBounding(genome, housing, 1.0F);
    List list = housing.getWorld().getEntitiesWithinAABB(EntityLivingBase.class, hurtBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      EntityLivingBase entity = (EntityLivingBase)obj;

      int damage = 4;

      if ((entity instanceof EntityPlayer)) {
        int count = ItemArmorApiarist.wearsItems((EntityPlayer)entity, getUID(), true);

        if (count <= 3)
        {
          if (count > 2)
            damage = 1;
          else if (count > 1)
            damage = 2;
          else if (count > 0)
            damage = 3;
        }
      } else {
        entity.attackEntityFrom(damageSourceBeeAggressive, damage);
      }
    }
    return storedData;
  }
}