package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeEffect;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.proxy.ProxyApiculture;
import forestry.core.EnumErrorCode;
import forestry.core.genetics.Allele;
import forestry.core.genetics.EffectData;
import forestry.core.utils.StringUtil;
import forestry.core.utils.Vect;
import forestry.plugins.PluginApiculture;
import net.minecraft.util.AABBPool;
import net.minecraft.util.AxisAlignedBB;

public abstract class AlleleEffectThrottled extends Allele
  implements IAlleleBeeEffect
{
  private String name;
  private boolean isCombinable = false;
  private int throttle;
  private boolean requiresWorkingQueen = false;

  public AlleleEffectThrottled(String uid, String name, boolean isDominant, int throttle, boolean requiresWorking, boolean isCombinable) {
    super(uid, isDominant);
    this.name = ("apiculture.effect." + name);
    this.throttle = throttle;
    this.isCombinable = isCombinable;
    requiresWorkingQueen = requiresWorking;
  }

  public String getName()
  {
    return StringUtil.localize(name);
  }

  public int getThrottle() {
    return throttle;
  }

  public boolean isCombinable()
  {
    return isCombinable;
  }

  public IEffectData validateStorage(IEffectData storedData)
  {
    if ((storedData instanceof EffectData)) {
      return storedData;
    }
    return new EffectData(1, 0);
  }

  public boolean isHalted(IEffectData storedData, IBeeHousing housing)
  {
    if ((requiresWorkingQueen) && (housing.getErrorOrdinal() != EnumErrorCode.OK.ordinal())) {
      return true;
    }
    int throttle = storedData.getInteger(0);
    throttle++;
    storedData.setInteger(0, throttle);

    if (throttle < getThrottle()) {
      return true;
    }

    storedData.setInteger(0, 0);
    return false;
  }

  public IEffectData doFX(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    int[] area = getModifiedArea(genome, housing);

    PluginApiculture.proxy.addBeeHiveFX("particles/swarm_bee", housing.getWorld(), housing.getXCoord(), housing.getYCoord(), housing.getZCoord(), genome.getPrimary().getIconColour(0), area[0], area[1], area[2]);

    return storedData;
  }

  protected int[] getModifiedArea(IBeeGenome genome, IBeeHousing housing) {
    int[] area = genome.getTerritory();
    int tmp9_8 = 0;
    int[] tmp9_7 = area; tmp9_7[tmp9_8] = ((int)(tmp9_7[tmp9_8] * (housing.getTerritoryModifier(genome, 1.0F) * 3.0F)));
    int tmp28_27 = 1;
    int[] tmp28_26 = area; tmp28_26[tmp28_27] = ((int)(tmp28_26[tmp28_27] * (housing.getTerritoryModifier(genome, 1.0F) * 3.0F)));
    int tmp47_46 = 2;
    int[] tmp47_45 = area; tmp47_45[tmp47_46] = ((int)(tmp47_45[tmp47_46] * (housing.getTerritoryModifier(genome, 1.0F) * 3.0F)));

    if (area[0] < 1)
      area[0] = 1;
    if (area[1] < 1)
      area[1] = 1;
    if (area[2] < 1) {
      area[2] = 1;
    }
    return area;
  }

  protected AxisAlignedBB getBounding(IBeeGenome genome, IBeeHousing housing, float modifier) {
    int[] areaAr = genome.getTerritory();
    Vect area = new Vect(areaAr[0], areaAr[1], areaAr[2]).multiply(modifier);
    Vect offset = new Vect(-Math.round(area.x / 2), -Math.round(area.y / 2), -Math.round(area.z / 2));

    Vect min = new Vect(housing.getXCoord() + offset.x, housing.getYCoord() + offset.y, housing.getZCoord() + offset.z);
    Vect max = new Vect(housing.getXCoord() + offset.x + area.x, housing.getYCoord() + offset.y + area.y, housing.getZCoord() + offset.z + area.z);

    return AxisAlignedBB.getAABBPool().getAABB(min.x, min.y, min.z, max.x, max.y, max.z);
  }
}