package forestry.apiculture.genetics;

import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeekeepingMode;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import net.minecraft.world.World;

public class BeekeepingMode
  implements IBeekeepingMode
{
  public static IBeekeepingMode easy = new BeekeepingMode("EASY", 2.0F, 1.0F, 1.0F, false, false);
  public static IBeekeepingMode normal = new BeekeepingMode("NORMAL", 1.0F, 1.0F, 1.0F, false, true);
  public static IBeekeepingMode hard = new BeekeepingMode("HARD", 0.75F, 1.5F, 1.0F, false, true);
  public static IBeekeepingMode hardcore = new BeekeepingMode("HARDCORE", 0.5F, 5.0F, 0.8F, true, true);
  public static IBeekeepingMode insane = new BeekeepingMode("INSANE", 0.2F, 10.0F, 0.6F, true, true);
  final Random rand;
  final String name;
  final float mutationModifier;
  final float lifespanModifier;
  final float speedModifier;
  final boolean reducesFertility;
  final boolean canFatigue;

  public BeekeepingMode(String name, float mutationModifier, float lifespanModifier, float speedModifier, boolean reducesFertility, boolean canFatigue)
  {
    rand = new Random();
    this.name = name;
    this.mutationModifier = mutationModifier;
    this.lifespanModifier = lifespanModifier;
    this.speedModifier = speedModifier;
    this.reducesFertility = reducesFertility;
    this.canFatigue = canFatigue;
  }

  public String getName()
  {
    return name;
  }

  public ArrayList<String> getDescription()
  {
    ArrayList ret = new ArrayList();
    ret.add("beemode." + name.toLowerCase(Locale.ENGLISH) + ".desc");
    return ret;
  }

  public float getWearModifier()
  {
    return 1.0F;
  }

  public float getMutationModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return mutationModifier;
  }

  public float getLifespanModifier(IBeeGenome genome, IBeeGenome mate, float currentModifier)
  {
    return lifespanModifier;
  }

  public float getProductionModifier(IBeeGenome genome, float currentModifier)
  {
    return speedModifier;
  }

  public float getTerritoryModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getFloweringModifier(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public float getGeneticDecay(IBeeGenome genome, float currentModifier)
  {
    return 1.0F;
  }

  public int getFinalFertility(IBee queen, World world, int x, int y, int z)
  {
    int toCreate = queen.getGenome().getFertility();

    if (reducesFertility) {
      toCreate = new Random().nextInt(toCreate);
    }
    return toCreate;
  }

  public boolean isFatigued(IBee queen, IBeeHousing housing)
  {
    if (!canFatigue) {
      return false;
    }
    if (queen.isNatural()) {
      return false;
    }
    if ((queen.getGeneration() > 96 + rand.nextInt(6) + rand.nextInt(6)) && (rand.nextFloat() < 0.02F * housing.getGeneticDecay(queen.getGenome(), 1.0F)))
    {
      return true;
    }
    return false;
  }

  public boolean isOverworked(IBee queen, IBeeHousing housing)
  {
    float productionModifier = housing.getProductionModifier(queen.getGenome(), 1.0F);
    if ((productionModifier > 16.0F) && 
      (housing.getWorld().rand.nextFloat() * 100.0F < 0.01D * (productionModifier * productionModifier - 100.0F))) {
      return true;
    }

    return false;
  }

  public boolean isDegenerating(IBee queen, IBee offspring, IBeeHousing housing)
  {
    float mutationModifier = housing.getMutationModifier(queen.getGenome(), queen.getMate(), 1.0F);
    if ((mutationModifier > 10.0F) && 
      (housing.getWorld().rand.nextFloat() * 100.0F < 0.4D * (mutationModifier * mutationModifier - 100.0F))) {
      return true;
    }

    return false;
  }

  public boolean isNaturalOffspring(IBee queen)
  {
    if (!queen.isNatural()) {
      return false;
    }
    return true;
  }

  public boolean mayMultiplyPrincess(IBee queen)
  {
    return true;
  }

  public boolean isSealed()
  {
    return false;
  }

  public boolean isSelfLighted()
  {
    return false;
  }

  public boolean isSunlightSimulated()
  {
    return false;
  }

  public boolean isHellish()
  {
    return false;
  }
}