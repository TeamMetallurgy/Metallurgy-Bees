package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import forestry.core.utils.Vect;
import net.minecraft.util.AABBPool;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.biome.BiomeGenBase;

public class JubilanceDefault
  implements IJubilanceProvider
{
  public boolean isJubilant(IAlleleBeeSpecies species, IBeeGenome genome, IBeeHousing housing)
  {
    BiomeGenBase biome = BiomeGenBase.biomeList[housing.getBiomeId()];

    if ((EnumTemperature.getFromValue(biome.temperature) != species.getTemperature()) || (EnumHumidity.getFromValue(biome.rainfall) != species.getHumidity()))
    {
      return false;
    }
    return true;
  }

  protected AxisAlignedBB getBounding(IBeeGenome genome, IBeeHousing housing, float modifier) {
    int[] areaAr = genome.getTerritory();
    Vect area = new Vect(areaAr[0], areaAr[1], areaAr[2]).multiply(modifier);
    Vect offset = new Vect(-Math.round(area.x / 2), -Math.round(area.y / 2), -Math.round(area.z / 2));

    Vect min = new Vect(housing.getXCoord() + offset.x, housing.getYCoord() + offset.y, housing.getZCoord() + offset.z);
    Vect max = new Vect(housing.getXCoord() + offset.x + area.x, housing.getYCoord() + offset.y + area.y, housing.getZCoord() + offset.z + area.z);

    return AxisAlignedBB.getAABBPool().getAABB(min.x, min.y, min.z, max.x, max.y, max.z);
  }
}