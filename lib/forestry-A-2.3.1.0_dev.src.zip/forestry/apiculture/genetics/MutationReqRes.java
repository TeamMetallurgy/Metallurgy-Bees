package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IGenome;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class MutationReqRes extends BeeMutation
{
  private ItemStack blockRequired;

  public MutationReqRes(IAllele allele0, IAllele allele1, IAllele[] template, int chance, ItemStack blockRequired)
  {
    super(allele0, allele1, template, chance);
    this.blockRequired = blockRequired;
  }

  public float getChance(IBeeHousing housing, IAllele allele0, IAllele allele1, IGenome genome0, IGenome genome1)
  {
    float chance = super.getChance(housing, allele0, allele1, genome0, genome1);

    if (chance <= 0.0F) {
      return 0.0F;
    }
    World world = housing.getWorld();
    if (blockRequired == null) {
      return chance;
    }
    int blockid = world.getBlockId(housing.getXCoord(), housing.getYCoord() - 1, housing.getZCoord());
    int meta = world.getBlockMetadata(housing.getXCoord(), housing.getYCoord() - 1, housing.getZCoord());
    if ((blockid == blockRequired.itemID) && (meta == blockRequired.getItemDamage())) {
      return chance;
    }
    return 0.0F;
  }
}