package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeeMutation;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.apiculture.IBeekeepingMode;
import forestry.api.genetics.AlleleManager;
import forestry.api.genetics.IAllele;
import forestry.api.genetics.IAlleleRegistry;
import forestry.api.genetics.IGenome;
import forestry.core.genetics.Mutation;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeDictionary.Type;

public class BeeMutation extends Mutation
  implements IBeeMutation
{
  private IBeeRoot root;
  boolean requiresDay = false;
  boolean requiresNight = false;

  private ArrayList<BiomeDictionary.Type> restrictBiomeTypes = new ArrayList();
  private boolean strictBiomeCheck = false;

  public BeeMutation(IAllele allele0, IAllele allele1, IAllele[] template, int chance) {
    super(allele0, allele1, template, chance);

    root = ((IBeeRoot)AlleleManager.alleleRegistry.getSpeciesRoot("rootBees"));
    PluginApiculture.beeInterface.registerMutation(this);
  }

  public IBeeRoot getRoot()
  {
    return root;
  }

  public BeeMutation enableStrictBiomeCheck() {
    strictBiomeCheck = true;
    return this;
  }

  public BeeMutation restrictBiomeType(BiomeDictionary.Type type) {
    restrictBiomeTypes.add(type);
    specialConditions.add(String.format("Is restricted to %s-like environments.", new Object[] { type.toString() }));
    return this;
  }

  public BeeMutation requireDay() {
    requiresDay = true;
    requiresNight = false;
    specialConditions.add("Can only occur during the day.");
    return this;
  }

  public BeeMutation requireNight() {
    requiresDay = false;
    requiresNight = true;
    specialConditions.add("Can only occur during the night.");
    return this;
  }

  public float getChance(IBeeHousing housing, IAllele allele0, IAllele allele1, IGenome genome0, IGenome genome1)
  {
    World world = housing.getWorld();
    if ((requiresDay) && (!world.isDaytime())) {
      return 0.0F;
    }
    if ((requiresNight) && (world.isDaytime())) {
      return 0.0F;
    }

    if (restrictBiomeTypes.size() > 0) {
      boolean noneMatched = true;

      BiomeGenBase biome = BiomeGenBase.biomeList[housing.getBiomeId()];
      if (strictBiomeCheck) {
        BiomeDictionary.Type[] types = BiomeDictionary.getTypesForBiome(biome);
        if ((types.length == 1) && (restrictBiomeTypes.contains(types[0])))
          noneMatched = false;
      } else {
        for (BiomeDictionary.Type type : restrictBiomeTypes) {
          if (BiomeDictionary.isBiomeOfType(biome, type)) {
            noneMatched = false;
            break;
          }
        }
      }

      if (noneMatched) {
        return 0.0F;
      }
    }
    BiomeGenBase biome = world.getWorldChunkManager().getBiomeGenAt(housing.getXCoord(), housing.getZCoord());
    if ((biome.temperature < minTemperature) || (biome.temperature > maxTemperature))
      return 0.0F;
    if ((biome.rainfall < minRainfall) || (biome.rainfall > maxRainfall)) {
      return 0.0F;
    }
    float processedChance = chance * housing.getMutationModifier((IBeeGenome)genome0, (IBeeGenome)genome1, 1.0F) * PluginApiculture.beeInterface.getBeekeepingMode(world).getMutationModifier((IBeeGenome)genome0, (IBeeGenome)genome1, 1.0F);

    if (processedChance <= 0.0F) {
      return 0.0F;
    }
    if ((this.allele0.getUID().equals(allele0.getUID())) && (this.allele1.getUID().equals(allele1.getUID())))
      return processedChance;
    if ((this.allele1.getUID().equals(allele0.getUID())) && (this.allele0.getUID().equals(allele1.getUID()))) {
      return processedChance;
    }
    return 0.0F;
  }
}