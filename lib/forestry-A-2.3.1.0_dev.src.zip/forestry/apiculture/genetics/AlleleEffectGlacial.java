package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.core.EnumTemperature;
import forestry.api.genetics.IEffectData;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.Vect;
import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;

public class AlleleEffectGlacial extends AlleleEffectThrottled
{
  public AlleleEffectGlacial(String uid)
  {
    super(uid, "glacial", false, 200, true, false);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    World world = housing.getWorld();

    if (isHalted(storedData, housing)) {
      return storedData;
    }
    if (EnumTemperature.hellishBiomeIds.contains(Integer.valueOf(housing.getBiomeId())))
      return storedData;
    if (EnumTemperature.hotBiomeIds.contains(Integer.valueOf(housing.getBiomeId())))
      return storedData;
    if (EnumTemperature.warmBiomeIds.contains(Integer.valueOf(housing.getBiomeId()))) {
      return storedData;
    }
    int[] areaAr = genome.getTerritory();
    Vect area = new Vect(areaAr[0], areaAr[1], areaAr[2]);
    Vect offset = new Vect(-Math.round(area.x / 2), -Math.round(area.y / 2), -Math.round(area.z / 2));

    for (int i = 0; i < 10; i++)
    {
      Vect randomPos = new Vect(world.rand.nextInt(area.x), world.rand.nextInt(area.y), world.rand.nextInt(area.z));

      Vect posBlock = randomPos.add(new Vect(housing.getXCoord(), housing.getYCoord(), housing.getZCoord()));
      posBlock = posBlock.add(offset);

      int blockid = world.getBlockId(posBlock.x, posBlock.y, posBlock.z);
      if (blockid == Block.waterStill.blockID)
      {
        if (world.isAirBlock(posBlock.x, posBlock.y + 1, posBlock.z))
        {
          Proxies.common.setBlockWithNotify(world, posBlock.x, posBlock.y, posBlock.z, Block.ice.blockID);
        }
      }
    }
    return storedData;
  }
}