package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class AlleleEffectExploration extends AlleleEffectThrottled
{
  public AlleleEffectExploration(String uid)
  {
    super(uid, "exploration", false, 80, true, false);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    if (isHalted(storedData, housing)) {
      return storedData;
    }
    AxisAlignedBB beatifyBox = getBounding(genome, housing, 1.0F);
    List list = housing.getWorld().getEntitiesWithinAABB(EntityPlayer.class, beatifyBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      EntityPlayer player = (EntityPlayer)obj;
      player.addExperience(2);
    }

    return storedData;
  }
}