package forestry.apiculture.genetics;

import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.apiculture.IHiveDrop;
import forestry.api.genetics.IAllele;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class HiveDrop
  implements IHiveDrop
{
  private IAllele[] template;
  private ArrayList<ItemStack> additional = new ArrayList();
  private int chance;
  private float ignobleShare = 0.0F;

  public HiveDrop(IAllele[] template, ItemStack[] bonus, int chance) {
    this.template = template;
    this.chance = chance;

    for (ItemStack stack : bonus)
      additional.add(stack);
  }

  public HiveDrop setIgnobleShare(float share) {
    ignobleShare = share;
    return this;
  }

  private IBee createBee(World world) {
    IBee bee = PluginApiculture.beeInterface.getBee(world, PluginApiculture.beeInterface.templateAsGenome(template));
    if (world.rand.nextFloat() < ignobleShare)
      bee.setIsNatural(false);
    return bee;
  }

  public ItemStack getPrincess(World world, int x, int y, int z, int fortune)
  {
    return PluginApiculture.beeInterface.getMemberStack(createBee(world), EnumBeeType.PRINCESS.ordinal());
  }

  public ArrayList<ItemStack> getDrones(World world, int x, int y, int z, int fortune)
  {
    ArrayList ret = new ArrayList();
    ret.add(PluginApiculture.beeInterface.getMemberStack(createBee(world), EnumBeeType.DRONE.ordinal()));

    return ret;
  }

  public ArrayList<ItemStack> getAdditional(World world, int x, int y, int z, int fortune)
  {
    ArrayList ret = new ArrayList();
    for (ItemStack stack : additional) {
      ret.add(stack.copy());
    }
    return ret;
  }

  public int getChance(World world, int x, int y, int z)
  {
    return chance;
  }
}