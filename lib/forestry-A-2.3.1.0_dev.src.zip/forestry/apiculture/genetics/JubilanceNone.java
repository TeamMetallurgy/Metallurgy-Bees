package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;

public class JubilanceNone
  implements IJubilanceProvider
{
  public boolean isJubilant(IAlleleBeeSpecies species, IBeeGenome genome, IBeeHousing housing)
  {
    return false;
  }
}