package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class JubilanceReqRes
  implements IJubilanceProvider
{
  private ItemStack blockRequired;

  public JubilanceReqRes(ItemStack blockRequired)
  {
    this.blockRequired = blockRequired;
  }

  public boolean isJubilant(IAlleleBeeSpecies species, IBeeGenome genome, IBeeHousing housing)
  {
    if (blockRequired == null) {
      return true;
    }
    int blockid = housing.getWorld().getBlockId(housing.getXCoord(), housing.getYCoord() - 1, housing.getZCoord());
    int meta = housing.getWorld().getBlockMetadata(housing.getXCoord(), housing.getYCoord() - 1, housing.getZCoord());
    if ((blockid == blockRequired.itemID) && (meta == blockRequired.getItemDamage())) {
      return true;
    }
    return false;
  }
}