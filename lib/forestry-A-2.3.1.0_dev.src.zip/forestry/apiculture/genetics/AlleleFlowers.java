package forestry.apiculture.genetics;

import forestry.api.genetics.IAlleleFlowers;
import forestry.api.genetics.IFlowerProvider;
import forestry.core.genetics.Allele;

public class AlleleFlowers extends Allele
  implements IAlleleFlowers
{
  IFlowerProvider provider;

  public AlleleFlowers(String uid, IFlowerProvider provider)
  {
    this(uid, provider, false);
  }

  public AlleleFlowers(String uid, IFlowerProvider provider, boolean isDominant) {
    super(uid, isDominant);
    this.provider = provider;
  }

  public IFlowerProvider getProvider()
  {
    return provider;
  }

  public String getName()
  {
    return getProvider().getDescription();
  }
}