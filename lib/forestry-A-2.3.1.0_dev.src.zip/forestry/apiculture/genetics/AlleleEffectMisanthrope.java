package forestry.apiculture.genetics;

import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.items.ItemArmorApiarist;
import forestry.core.utils.DamageSourceForestry;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class AlleleEffectMisanthrope extends AlleleEffectThrottled
{
  public static DamageSource damageSourceBeeEnd = new DamageSourceForestry("bee.end");

  public AlleleEffectMisanthrope(String uid) {
    super(uid, "misanthrope", true, 20, false, false);
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    if (isHalted(storedData, housing)) {
      return storedData;
    }
    AxisAlignedBB beatifyBox = getBounding(genome, housing, 1.0F);
    List list = housing.getWorld().getEntitiesWithinAABB(EntityPlayer.class, beatifyBox);

    for (Iterator i$ = list.iterator(); i$.hasNext(); ) { Object obj = i$.next();
      EntityPlayer player = (EntityPlayer)obj;

      int damage = 4;

      int count = ItemArmorApiarist.wearsItems(player, getUID(), true);

      if (count <= 3)
      {
        if (count > 2)
          damage = 1;
        else if (count > 1)
          damage = 2;
        else if (count > 0) {
          damage = 3;
        }
        player.attackEntityFrom(damageSourceBeeEnd, damage);
      }
    }
    return storedData;
  }
}