package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeEffect;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.genetics.IEffectData;
import forestry.apiculture.proxy.ProxyApiculture;
import forestry.core.genetics.Allele;
import forestry.plugins.PluginApiculture;
import net.minecraft.world.World;

public class AlleleEffectNone extends Allele
  implements IAlleleBeeEffect
{
  public AlleleEffectNone(String uid)
  {
    super(uid, true);
  }

  public IEffectData validateStorage(IEffectData storedData)
  {
    return null;
  }

  public boolean isCombinable()
  {
    return false;
  }

  public IEffectData doEffect(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    return doEffect(genome, storedData, housing.getWorld(), housing.getBiomeId(), housing.getXCoord(), housing.getYCoord(), housing.getZCoord());
  }

  protected IEffectData doEffect(IBeeGenome genome, IEffectData storedData, World world, int biomeid, int x, int y, int z) {
    return storedData;
  }

  public String getName()
  {
    return "None";
  }

  public IEffectData doFX(IBeeGenome genome, IEffectData storedData, IBeeHousing housing)
  {
    int[] area = genome.getTerritory();
    int tmp11_10 = 0;
    int[] tmp11_8 = area; tmp11_8[tmp11_10] = ((int)(tmp11_8[tmp11_10] * housing.getTerritoryModifier(genome, 1.0F)));
    int tmp28_27 = 1;
    int[] tmp28_25 = area; tmp28_25[tmp28_27] = ((int)(tmp28_25[tmp28_27] * housing.getTerritoryModifier(genome, 1.0F)));
    int tmp45_44 = 2;
    int[] tmp45_42 = area; tmp45_42[tmp45_44] = ((int)(tmp45_42[tmp45_44] * housing.getTerritoryModifier(genome, 1.0F)));

    if (area[0] < 1)
      area[0] = 1;
    if (area[1] < 1)
      area[1] = 1;
    if (area[2] < 1) {
      area[2] = 1;
    }
    PluginApiculture.proxy.addBeeHiveFX("particles/swarm_bee", housing.getWorld(), housing.getXCoord(), housing.getYCoord(), housing.getZCoord(), genome.getPrimary().getIconColour(0), area[0], area[1], area[2]);

    return storedData;
  }
}