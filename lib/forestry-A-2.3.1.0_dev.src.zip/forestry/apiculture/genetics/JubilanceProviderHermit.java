package forestry.apiculture.genetics;

import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeHousing;
import java.util.List;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

public class JubilanceProviderHermit extends JubilanceDefault
{
  public boolean isJubilant(IAlleleBeeSpecies species, IBeeGenome genome, IBeeHousing housing)
  {
    AxisAlignedBB bounding = getBounding(genome, housing, 1.0F);

    List list = housing.getWorld().getEntitiesWithinAABB(EntityLiving.class, bounding);
    if (list.size() > 0) {
      return false;
    }
    return true;
  }
}