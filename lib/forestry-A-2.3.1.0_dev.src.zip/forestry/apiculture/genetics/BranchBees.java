package forestry.apiculture.genetics;

import forestry.core.genetics.Branch;

public class BranchBees extends Branch
{
  public BranchBees(String uid, String scientific)
  {
    super("bees." + uid, scientific);
  }
}