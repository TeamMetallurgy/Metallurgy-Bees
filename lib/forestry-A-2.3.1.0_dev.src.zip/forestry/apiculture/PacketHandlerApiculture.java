package forestry.apiculture;

import cpw.mods.fml.common.network.Player;
import forestry.apiculture.gui.ContainerImprinter;
import forestry.core.interfaces.IPacketHandler;
import forestry.core.network.PacketCoordinates;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import java.io.DataInputStream;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.INetworkManager;

public class PacketHandlerApiculture
  implements IPacketHandler
{
  public void onPacketData(INetworkManager network, int packetID, DataInputStream data, Player player)
  {
    try
    {
      switch (packetID) {
      case 20:
        PacketCoordinates packetC = new PacketCoordinates();
        packetC.readData(data);
        Proxies.common.setBiomefinderCoordinates((EntityPlayer)player, packetC.getCoordinates());
        break;
      case 31:
        onImprintSelectionGet((EntityPlayer)player);
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private void onImprintSelectionGet(EntityPlayer playerEntity)
  {
    if (!(playerEntity.openContainer instanceof ContainerImprinter)) {
      return;
    }
    ((ContainerImprinter)playerEntity.openContainer).sendSelection(playerEntity);
  }
}