package forestry.apiculture;

import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.IApiaristTracker;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeHousing;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.apiculture.IBeekeepingLogic;
import forestry.api.genetics.IEffectData;
import forestry.api.genetics.IIndividual;
import forestry.core.EnumErrorCode;
import forestry.core.config.ForestryItem;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyLog;
import forestry.plugins.PluginApiculture;
import java.util.Stack;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public class BeekeepingLogic
  implements IBeekeepingLogic
{
  private static final int MAX_POLLINATION_ATTEMPTS = 20;
  IBeeHousing housing;
  private int breedingTime;
  private int totalBreedingTime = 100;
  private int throttle;
  private IEffectData[] effectData = new IEffectData[2];
  private IBee queen;
  private IIndividual pollen;
  private int attemptedPollinations = 0;
  private Stack<ItemStack> spawn = new Stack();

  public BeekeepingLogic(IBeeHousing housing) {
    this.housing = housing;
  }

  public void readFromNBT(NBTTagCompound nbttagcompound)
  {
    breedingTime = nbttagcompound.getInteger("BreedingTime");
    throttle = nbttagcompound.getInteger("Throttle");

    NBTTagList nbttaglist = new NBTTagList();
    while (!spawn.isEmpty()) {
      NBTTagCompound nbttagcompound1 = new NBTTagCompound();
      ((ItemStack)spawn.pop()).writeToNBT(nbttagcompound1);
      nbttaglist.appendTag(nbttagcompound1);
    }
    nbttagcompound.setTag("Offspring", nbttaglist);
  }

  public void writeToNBT(NBTTagCompound nbttagcompound)
  {
    nbttagcompound.setInteger("BreedingTime", breedingTime);
    nbttagcompound.setInteger("Throttle", throttle);

    NBTTagList nbttaglist = nbttagcompound.getTagList("Offspring");
    for (int i = 0; i < nbttaglist.tagCount(); i++)
      spawn.add(ItemStack.loadItemStackFromNBT((NBTTagCompound)nbttaglist.tagAt(i)));
  }

  public int getBreedingTime()
  {
    return breedingTime;
  }

  public int getTotalBreedingTime()
  {
    return totalBreedingTime;
  }

  public IBee getQueen()
  {
    return queen;
  }

  public IBeeHousing getHousing() {
    return housing;
  }

  public IEffectData[] getEffectData()
  {
    return effectData;
  }

  public void update()
  {
    resetQueen(null);

    if (!spawn.isEmpty()) {
      ItemStack next = (ItemStack)spawn.peek();
      if (housing.addProduct(next, true)) {
        spawn.pop();
        housing.setErrorState(EnumErrorCode.OK.ordinal());
      } else {
        housing.setErrorState(EnumErrorCode.NOSPACE.ordinal());
      }return;
    }

    if (housing.getQueen() == null) {
      housing.setErrorState(EnumErrorCode.NOQUEEN.ordinal());
      return;
    }

    if (ForestryItem.beePrincessGE.isItemEqual(housing.getQueen())) {
      if (ForestryItem.beeDroneGE.isItemEqual(housing.getDrone()))
        housing.setErrorState(EnumErrorCode.NODRONE.ordinal());
      else
        housing.setErrorState(EnumErrorCode.OK.ordinal());
      tickBreed();
      return;
    }

    if (!ForestryItem.beeQueenGE.isItemEqual(housing.getQueen())) {
      housing.setErrorState(EnumErrorCode.NOQUEEN.ordinal());
      return;
    }

    IBee queen = PluginApiculture.beeInterface.getMember(housing.getQueen());

    if (!queen.isAlive()) {
      killQueen(queen);
      housing.setErrorState(EnumErrorCode.OK.ordinal());
      return;
    }

    resetQueen(queen);

    EnumErrorCode state = EnumErrorCode.values()[queen.isWorking(housing)];
    if (state != EnumErrorCode.OK) {
      housing.setErrorState(state.ordinal());
      return;
    }if (housing.getErrorOrdinal() != EnumErrorCode.NOFLOWER.ordinal()) {
      housing.setErrorState(EnumErrorCode.OK.ordinal());
    }

    effectData = queen.doEffect(effectData, housing);

    throttle += 1;

    if (throttle >= PluginApiculture.beeCycleTicks)
      throttle = 0;
    else {
      return;
    }

    if (!queen.hasFlower(housing)) {
      housing.setErrorState(EnumErrorCode.NOFLOWER.ordinal());
      return;
    }
    housing.setErrorState(EnumErrorCode.OK.ordinal());

    ItemStack[] products = queen.produceStacks(housing);
    housing.wearOutEquipment(1);
    for (ItemStack stack : products) {
      housing.addProduct(stack, false);
    }

    queen.plantFlowerRandom(housing);

    if (pollen == null) {
      pollen = queen.retrievePollen(housing);
      attemptedPollinations = 0;
      if ((pollen != null) && 
        (housing.onPollenRetrieved(queen, pollen, false))) {
        pollen = null;
      }
    }
    if (pollen != null) {
      attemptedPollinations += 1;
      if ((queen.pollinateRandom(housing, pollen)) || (attemptedPollinations >= 20))
      {
        pollen = null;
      }

    }

    queen.age(housing.getWorld(), housing.getLifespanModifier(queen.getGenome(), queen.getMate(), 0.0F));

    NBTTagCompound nbttagcompound = new NBTTagCompound();
    queen.writeToNBT(nbttagcompound);
    housing.getQueen().setTagCompound(nbttagcompound);
  }

  private void resetQueen(IBee bee)
  {
    queen = bee;
  }

  private void tickBreed()
  {
    if (!tryBreed()) {
      breedingTime = 0;
      return;
    }

    if (breedingTime < totalBreedingTime)
      breedingTime += 1;
    if (breedingTime < totalBreedingTime) {
      return;
    }

    if (!ForestryItem.beePrincessGE.isItemEqual(housing.getQueen())) {
      return;
    }

    IBee princess = PluginApiculture.beeInterface.getMember(housing.getQueen());
    IBee drone = PluginApiculture.beeInterface.getMember(housing.getDrone());
    princess.mate(drone);

    NBTTagCompound nbttagcompound = new NBTTagCompound();
    princess.writeToNBT(nbttagcompound);
    ItemStack queen = ForestryItem.beeQueenGE.getItemStack();
    queen.setTagCompound(nbttagcompound);

    housing.setQueen(queen);
    housing.onQueenChange(housing.getQueen());

    PluginApiculture.beeInterface.getBreedingTracker(housing.getWorld(), housing.getOwnerName()).registerQueen(princess);

    housing.getDrone().stackSize -= 1;
    if (housing.getDrone().stackSize <= 0) {
      housing.setDrone(null);
    }

    breedingTime = 0;
  }

  private boolean tryBreed() {
    if ((housing.getDrone() == null) || (housing.getQueen() == null)) {
      return false;
    }
    if ((!ForestryItem.beeDroneGE.isItemEqual(housing.getDrone())) || (!ForestryItem.beePrincessGE.isItemEqual(housing.getQueen()))) {
      return false;
    }
    if (!housing.canBreed()) {
      return false;
    }
    return true;
  }

  private void killQueen(IBee queen) {
    if (queen.canSpawn()) {
      spawnOffspring(queen);
      housing.getQueen().stackSize = 0;
      housing.setQueen(null);
    } else {
      Proxies.log.warning("Tried to spawn offspring off an unmated queen. Devolving her to a princess.");

      ItemStack convert = ForestryItem.beePrincessGE.getItemStack();
      NBTTagCompound nbttagcompound = new NBTTagCompound();
      queen.writeToNBT(nbttagcompound);
      convert.setTagCompound(nbttagcompound);

      spawn.add(convert);
      housing.setQueen(null);
    }
    housing.onQueenChange(housing.getQueen());
  }

  private void spawnOffspring(IBee queen)
  {
    Stack offspring = new Stack();
    IApiaristTracker breedingTracker = PluginApiculture.beeInterface.getBreedingTracker(housing.getWorld(), housing.getOwnerName());

    housing.onQueenDeath(getQueen());

    IBee heiress = queen.spawnPrincess(housing);
    if (heiress != null) {
      ItemStack princess = PluginApiculture.beeInterface.getMemberStack(heiress, EnumBeeType.PRINCESS.ordinal());
      breedingTracker.registerPrincess(heiress);
      offspring.push(princess);
    }

    IBee[] larvae = queen.spawnDrones(housing);
    for (IBee larva : larvae) {
      ItemStack drone = PluginApiculture.beeInterface.getMemberStack(larva, EnumBeeType.DRONE.ordinal());
      breedingTracker.registerDrone(larva);
      offspring.push(drone);
    }

    while (!offspring.isEmpty()) {
      ItemStack spawned = (ItemStack)offspring.pop();
      if (!housing.addProduct(spawned, true)) {
        spawn.add(spawned);
      }
    }
    housing.onPostQueenDeath(getQueen());
  }
}