package forestry.apiculture.render;

import forestry.apiculture.entities.EntityBee;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public class RenderBee extends RenderLiving
{
  ModelBee beeModel;

  public RenderBee()
  {
    super(new ModelBee(), 0.15F);
    beeModel = ((ModelBee)mainModel);
  }

  public void renderBee(EntityBee entity, double posX, double posY, double posZ, float par8, float par9) {
    beeModel.setType(entity.getType());
    doRenderLiving(entity, posX, posY, posZ, par8, par9);
  }

  public void doRender(Entity entity, double posX, double posY, double posZ, float par8, float par9)
  {
    renderBee((EntityBee)entity, posX, posY, posZ, par8, par9);
  }

  protected ResourceLocation getEntityTexture(Entity entity)
  {
    return ((EntityBee)entity).getTexture();
  }
}