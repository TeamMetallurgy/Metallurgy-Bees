package forestry.apiculture.render;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.ITickHandler;
import cpw.mods.fml.common.TickType;
import cpw.mods.fml.common.registry.TickRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.profiler.Profiler;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.ForgeSubscribe;
import net.minecraftforge.event.world.WorldEvent.Unload;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class ParticleRenderer
  implements ITickHandler
{
  private static final String name = "forestry-particles";
  private static ParticleRenderer instance = null;

  private boolean lazyAdd = false;
  private final List<EntityFX> particles = new ArrayList();
  private final List<EntityFX> newParticles = new ArrayList();

  public static synchronized ParticleRenderer getInstance()
  {
    if (instance == null) instance = new ParticleRenderer();

    return instance;
  }

  public synchronized void addEffect(EntityFX particle)
  {
    if (lazyAdd)
      newParticles.add(particle);
    else
      particles.add(particle);
  }

  @ForgeSubscribe
  public void onRenderWorldLast(RenderWorldLastEvent event)
  {
    render(event.partialTicks);
  }

  @ForgeSubscribe
  public void onWorldUnload(WorldEvent.Unload event) {
    if (FMLCommonHandler.instance().getEffectiveSide().isClient())
      synchronized (this) {
        particles.clear();
      }
  }

  public void tickStart(EnumSet<TickType> type, Object[] tickData)
  {
  }

  public void tickEnd(EnumSet<TickType> type, Object[] tickData)
  {
    update();
  }

  public EnumSet<TickType> ticks()
  {
    return EnumSet.of(TickType.CLIENT);
  }

  public String getLabel()
  {
    return "forestry-particles";
  }

  private ParticleRenderer()
  {
    MinecraftForge.EVENT_BUS.register(this);
    TickRegistry.registerTickHandler(this, Side.CLIENT);
  }

  private synchronized void update() {
    Minecraft.getMinecraft().mcProfiler.startSection("forestry-particles-update");

    lazyAdd = true;

    for (Iterator it = particles.iterator(); it.hasNext(); ) {
      EntityFX particle = (EntityFX)it.next();

      particle.onUpdate();

      if (particle.isDead) {
        it.remove();
      }
    }

    lazyAdd = false;
    particles.addAll(newParticles);
    newParticles.clear();

    Minecraft.getMinecraft().mcProfiler.endSection();
  }

  private synchronized void render(float partialTicks) {
    Minecraft.getMinecraft().mcProfiler.startSection("forestry-particles-render");

    float rotationX = ActiveRenderInfo.rotationX;
    float rotationZ = ActiveRenderInfo.rotationZ;
    float rotationYZ = ActiveRenderInfo.rotationYZ;
    float rotationXY = ActiveRenderInfo.rotationXY;
    float rotationXZ = ActiveRenderInfo.rotationXZ;

    EntityLivingBase player = Minecraft.getMinecraft().renderViewEntity;
    EntityFX.interpPosX = player.lastTickPosX + (player.posX - player.lastTickPosX) * partialTicks;
    EntityFX.interpPosY = player.lastTickPosY + (player.posY - player.lastTickPosY) * partialTicks;
    EntityFX.interpPosZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * partialTicks;

    Minecraft.getMinecraft().renderEngine.bindTexture(TextureMap.locationItemsTexture);

    GL11.glPushAttrib(16640);

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glDepthMask(false);
    GL11.glEnable(3042);
    GL11.glBlendFunc(770, 1);
    GL11.glAlphaFunc(516, 0.003921569F);

    Tessellator tessellator = Tessellator.instance;
    tessellator.startDrawingQuads();

    for (EntityFX particle : particles) {
      tessellator.setBrightness(particle.getBrightnessForRender(partialTicks));

      particle.renderParticle(tessellator, partialTicks, rotationX, rotationXZ, rotationZ, rotationYZ, rotationXY);
    }

    tessellator.draw();

    GL11.glPopAttrib();

    Minecraft.getMinecraft().mcProfiler.endSection();
  }
}