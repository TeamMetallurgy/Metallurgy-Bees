package forestry.apiculture.render;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;

public class TextureBiomefinder extends TextureAtlasSprite
{
  private static TextureBiomefinder instance;
  private ChunkCoordinates targetBiome;
  public double currentAngle;
  public double angleDelta;

  public static TextureBiomefinder getInstance()
  {
    return instance;
  }

  public TextureBiomefinder()
  {
    super("biomefinder");
    instance = this;
  }

  public void setTargetCoordinates(ChunkCoordinates coordinates) {
    targetBiome = coordinates;
  }

  public void updateAnimation() {
    Minecraft minecraft = Minecraft.getMinecraft();

    if ((minecraft.theWorld != null) && (minecraft.thePlayer != null))
      updateCompass(minecraft.theWorld, minecraft.thePlayer.posX, minecraft.thePlayer.posZ, minecraft.thePlayer.rotationYaw, false, true);
    else
      updateCompass((World)null, 0.0D, 0.0D, 0.0D, true, true);
  }

  public void updateCompass(World world, double playerX, double playerZ, double playerYaw, boolean par8, boolean hasSpin)
  {
    double targetAngle = 0.0D;

    if ((world == null) || (targetBiome == null))
    {
      targetAngle = Math.random() * 3.141592653589793D * 2.0D;
    } else {
      double xPart = targetBiome.posX - playerX;
      double yPart = targetBiome.posZ - playerZ;
      targetAngle = (playerYaw - 90.0D) * 3.141592653589793D / 180.0D - Math.atan2(yPart, xPart);
    }

    if (!hasSpin) {
      currentAngle = targetAngle;
    }
    else
    {
      for (double angleChange = targetAngle - currentAngle; angleChange < -3.141592653589793D; angleChange += 6.283185307179586D);
      while (angleChange >= 3.141592653589793D) {
        angleChange -= 6.283185307179586D;
      }
      if (angleChange < -1.0D) {
        angleChange = -1.0D;
      }
      if (angleChange > 1.0D) {
        angleChange = 1.0D;
      }
      angleDelta += angleChange * 0.1D;
      angleDelta *= 0.8D;
      currentAngle += angleDelta;
    }

    for (int i = (int)((currentAngle / 6.283185307179586D + 1.0D) * framesTextureData.size()) % framesTextureData.size(); i < 0; i = (i + framesTextureData.size()) % framesTextureData.size());
    if (i != frameCounter) {
      frameCounter = i;
      TextureUtil.uploadTextureSub((int[])framesTextureData.get(frameCounter), width, height, originX, originY, false, false);
    }
  }
}