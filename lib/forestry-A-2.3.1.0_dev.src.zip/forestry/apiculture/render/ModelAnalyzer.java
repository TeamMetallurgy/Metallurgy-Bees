package forestry.apiculture.render;

import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.utils.ForestryResource;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.ForgeDirection;
import org.lwjgl.opengl.GL11;

public class ModelAnalyzer extends ModelBase
{
  private ModelRenderer pedestal;
  private ModelRenderer cover;
  private ModelRenderer tower1;
  private ModelRenderer tower2;
  private ResourceLocation[] textures;

  public ModelAnalyzer(String gfxBase)
  {
    textures = new ResourceLocation[] { new ForestryResource(gfxBase + "pedestal.png"), new ForestryResource(gfxBase + "tower1.png"), new ForestryResource(gfxBase + "tower2.png") };

    pedestal = new ModelRenderer(this, 0, 0);
    pedestal.addBox(-8.0F, -8.0F, -8.0F, 16, 1, 16);
    pedestal.setRotationPoint(8.0F, 8.0F, 8.0F);

    cover = new ModelRenderer(this, 0, 0);
    cover.addBox(-8.0F, -8.0F, -8.0F, 16, 1, 16);
    cover.setRotationPoint(8.0F, 8.0F, 8.0F);

    tower1 = new ModelRenderer(this, 0, 0);
    tower1.addBox(-8.0F, -7.0F, -7.0F, 2, 14, 14);
    tower1.setRotationPoint(8.0F, 8.0F, 8.0F);

    tower2 = new ModelRenderer(this, 0, 0);
    tower2.addBox(6.0F, -7.0F, -7.0F, 2, 14, 14);
    tower2.setRotationPoint(8.0F, 8.0F, 8.0F);
  }

  public void render(ForgeDirection orientation, float posX, float posY, float posZ)
  {
    GL11.glPushMatrix();
    GL11.glDisable(2896);

    GL11.glTranslatef(posX, posY, posZ);
    float[] angle = { 0.0F, 0.0F, 0.0F };

    if (orientation == null)
      orientation = ForgeDirection.WEST;
    switch (1.$SwitchMap$net$minecraftforge$common$ForgeDirection[orientation.ordinal()]) {
    case 1:
      angle[1] = 1.570796F;
      break;
    case 2:
      angle[1] = -1.570796F;
      break;
    case 3:
      break;
    case 4:
    default:
      angle[1] = 3.141593F;
    }

    float factor = 0.0625F;

    Proxies.common.bindTexture(textures[0]);

    pedestal.rotateAngleX = angle[0];
    pedestal.rotateAngleY = angle[1];
    pedestal.rotateAngleZ = angle[2];
    pedestal.render(factor);

    cover.rotateAngleX = angle[0];
    cover.rotateAngleY = angle[1];
    cover.rotateAngleZ = 3.141593F;
    cover.render(factor);

    tower1.rotateAngleX = angle[0];
    tower1.rotateAngleY = angle[1];
    tower1.rotateAngleZ = angle[2];
    Proxies.common.bindTexture(textures[1]);
    tower1.render(factor);

    tower2.rotateAngleX = angle[0];
    tower2.rotateAngleY = angle[1];
    tower2.rotateAngleZ = angle[2];
    Proxies.common.bindTexture(textures[2]);
    tower2.render(factor);

    GL11.glEnable(2896);
    GL11.glPopMatrix();
  }
}