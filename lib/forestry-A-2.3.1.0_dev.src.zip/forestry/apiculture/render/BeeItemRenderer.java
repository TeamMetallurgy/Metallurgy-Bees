package forestry.apiculture.render;

import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.apiculture.entities.EntityBee;
import forestry.core.proxy.Proxies;
import forestry.core.proxy.ProxyCommon;
import forestry.core.render.SpriteSheet;
import forestry.core.render.TextureManager;
import forestry.plugins.PluginApiculture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Icon;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import org.lwjgl.opengl.GL11;

public class BeeItemRenderer
  implements IItemRenderer
{
  ModelBee model;
  EntityBee entity;

  private static float getWingYaw(IBee bee)
  {
    float wingYaw = 1.0F;

    if (bee.isAlive()) {
      long systemTime = System.currentTimeMillis();
      long flapping = systemTime + bee.getIdent().hashCode();
      float flap = (float)(flapping % 1000L) / 1000.0F;

      wingYaw = getIrregularWingYaw(flapping, flap);
    }

    return wingYaw;
  }

  public static float getIrregularWingYaw(long flapping, float flap) {
    long irregular = flapping / 1000L;
    float wingYaw = 1.0F;

    if (irregular % 11L == 0L) {
      wingYaw = 0.75F;
    } else {
      if ((irregular % 7L == 0L) || (irregular % 19L == 0L)) {
        flap *= 8.0F;
        flap %= 1.0F;
      }
      wingYaw = getRegularWingYaw(flap);
    }

    return wingYaw;
  }

  public static float getRegularWingYaw(float flap) {
    return flap < 0.5D ? 0.75F + flap : 1.75F - flap;
  }

  private IBee initBee(ItemStack item, boolean scaled) {
    IBee bee = PluginApiculture.beeInterface.getMember(item);
    if (bee == null) {
      bee = PluginApiculture.beeInterface.templateAsIndividual(PluginApiculture.beeInterface.getDefaultTemplate());
    }
    if (entity == null) {
      entity = new EntityBee(Proxies.common.getClientInstance().theWorld);
    }
    entity.setSpecies(bee.getGenome().getPrimary());
    entity.setType(PluginApiculture.beeInterface.getType(item));

    return bee;
  }

  private void renderBeeHalo()
  {
    Icon background = TextureManager.getInstance().getDefault("habitats/desert");
    float xPos = 1.0F; float yPos = 1.0F;
    float width = 1.0F; float height = 1.0F;

    Proxies.common.bindTexture(SpriteSheet.ITEMS);
    Tessellator tessellator = Tessellator.instance;
    tessellator.startDrawingQuads();
    tessellator.addVertexWithUV(xPos + 0.0F, yPos + height, 0.0D, background.getMinU(), background.getMaxV());
    tessellator.addVertexWithUV(xPos + width, yPos + height, 0.0D, background.getMaxU(), background.getMaxV());
    tessellator.addVertexWithUV(xPos + width, yPos + 0.0F, 0.0D, background.getMaxU(), background.getMinV());
    tessellator.addVertexWithUV(xPos + 0.0F, yPos + 0.0F, 0.0D, background.getMinU(), background.getMinV());
    tessellator.draw();
  }

  private void renderBeeItem(IBee bee, float translateX, float translateY, float translateZ) {
    float yaw = 1.0F;
    float pitch = 1.0F;

    GL11.glPushAttrib(8192);
    GL11.glEnable(2896);
    GL11.glEnable(2929);
    GL11.glEnable(2903);

    GL11.glPushMatrix();

    GL11.glScalef(2.0F, 2.0F, 2.0F);
    GL11.glTranslatef(translateX, translateY, translateZ);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(-(float)Math.atan(pitch / 40.0F) * 20.0F, 1.0F, 0.0F, 0.0F);

    entity.renderYawOffset = ((float)Math.atan(yaw / 40.0F) * 20.0F);
    entity.rotationYaw = ((float)Math.atan(yaw / 40.0F) * 40.0F);
    entity.rotationPitch = (-(float)Math.atan(pitch / 40.0F) * 20.0F);
    entity.rotationYawHead = entity.rotationYaw;

    RenderManager.instance.renderEntityWithPosYaw(entity, 0.0D, 0.0D, 0.0D, 0.0F, getWingYaw(bee));

    GL11.glPopMatrix();

    RenderHelper.disableStandardItemLighting();
    GL11.glDisable(32826);
    OpenGlHelper.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GL11.glDisable(3553);
    OpenGlHelper.setActiveTexture(OpenGlHelper.defaultTexUnit);
    GL11.glPopAttrib();
  }

  private void renderBeeInInventory(IBee bee)
  {
    GL11.glPushAttrib(8192);
    GL11.glEnable(2896);
    GL11.glEnable(2929);
    GL11.glEnable(2903);
    RenderHelper.enableStandardItemLighting();

    GL11.glPushMatrix();

    GL11.glTranslatef(-0.3F, -2.5F, 0.0F);
    GL11.glScalef(-3.0F, 3.0F, 3.0F);
    GL11.glRotatef(32.0F, 0.0F, 1.0F, 0.0F);
    GL11.glScalef(1.6F, 1.0F, 1.0F);

    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    entity.renderYawOffset = 0.0F;
    entity.rotationYaw = 0.0F;
    entity.rotationPitch = 0.0F;
    entity.rotationYawHead = entity.rotationYaw;

    RenderManager.instance.renderEntityWithPosYaw(entity, 0.0D, 0.0D, 0.0D, 0.0F, getWingYaw(bee));

    GL11.glPopMatrix();
    RenderHelper.disableStandardItemLighting();
    GL11.glDisable(32826);
    OpenGlHelper.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GL11.glDisable(3553);
    OpenGlHelper.setActiveTexture(OpenGlHelper.defaultTexUnit);
    GL11.glPopAttrib();
  }

  public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type)
  {
    switch (1.$SwitchMap$net$minecraftforge$client$IItemRenderer$ItemRenderType[type.ordinal()]) {
    case 1:
      return true;
    case 2:
      return true;
    case 3:
      return true;
    }
    return false;
  }

  public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper)
  {
    switch (helper) {
    case ENTITY_BOBBING:
    case ENTITY_ROTATION:
      return false;
    }
    return true;
  }

  public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object[] data)
  {
    switch (1.$SwitchMap$net$minecraftforge$client$IItemRenderer$ItemRenderType[type.ordinal()]) {
    case 1:
      renderBeeItem(initBee(item, true), 0.0F, 0.0F, 0.0F);
      break;
    case 2:
      renderBeeItem(initBee(item, true), 1.0F, 0.0F, 0.5F);
      break;
    case 3:
      renderBeeInInventory(initBee(item, false));
      break;
    }
  }
}