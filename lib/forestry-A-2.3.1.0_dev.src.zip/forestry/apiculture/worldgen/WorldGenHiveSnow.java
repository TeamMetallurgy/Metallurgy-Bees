package forestry.apiculture.worldgen;

import forestry.api.core.EnumTemperature;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;

public class WorldGenHiveSnow extends WorldGenHive
{
  public boolean generate(World world, Random random, int x, int y, int z)
  {
    BiomeGenBase biome = world.getWorldChunkManager().getBiomeGenAt(x, z);
    if ((EnumTemperature.getFromValue(biome.temperature) != EnumTemperature.ICY) && (EnumTemperature.getFromValue(biome.temperature) != EnumTemperature.COLD))
    {
      return false;
    }
    if (tryPlaceGroundHive(world, x, y, z, 6, new Block[] { Block.dirt, Block.grass })) {
      world.setBlock(x, y + 1, z, Block.snow.blockID, 0, 0);
      return true;
    }

    return false;
  }
}