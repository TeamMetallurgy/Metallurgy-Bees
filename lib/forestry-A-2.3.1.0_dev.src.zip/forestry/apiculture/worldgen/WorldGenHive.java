package forestry.apiculture.worldgen;

import forestry.core.config.ForestryBlock;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.IPlantable;

public abstract class WorldGenHive extends WorldGenerator
{
  public abstract boolean generate(World paramWorld, Random paramRandom, int paramInt1, int paramInt2, int paramInt3);

  protected boolean tryPlaceTreeHive(World world, int x, int y, int z, int meta)
  {
    if (!world.isAirBlock(x, y, z)) {
      return false;
    }
    Block b = Block.blocksList[world.getBlockId(x, y + 1, z)];
    if ((b == null) || (!b.isLeaves(world, x, y + 1, z))) {
      return false;
    }
    if (world.isAirBlock(x, y - 1, z)) {
      setHive(world, x, y, z, meta);
      return true;
    }
    return false;
  }

  protected boolean tryPlaceGroundHive(World world, int x, int y, int z, int meta, Block[] groundBlocks) {
    if (!world.isAirBlock(x, y, z)) {
      Block block = Block.blocksList[world.getBlockId(x, y, z)];
      if ((block != Block.snow) && (!(block instanceof IPlantable))) {
        return false;
      }
    }
    if (!world.isAirBlock(x, y + 1, z)) {
      return false;
    }
    if (isAcceptableBlock(world, x, y - 1, z, groundBlocks)) {
      setHive(world, x, y, z, meta);
      return true;
    }

    return false;
  }

  private boolean isAcceptableBlock(World world, int x, int y, int z, Block[] blocks) {
    Block block = Block.blocksList[world.getBlockId(x, y, z)];
    if (block == null)
      return false;
    for (Block testBlock : blocks) {
      if (block.isGenMineableReplaceable(world, x, y, z, testBlock.blockID))
        return true;
    }
    return false;
  }

  protected void setHive(World world, int x, int y, int z, int meta) {
    boolean placed = world.setBlock(x, y, z, ForestryBlock.beehives.blockID, meta, 2);
    if (!placed) {
      return;
    }
    if (world.getBlockId(x, y, z) != ForestryBlock.beehives.blockID) {
      return;
    }
    ForestryBlock.beehives.onBlockAdded(world, x, y, z);
    world.markBlockForUpdate(x, y, z);

    postGen(world, x, y, z, meta);
  }

  protected void postGen(World world, int x, int y, int z, int meta) {
    ForestryBlock.beehives.onBlockPlaced(world, x, y, z, 0, 0.0F, 0.0F, 0.0F, meta);
  }
}