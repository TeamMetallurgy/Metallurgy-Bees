package forestry.apiculture.worldgen;

import forestry.api.apiculture.EnumBeeType;
import forestry.api.apiculture.FlowerManager;
import forestry.api.apiculture.IAlleleBeeSpecies;
import forestry.api.apiculture.IBee;
import forestry.api.apiculture.IBeeGenome;
import forestry.api.apiculture.IBeeRoot;
import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import forestry.api.genetics.EnumTolerance;
import forestry.apiculture.gadgets.TileBeehouse;
import forestry.core.config.ForestryBlock;
import forestry.core.config.ForestryItem;
import forestry.core.genetics.ClimateHelper;
import forestry.plugins.PluginApiculture;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.structure.ComponentVillage;
import net.minecraft.world.gen.structure.ComponentVillageStartPiece;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import net.minecraftforge.common.ChestGenHooks;

public class ComponentVillageBeeHouse extends ComponentVillage
{
  protected ItemStack[] buildingBlocks = { new ItemStack(ForestryBlock.planks1, 1, 15), new ItemStack(Block.wood, 1, 0) };
  protected int averageGroundLevel = -1;
  protected boolean isInDesert = false;
  protected boolean hasChest = false;

  public ComponentVillageBeeHouse()
  {
    buildingBlocks[0] = new ItemStack(ForestryBlock.planks1);
    buildingBlocks[1] = new ItemStack(ForestryBlock.log1);
  }

  public ComponentVillageBeeHouse(ComponentVillageStartPiece startPiece, int componentType, Random random, StructureBoundingBox boundingBox, int coordBaseMode) {
    super(startPiece, componentType);
    this.coordBaseMode = coordBaseMode;
    this.boundingBox = boundingBox;
    isInDesert = startPiece.inDesert;

    buildingBlocks[0] = new ItemStack(ForestryBlock.planks1, 1, random.nextInt(16));
    Block woodBlock;
    switch (random.nextInt(4)) {
    case 1:
      woodBlock = ForestryBlock.log2;
      break;
    case 2:
      woodBlock = ForestryBlock.log3;
      break;
    case 3:
      woodBlock = ForestryBlock.log4;
      break;
    default:
      woodBlock = ForestryBlock.log1;
    }

    buildingBlocks[1] = new ItemStack(woodBlock, 1, random.nextInt(4));
  }

  public static ComponentVillageBeeHouse buildComponent(ComponentVillageStartPiece startPiece, List par1List, Random random, int par3, int par4, int par5, int par6, int par7)
  {
    StructureBoundingBox bbox = StructureBoundingBox.getComponentToAddBoundingBox(par3, par4, par5, 0, 0, 0, 9, 9, 6, par6);
    return (canVillageGoDeeper(bbox)) && (StructureComponent.findIntersecting(par1List, bbox) == null) ? new ComponentVillageBeeHouse(startPiece, par7, random, bbox, par6) : null;
  }

  public boolean addComponentParts(World world, Random random, StructureBoundingBox structBoundingBox)
  {
    if (averageGroundLevel < 0) {
      averageGroundLevel = getAverageGroundLevel(world, structBoundingBox);
      if (averageGroundLevel < 0) {
        return true;
      }
      boundingBox.offset(0, averageGroundLevel - boundingBox.maxY + 8 - 1, 0);
    }

    fillWithBlocks(world, structBoundingBox, 1, 1, 1, 7, 4, 4, 0, 0, false);
    fillWithBlocks(world, structBoundingBox, 2, 1, 6, 8, 4, 10, 0, 0, false);

    buildGarden(world, structBoundingBox);

    fillWithBlocks(world, structBoundingBox, 1, 1, 6, 1, 1, 10, Block.fence.blockID, Block.fence.blockID, false);
    fillWithBlocks(world, structBoundingBox, 8, 1, 6, 8, 1, 10, Block.fence.blockID, Block.fence.blockID, false);
    fillWithBlocks(world, structBoundingBox, 2, 1, 10, 7, 1, 10, Block.fence.blockID, Block.fence.blockID, false);

    plantFlowerGarden(world, structBoundingBox, 2, 1, 5, 7, 1, 9);

    buildApiaries(world, structBoundingBox, 3, 1, 4, 6, 1, 8);

    fillWithBlocks(world, structBoundingBox, 1, 0, 1, 7, 0, 4, Block.planks.blockID, Block.planks.blockID, false);

    fillWithBlocks(world, structBoundingBox, 0, 0, 0, 0, 3, 5, Block.cobblestone.blockID, Block.cobblestone.blockID, false);
    fillWithBlocks(world, structBoundingBox, 8, 0, 0, 8, 3, 5, Block.cobblestone.blockID, Block.cobblestone.blockID, false);
    fillWithBlocks(world, structBoundingBox, 1, 0, 0, 7, 1, 0, Block.cobblestone.blockID, Block.cobblestone.blockID, false);
    fillWithBlocks(world, structBoundingBox, 1, 0, 5, 7, 1, 5, Block.cobblestone.blockID, Block.cobblestone.blockID, false);

    fillBoxWith(world, structBoundingBox, 1, 2, 0, 7, 3, 0, buildingBlocks[0], false);
    fillBoxWith(world, structBoundingBox, 1, 2, 5, 7, 3, 5, buildingBlocks[0], false);
    fillBoxWith(world, structBoundingBox, 0, 4, 1, 8, 4, 1, buildingBlocks[0], false);
    fillBoxWith(world, structBoundingBox, 0, 4, 4, 8, 4, 4, buildingBlocks[0], false);
    fillBoxWith(world, structBoundingBox, 0, 5, 2, 8, 5, 3, buildingBlocks[0], false);

    placeBlockAtCurrentPosition(world, buildingBlocks[0], 0, 4, 2, structBoundingBox);
    placeBlockAtCurrentPosition(world, buildingBlocks[0], 0, 4, 3, structBoundingBox);
    placeBlockAtCurrentPosition(world, buildingBlocks[0], 8, 4, 2, structBoundingBox);
    placeBlockAtCurrentPosition(world, buildingBlocks[0], 8, 4, 3, structBoundingBox);

    buildRoof(world, structBoundingBox);

    placeBlockAtCurrentPosition(world, buildingBlocks[1], 0, 2, 1, structBoundingBox);
    placeBlockAtCurrentPosition(world, buildingBlocks[1], 0, 2, 4, structBoundingBox);
    placeBlockAtCurrentPosition(world, buildingBlocks[1], 8, 2, 1, structBoundingBox);
    placeBlockAtCurrentPosition(world, buildingBlocks[1], 8, 2, 4, structBoundingBox);

    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 0, 2, 2, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 0, 2, 3, structBoundingBox);

    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 8, 2, 2, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 8, 2, 3, structBoundingBox);

    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 2, 2, 5, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 3, 2, 5, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 4, 2, 5, structBoundingBox);

    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 5, 2, 0, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.thinGlass.blockID, 0, 6, 2, 5, structBoundingBox);

    if (random.nextInt(10) < 1) {
      placeBlockAtCurrentPosition(world, new ItemStack(ForestryBlock.core, 1, 1), 1, 1, 3, structBoundingBox);
    }
    else {
      placeBlockAtCurrentPosition(world, buildingBlocks[0], 1, 1, 3, structBoundingBox);
    }

    placeBlockAtCurrentPosition(world, 0, 0, 2, 1, 0, structBoundingBox);
    placeBlockAtCurrentPosition(world, 0, 0, 2, 2, 0, structBoundingBox);
    placeDoorAtCurrentPosition(world, structBoundingBox, random, 2, 1, 0, getMetadataWithOffset(Block.doorWood.blockID, 1));

    if ((getBlockIdAtCurrentPosition(world, 2, 0, -1, structBoundingBox) == 0) && (getBlockIdAtCurrentPosition(world, 2, -1, -1, structBoundingBox) != 0))
    {
      placeBlockAtCurrentPosition(world, Block.stairsCobblestone.blockID, getMetadataWithOffset(Block.stairsCobblestone.blockID, 3), 2, 0, -1, structBoundingBox);
    }

    placeBlockAtCurrentPosition(world, 0, 0, 6, 1, 5, structBoundingBox);
    placeBlockAtCurrentPosition(world, 0, 0, 6, 2, 5, structBoundingBox);

    placeBlockAtCurrentPosition(world, Block.torchWood.blockID, 0, 2, 3, 4, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.torchWood.blockID, 0, 6, 3, 4, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.torchWood.blockID, 0, 2, 3, 1, structBoundingBox);
    placeBlockAtCurrentPosition(world, Block.torchWood.blockID, 0, 6, 3, 1, structBoundingBox);

    placeDoorAtCurrentPosition(world, structBoundingBox, random, 6, 1, 5, getMetadataWithOffset(Block.doorWood.blockID, 1));

    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 9; j++) {
        clearCurrentPositionBlocksUpwards(world, j, 7, i, structBoundingBox);
        fillCurrentPositionBlocksDownwards(world, Block.cobblestone.blockID, 0, j, -1, i, structBoundingBox);
      }
    }
    generateStructureChestContents(world, structBoundingBox, random, 7, 1, 4, ChestGenHooks.getItems("naturalistChest", random), random.nextInt(4) + random.nextInt(4) + 5);

    spawnVillagers(world, boundingBox, 7, 1, 1, 2);

    return true;
  }

  private void buildRoof(World world, StructureBoundingBox structBoundingBox) {
    int rotatedMetaDoor = getMetadataWithOffset(Block.stairsWoodOak.blockID, 3);
    int rotatedMetaGarden = getMetadataWithOffset(Block.stairsWoodOak.blockID, 2);

    for (int i = -1; i <= 2; i++)
      for (int j = 0; j <= 8; j++) {
        placeBlockAtCurrentPosition(world, Block.stairsWoodOak.blockID, rotatedMetaDoor, j, 4 + i, i, structBoundingBox);
        placeBlockAtCurrentPosition(world, Block.stairsWoodOak.blockID, rotatedMetaGarden, j, 4 + i, 5 - i, structBoundingBox);
      }
  }

  protected void buildGarden(World world, StructureBoundingBox box)
  {
    int groundId = Block.dirt.blockID;
    if (isInDesert) {
      groundId = Block.sand.blockID;
    }
    for (int i = 1; i <= 8; i++)
      for (int j = 6; j <= 10; j++)
        fillCurrentPositionBlocksDownwards(world, groundId, 0, i, 0, j, box);
  }

  protected void plantFlowerGarden(World world, StructureBoundingBox box, int minX, int minY, int minZ, int maxX, int maxY, int maxZ)
  {
    if (isInDesert) {
      placeBlockAtCurrentPosition(world, Block.cactus.blockID, 0, 4, 1, 7, box);
      return;
    }

    for (int i = minY; i <= maxY; i++)
      for (int j = minX; j <= maxX; j++)
        for (int k = minZ; k <= maxZ; k++)
          if (world.rand.nextBoolean()) {
            int xCoord = getXWithOffset(j, k);
            int yCoord = getYWithOffset(i);
            int zCoord = getZWithOffset(j, k);

            if (Block.plantRed.canBlockStay(world, xCoord, yCoord, zCoord))
            {
              ItemStack flower = (ItemStack)FlowerManager.plainFlowers.get(world.rand.nextInt(FlowerManager.plainFlowers.size()));
              placeBlockAtCurrentPosition(world, flower.itemID, flower.getItemDamage(), j, i, k, box);
            }
          }
  }

  protected void buildApiaries(World world, StructureBoundingBox box, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) { populateApiary(world, box, 3, 1, 8);
    populateApiary(world, box, 6, 1, 8); }

  private void populateApiary(World world, StructureBoundingBox box, int x, int y, int z)
  {
    int xCoord = getXWithOffset(x, z);
    int yCoord = getYWithOffset(y);
    int zCoord = getZWithOffset(x, z);

    if ((box.isVecInside(xCoord, yCoord, zCoord)) && (world.getBlockId(xCoord, yCoord, zCoord) != ForestryBlock.apiculture.blockID) && (world.blockExists(xCoord, yCoord - 1, zCoord)))
    {
      world.setBlock(xCoord, yCoord, zCoord, ForestryBlock.apiculture.blockID, 0, 2);

      ForestryBlock.apiculture.onBlockAdded(world, xCoord, yCoord, zCoord);

      TileEntity tile = world.getBlockTileEntity(xCoord, yCoord, zCoord);
      if ((tile instanceof TileBeehouse)) {
        TileBeehouse apiary = (TileBeehouse)tile;
        apiary.initialize();
        apiary.setSlotContents(0, PluginApiculture.beeInterface.getMemberStack(getVillageBee(world, xCoord, yCoord, zCoord), EnumBeeType.PRINCESS.ordinal()));

        apiary.setSlotContents(1, PluginApiculture.beeInterface.getMemberStack(getVillageBee(world, xCoord, yCoord, zCoord), EnumBeeType.DRONE.ordinal()));

        for (int i = 9; i < 12; i++) {
          float roll = world.rand.nextFloat();
          if (roll < 0.2F)
            apiary.setSlotContents(i, ForestryItem.frameUntreated.getItemStack());
          else if (roll < 0.4F)
            apiary.setSlotContents(i, ForestryItem.frameImpregnated.getItemStack());
          else if (roll < 0.6D)
            apiary.setSlotContents(i, ForestryItem.frameProven.getItemStack());
        }
      }
    }
  }

  private IBee getVillageBee(World world, int xCoord, int yCoord, int zCoord)
  {
    BiomeGenBase biome = world.getBiomeGenForCoords(xCoord, zCoord);
    ArrayList candidates;
    ArrayList candidates;
    if ((forestry.api.apiculture.BeeManager.villageBees[1] != null) && (forestry.api.apiculture.BeeManager.villageBees[1].size() > 0) && (world.rand.nextDouble() < 0.2D))
      candidates = forestry.api.apiculture.BeeManager.villageBees[1];
    else {
      candidates = forestry.api.apiculture.BeeManager.villageBees[0];
    }

    ArrayList valid = new ArrayList();
    for (IBeeGenome genome : candidates) {
      if (checkBiomeHazard(genome, biome.temperature, biome.rainfall)) {
        valid.add(genome);
      }
    }
    if (valid.isEmpty()) {
      return PluginApiculture.beeInterface.getBee(world, (IBeeGenome)forestry.api.apiculture.BeeManager.villageBees[0].get(world.rand.nextInt(forestry.api.apiculture.BeeManager.villageBees[0].size())));
    }
    return PluginApiculture.beeInterface.getBee(world, (IBeeGenome)valid.get(world.rand.nextInt(valid.size())));
  }

  private boolean checkBiomeHazard(IBeeGenome genome, float temperature, float humidity)
  {
    EnumTemperature beeTemperature = genome.getPrimary().getTemperature();
    EnumTolerance temperatureTolerance = genome.getToleranceTemp();

    ArrayList toleratedTemperatures = ClimateHelper.getToleratedTemperature(beeTemperature, temperatureTolerance);
    boolean validTemp = false;

    validTemp = toleratedTemperatures.contains(EnumTemperature.getFromValue(temperature));

    if (!validTemp) {
      return false;
    }
    EnumHumidity beeHumidity = genome.getPrimary().getHumidity();
    EnumTolerance humidityTolerance = genome.getToleranceHumid();

    ArrayList toleratedHumidity = ClimateHelper.getToleratedHumidity(beeHumidity, humidityTolerance);

    boolean validHumidity = false;

    validHumidity = toleratedHumidity.contains(EnumHumidity.getFromValue(humidity));

    return validHumidity;
  }

  protected void fillBoxWith(World world, StructureBoundingBox box, int par3, int par4, int par5, int par6, int par7, int par8, ItemStack buildingBlock, boolean replace)
  {
    for (int var14 = par4; var14 <= par7; var14++)
      for (int var15 = par3; var15 <= par6; var15++)
        for (int var16 = par5; var16 <= par8; var16++)
          if ((!replace) || (getBlockIdAtCurrentPosition(world, var15, var14, var16, box) != 0))
            placeBlockAtCurrentPosition(world, buildingBlock.itemID, buildingBlock.getItemDamage(), var15, var14, var16, box);
  }

  protected void placeBlockAtCurrentPosition(World world, ItemStack buildingBlock, int par4, int par5, int par6, StructureBoundingBox par7StructureBoundingBox) {
    int var8 = getXWithOffset(par4, par6);
    int var9 = getYWithOffset(par5);
    int var10 = getZWithOffset(par4, par6);

    if (par7StructureBoundingBox.isVecInside(var8, var9, var10))
      world.setBlock(var8, var9, var10, buildingBlock.itemID, buildingBlock.getItemDamage(), 2);
  }

  protected int getVillagerType(int villagerCount)
  {
    if (villagerCount <= 0) {
      return 80;
    }
    return 81;
  }
}