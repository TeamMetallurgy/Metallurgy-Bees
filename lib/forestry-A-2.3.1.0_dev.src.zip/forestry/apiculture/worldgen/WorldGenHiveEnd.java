package forestry.apiculture.worldgen;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;

public class WorldGenHiveEnd extends WorldGenHive
{
  public boolean generate(World world, Random random, int x, int y, int z)
  {
    BiomeGenBase biome = world.getWorldChunkManager().getBiomeGenAt(x, z);
    if (biome.biomeID != BiomeGenBase.sky.biomeID) {
      return false;
    }
    return tryPlaceGroundHive(world, x, y, z, 5, new Block[] { Block.whiteStone });
  }
}