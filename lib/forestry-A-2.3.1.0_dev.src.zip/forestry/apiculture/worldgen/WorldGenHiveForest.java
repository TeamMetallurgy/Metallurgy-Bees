package forestry.apiculture.worldgen;

import forestry.api.core.EnumHumidity;
import forestry.api.core.EnumTemperature;
import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;

public class WorldGenHiveForest extends WorldGenHive
{
  public boolean generate(World world, Random random, int x, int y, int z)
  {
    BiomeGenBase biome = world.getWorldChunkManager().getBiomeGenAt(x, z);
    if ((EnumTemperature.getFromValue(biome.temperature) != EnumTemperature.NORMAL) || (EnumHumidity.getFromValue(biome.rainfall) != EnumHumidity.NORMAL))
    {
      return false;
    }
    return tryPlaceTreeHive(world, x, y, z, 1);
  }
}