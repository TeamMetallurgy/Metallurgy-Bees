package forestry.apiculture.worldgen;

import forestry.apiculture.gadgets.TileSwarm;
import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class WorldGenHiveSwamer extends WorldGenHive
{
  private ItemStack[] bees;

  public WorldGenHiveSwamer(ItemStack[] bees)
  {
    this.bees = bees;
  }

  public boolean generate(World world, Random random, int x, int y, int z)
  {
    if ((world.blockExists(x, y, z)) && (world.isAirBlock(x, y, z)) && ((!world.isAirBlock(x, y - 1, z)) || (!world.isAirBlock(x, y + 1, z)))) {
      setHive(world, x, y, z, 8);
      return true;
    }

    return false;
  }

  protected void postGen(World world, int x, int y, int z, int meta)
  {
    TileEntity tile = world.getBlockTileEntity(x, y, z);
    if ((tile instanceof TileSwarm))
      ((TileSwarm)tile).setContained(bees);
  }
}