package forestry.apiculture;

import forestry.api.genetics.IFlowerProvider;
import forestry.api.genetics.IIndividual;
import forestry.api.genetics.IPollinatable;
import forestry.core.utils.StringUtil;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockMycelium;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.EnumPlantType;

public class FlowerProviderMushroom
  implements IFlowerProvider
{
  public boolean isAcceptedFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);

    if (blockid == Block.flowerPot.blockID) {
      return checkFlowerPot(world.getBlockMetadata(x, y, z));
    }
    return (blockid == Block.mushroomBrown.blockID) || (blockid == Block.mushroomRed.blockID);
  }

  public boolean isAcceptedPollinatable(World world, IPollinatable pollinatable)
  {
    EnumSet types = pollinatable.getPlantType();
    return (types.size() > 1) || (!types.contains(EnumPlantType.Nether));
  }

  private boolean checkFlowerPot(int meta) {
    if ((meta == 7) || (meta == 8)) {
      return true;
    }
    return false;
  }

  public boolean growFlower(World world, IIndividual individual, int x, int y, int z)
  {
    int blockid = world.getBlockId(x, y, z);

    if (blockid != 0) {
      if (blockid == Block.flowerPot.blockID) {
        return growInPot(world, x, y, z);
      }
      return false;
    }

    int groundid = world.getBlockId(x, y - 1, z);

    if (groundid != Block.mycelium.blockID)
      return false;
    int mushroomId;
    int mushroomId;
    if (world.rand.nextBoolean())
      mushroomId = Block.mushroomBrown.blockID;
    else {
      mushroomId = Block.mushroomRed.blockID;
    }
    world.setBlock(x, y, z, mushroomId, 0, 2);
    return true;
  }

  private boolean growInPot(World world, int x, int y, int z) {
    if (world.rand.nextBoolean())
      world.setBlock(x, y, z, Block.flowerPot.blockID, 7, 2);
    else
      world.setBlock(x, y, z, Block.flowerPot.blockID, 8, 2);
    return true;
  }

  public String getDescription()
  {
    return StringUtil.localize("flowers.mushroom");
  }

  public ItemStack[] affectProducts(World world, IIndividual individual, int x, int y, int z, ItemStack[] products)
  {
    return products;
  }

  public ItemStack[] getItemStacks()
  {
    return new ItemStack[] { new ItemStack(Block.mushroomBrown), new ItemStack(Block.mushroomRed) };
  }
}