package buildcraft.api.transport;

import net.minecraft.item.ItemStack;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.fluids.IFluidHandler;

public abstract interface IPipeTile extends ISolidSideTile, IFluidHandler
{
  @Deprecated
  public abstract IPipe getPipe();

  public abstract PipeType getPipeType();

  public abstract int injectItem(ItemStack paramItemStack, boolean paramBoolean, ForgeDirection paramForgeDirection);

  public abstract boolean isPipeConnected(ForgeDirection paramForgeDirection);

  public static enum PipeType
  {
    ITEM, FLUID, POWER, STRUCTURE;
  }
}