package buildcraft.api.transport;

import net.minecraft.world.World;

public abstract interface IExtractionHandler
{
  public abstract boolean canExtractItems(Object paramObject, World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract boolean canExtractFluids(Object paramObject, World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}