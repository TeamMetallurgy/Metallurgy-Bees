package buildcraft.api.transport;

import net.minecraftforge.common.ForgeDirection;

public abstract interface ISolidSideTile
{
  public abstract boolean isSolidOnSide(ForgeDirection paramForgeDirection);
}