package buildcraft.api.transport;

import net.minecraft.tileentity.TileEntity;

public abstract interface IPipe
{
  public abstract boolean isWired(WireColor paramWireColor);

  public abstract boolean hasGate();

  public abstract TileEntity getContainer();

  public abstract boolean isWireConnectedTo(TileEntity paramTileEntity, WireColor paramWireColor);

  public static enum WireColor
  {
    Red, Blue, Green, Yellow;

    public WireColor reverse() {
      switch (IPipe.1.$SwitchMap$buildcraft$api$transport$IPipe$WireColor[ordinal()]) {
      case 1:
        return Yellow;
      case 2:
        return Green;
      case 3:
        return Blue;
      }
      return Red;
    }
  }

  public static enum DrawingState
  {
    DrawingPipe, DrawingRedWire, DrawingBlueWire, DrawingGreenWire, DrawingYellowWire, DrawingGate;
  }
}