package buildcraft.api.transport;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.World;

public abstract class PipeManager
{
  public static List<IExtractionHandler> extractionHandlers = new ArrayList();

  public static void registerExtractionHandler(IExtractionHandler handler) {
    extractionHandlers.add(handler);
  }

  public static boolean canExtractItems(Object extractor, World world, int i, int j, int k)
  {
    for (IExtractionHandler handler : extractionHandlers) {
      if (!handler.canExtractItems(extractor, world, i, j, k))
        return false;
    }
    return true;
  }

  public static boolean canExtractFluids(Object extractor, World world, int i, int j, int k)
  {
    for (IExtractionHandler handler : extractionHandlers) {
      if (!handler.canExtractFluids(extractor, world, i, j, k))
        return false;
    }
    return true;
  }
}