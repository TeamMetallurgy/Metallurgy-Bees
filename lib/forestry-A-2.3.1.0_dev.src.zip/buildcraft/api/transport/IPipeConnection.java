package buildcraft.api.transport;

import net.minecraftforge.common.ForgeDirection;

public abstract interface IPipeConnection
{
  public abstract ConnectOverride overridePipeConnection(IPipeTile.PipeType paramPipeType, ForgeDirection paramForgeDirection);

  public static enum ConnectOverride
  {
    CONNECT, DISCONNECT, DEFAULT;
  }
}