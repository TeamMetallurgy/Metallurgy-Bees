package buildcraft.api.recipes;

import java.util.LinkedList;
import net.minecraft.item.ItemStack;

public class AssemblyRecipe
{
  public static LinkedList<AssemblyRecipe> assemblyRecipes = new LinkedList();
  public final ItemStack[] input;
  public final ItemStack output;
  public final float energy;

  public AssemblyRecipe(ItemStack[] input, int energy, ItemStack output)
  {
    this.input = input;
    this.output = output;
    this.energy = energy;
  }

  public boolean canBeDone(ItemStack[] items)
  {
    for (ItemStack in : input)
    {
      if (in != null)
      {
        int found = 0;

        for (ItemStack item : items) {
          if (item != null)
          {
            if (item.isItemEqual(in)) {
              found += item.stackSize;
            }
          }
        }

        if (found < in.stackSize) {
          return false;
        }
      }
    }
    return true;
  }
}