package buildcraft.api.core;

import net.minecraft.world.World;

public class SafeTimeTracker
{
  private long lastMark = -9223372036854775808L;
  private long duration = -1L;

  public boolean markTimeIfDelay(World world, long delay)
  {
    if (world == null) {
      return false;
    }
    long currentTime = world.getTotalWorldTime();

    if (currentTime < lastMark) {
      lastMark = currentTime;
      return false;
    }if (lastMark + delay <= currentTime) {
      duration = (currentTime - lastMark);
      lastMark = currentTime;
      return true;
    }
    return false;
  }

  public long durationOfLastDelay()
  {
    return duration > 0L ? duration : 0L;
  }

  public void markTime(World world) {
    lastMark = world.getTotalWorldTime();
  }
}