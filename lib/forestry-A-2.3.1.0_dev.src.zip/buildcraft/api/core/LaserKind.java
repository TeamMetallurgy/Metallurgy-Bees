package buildcraft.api.core;

public enum LaserKind
{
  Red, Blue, Stripes;
}