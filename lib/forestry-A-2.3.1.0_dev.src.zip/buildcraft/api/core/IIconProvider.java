package buildcraft.api.core;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.Icon;

public abstract interface IIconProvider
{
  @SideOnly(Side.CLIENT)
  public abstract Icon getIcon(int paramInt);

  @SideOnly(Side.CLIENT)
  public abstract void registerIcons(IconRegister paramIconRegister);
}