package buildcraft.api.core;

import net.minecraft.world.World;

public abstract interface IBox
{
  public abstract void expand(int paramInt);

  public abstract void contract(int paramInt);

  public abstract boolean contains(int paramInt1, int paramInt2, int paramInt3);

  public abstract Position pMin();

  public abstract Position pMax();

  public abstract void createLasers(World paramWorld, LaserKind paramLaserKind);

  public abstract void deleteLasers();
}