package buildcraft.api.core;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class StackWrapper
{
  public final ItemStack stack;

  public StackWrapper(ItemStack stack)
  {
    this.stack = stack;
  }

  public int hashCode()
  {
    int hash = 5;
    hash = 67 * hash + stack.itemID;
    hash = 67 * hash + stack.getItemDamage();
    if (stack.stackTagCompound != null)
      hash = 67 * hash + stack.stackTagCompound.hashCode();
    return hash;
  }

  public boolean equals(Object obj)
  {
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    StackWrapper other = (StackWrapper)obj;
    if (stack.itemID != other.stack.itemID)
      return false;
    if ((stack.getHasSubtypes()) && (stack.getItemDamage() != other.stack.getItemDamage()))
      return false;
    if ((stack.stackTagCompound != null) && (!stack.stackTagCompound.equals(other.stack.stackTagCompound)))
      return false;
    return true;
  }
}