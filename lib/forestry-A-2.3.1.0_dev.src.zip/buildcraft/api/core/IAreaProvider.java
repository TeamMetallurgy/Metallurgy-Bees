package buildcraft.api.core;

public abstract interface IAreaProvider
{
  public abstract int xMin();

  public abstract int yMin();

  public abstract int zMin();

  public abstract int xMax();

  public abstract int yMax();

  public abstract int zMax();

  public abstract void removeFromWorld();
}