package buildcraft.api.blueprints;

import java.util.LinkedList;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

@Deprecated
public class BptSlotInfo
{
  public int blockId = 0;
  public int meta = 0;
  public int x;
  public int y;
  public int z;
  public LinkedList<ItemStack> storedRequirements = new LinkedList();

  public NBTTagCompound cpt = new NBTTagCompound();

  public BptSlotInfo clone()
  {
    BptSlotInfo obj = new BptSlotInfo();

    obj.x = x;
    obj.y = y;
    obj.z = z;
    obj.blockId = blockId;
    obj.meta = meta;
    obj.cpt = ((NBTTagCompound)cpt.copy());

    return obj;
  }
}