package buildcraft.api.blueprints;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Deprecated
public class BlueprintManager
{
  public static BptBlock[] blockBptProps = new BptBlock[Block.blocksList.length];

  public static ItemSignature getItemSignature(Item item) {
    ItemSignature sig = new ItemSignature();

    if (itemID >= Block.blocksList.length + 126) {
      sig.itemClassName = item.getClass().getSimpleName();
    }

    sig.itemName = item.getUnlocalizedName(new ItemStack(item));

    return sig;
  }

  public static BlockSignature getBlockSignature(Block block) {
    return blockBptProps[0].getSignature(block);
  }

  static
  {
    for (int i = 0; i < blockBptProps.length; i++)
      new BptBlock(i);
  }
}