package buildcraft.api.blueprints;

import java.util.ArrayList;
import java.util.LinkedList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

@Deprecated
public class BptBlock
{
  public final int blockId;

  public BptBlock(int blockId)
  {
    this.blockId = blockId;

    BlueprintManager.blockBptProps[blockId] = this;
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    if (slot.blockId != 0)
      if (slot.storedRequirements.size() != 0)
        requirements.addAll(slot.storedRequirements);
      else
        requirements.add(new ItemStack(slot.blockId, 1, slot.meta));
  }

  public ItemStack useItem(BptSlotInfo slot, IBptContext context, ItemStack req, ItemStack stack)
  {
    ItemStack result = stack.copy();
    if (stack.isItemStackDamageable()) {
      if (req.getItemDamage() + stack.getItemDamage() <= stack.getMaxDamage()) {
        stack.setItemDamage(req.getItemDamage() + stack.getItemDamage());
        result.setItemDamage(req.getItemDamage());
        req.stackSize = 0;
      }

      if (stack.getItemDamage() >= stack.getMaxDamage()) {
        stack.stackSize = 0;
      }
    }
    else if (stack.stackSize >= req.stackSize) {
      result.stackSize = req.stackSize;
      stack.stackSize -= req.stackSize;
      req.stackSize = 0;
    } else {
      req.stackSize -= stack.stackSize;
      stack.stackSize = 0;
    }

    if ((stack.stackSize == 0) && (stack.getItem().getContainerItem() != null)) {
      Item container = stack.getItem().getContainerItem();

      stack.itemID = container.itemID;
      stack.stackSize = 1;
      stack.setItemDamage(0);
    }
    return result;
  }

  public boolean isValid(BptSlotInfo slot, IBptContext context)
  {
    return (slot.blockId == context.world().getBlockId(slot.x, slot.y, slot.z)) && (slot.meta == context.world().getBlockMetadata(slot.x, slot.y, slot.z));
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
  }

  public void buildBlock(BptSlotInfo slot, IBptContext context)
  {
    context.world().setBlock(slot.x, slot.y, slot.z, slot.blockId, slot.meta, 3);
    context.world().setBlockMetadataWithNotify(slot.x, slot.y, slot.z, slot.meta, 3);

    if ((Block.blocksList[slot.blockId] instanceof BlockContainer)) {
      TileEntity tile = context.world().getBlockTileEntity(slot.x, slot.y, slot.z);

      slot.cpt.setInteger("x", slot.x);
      slot.cpt.setInteger("y", slot.y);
      slot.cpt.setInteger("z", slot.z);

      if (tile != null)
        tile.readFromNBT(slot.cpt);
    }
  }

  public boolean ignoreBuilding(BptSlotInfo slot)
  {
    return false;
  }

  public void initializeFromWorld(BptSlotInfo slot, IBptContext context, int x, int y, int z)
  {
    if ((Block.blocksList[slot.blockId] instanceof BlockContainer)) {
      TileEntity tile = context.world().getBlockTileEntity(x, y, z);

      if (tile != null) {
        tile.writeToNBT(slot.cpt);
      }
    }

    if (Block.blocksList[slot.blockId] != null) {
      ArrayList req = Block.blocksList[slot.blockId].getBlockDropped(context.world(), x, y, z, context.world().getBlockMetadata(x, y, z), 0);

      if (req != null)
        slot.storedRequirements.addAll(req);
    }
  }

  public void postProcessing(BptSlotInfo slot, IBptContext context)
  {
  }

  public BlockSignature getSignature(Block block)
  {
    BlockSignature sig = new BlockSignature();

    if (block.blockID > 122) {
      sig.blockClassName = block.getClass().getSimpleName();

      if ((block instanceof BlockContainer))
      {
        TileEntity tile = ((BlockContainer)block).createNewTileEntity(null);

        if (tile != null) {
          sig.tileClassName = tile.getClass().getSimpleName();
        }
      }
    }

    sig.blockName = block.getUnlocalizedName();
    sig.replaceNullWithStar();

    return sig;
  }

  public boolean match(Block block, BlockSignature sig)
  {
    if (block == null) {
      return false;
    }
    BlockSignature inst = BlueprintManager.getBlockSignature(block);

    return (starMatch(sig.blockName, inst.blockName)) && (starMatch(sig.blockClassName, inst.blockClassName)) && (starMatch(sig.tileClassName, inst.tileClassName)) && (starMatch(sig.customField, inst.customField)) && (starMatch(sig.mod, inst.mod));
  }

  private boolean starMatch(String s1, String s2)
  {
    return (s1.equals("*")) || (s2.equals("*")) || (s1.equals(s2));
  }
}