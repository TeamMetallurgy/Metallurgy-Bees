package buildcraft.api.blueprints;

@Deprecated
public class ItemSignature
{
  public String itemClassName;
  public String itemName;

  public ItemSignature(String str)
  {
    String[] values = str.split("/");

    itemClassName = values[1];
    itemName = values[2];

    replaceNullWithStar();
  }

  public ItemSignature()
  {
    replaceNullWithStar();
  }

  public String toString()
  {
    replaceNullWithStar();

    return "#I/" + itemClassName + "/" + itemName;
  }

  public void replaceNullWithStar() {
    if (itemClassName == null) {
      itemClassName = "*";
    }

    if (itemName == null)
      itemName = "*";
  }
}