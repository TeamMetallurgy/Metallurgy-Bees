package buildcraft.api.blueprints;

import buildcraft.api.core.IBox;
import buildcraft.api.core.Position;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

@Deprecated
public abstract interface IBptContext
{
  public abstract ItemStack mapItemStack(ItemStack paramItemStack);

  public abstract int mapWorldId(int paramInt);

  public abstract void storeId(int paramInt);

  public abstract Position rotatePositionLeft(Position paramPosition);

  public abstract IBox surroundingBox();

  public abstract World world();
}