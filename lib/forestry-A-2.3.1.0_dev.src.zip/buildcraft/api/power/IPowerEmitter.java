package buildcraft.api.power;

import net.minecraftforge.common.ForgeDirection;

public abstract interface IPowerEmitter
{
  public abstract boolean canEmitPowerFrom(ForgeDirection paramForgeDirection);
}