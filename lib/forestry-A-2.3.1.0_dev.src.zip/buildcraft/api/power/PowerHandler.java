package buildcraft.api.power;

import buildcraft.api.core.SafeTimeTracker;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.ForgeDirection;

public final class PowerHandler
{
  public static final PerditionCalculator DEFAULT_PERDITION = new PerditionCalculator();
  private float minEnergyReceived;
  private float maxEnergyReceived;
  private float maxEnergyStored;
  private float activationEnergy;
  private float energyStored = 0.0F;
  private final SafeTimeTracker doWorkTracker = new SafeTimeTracker();
  private final SafeTimeTracker sourcesTracker = new SafeTimeTracker();
  private final SafeTimeTracker perditionTracker = new SafeTimeTracker();
  public final int[] powerSources = new int[6];
  public final IPowerReceptor receptor;
  private PerditionCalculator perdition;
  private final PowerReceiver receiver;
  private final Type type;

  public PowerHandler(IPowerReceptor receptor, Type type)
  {
    this.receptor = receptor;
    this.type = type;
    receiver = new PowerReceiver(null);
    perdition = DEFAULT_PERDITION;
  }

  public PowerReceiver getPowerReceiver() {
    return receiver;
  }

  public float getMinEnergyReceived() {
    return minEnergyReceived;
  }

  public float getMaxEnergyReceived() {
    return maxEnergyReceived;
  }

  public float getMaxEnergyStored() {
    return maxEnergyStored;
  }

  public float getActivationEnergy() {
    return activationEnergy;
  }

  public float getEnergyStored() {
    return energyStored;
  }

  public void configure(float minEnergyReceived, float maxEnergyReceived, float activationEnergy, float maxStoredEnergy)
  {
    if (minEnergyReceived > maxEnergyReceived) {
      maxEnergyReceived = minEnergyReceived;
    }
    this.minEnergyReceived = minEnergyReceived;
    this.maxEnergyReceived = maxEnergyReceived;
    maxEnergyStored = maxStoredEnergy;
    this.activationEnergy = activationEnergy;
  }

  public void configurePowerPerdition(int powerLoss, int powerLossRegularity)
  {
    if ((powerLoss == 0) || (powerLossRegularity == 0)) {
      perdition = new PerditionCalculator(0.0F);
      return;
    }
    perdition = new PerditionCalculator(powerLoss / powerLossRegularity);
  }

  public void setPerdition(PerditionCalculator perdition)
  {
    if (perdition == null)
      perdition = DEFAULT_PERDITION;
    this.perdition = perdition;
  }

  public PerditionCalculator getPerdition() {
    if (perdition == null)
      return DEFAULT_PERDITION;
    return perdition;
  }

  public void update()
  {
    applyPerdition();
    applyWork();
    validateEnergy();
  }

  private void applyPerdition() {
    if ((perditionTracker.markTimeIfDelay(receptor.getWorld(), 1L)) && (energyStored > 0.0F)) {
      float newEnergy = getPerdition().applyPerdition(this, energyStored, perditionTracker.durationOfLastDelay());
      if ((newEnergy == 0.0F) || (newEnergy < energyStored))
        energyStored = newEnergy;
      else
        energyStored = DEFAULT_PERDITION.applyPerdition(this, energyStored, perditionTracker.durationOfLastDelay());
      validateEnergy();
    }
  }

  private void applyWork() {
    if ((energyStored >= activationEnergy) && 
      (doWorkTracker.markTimeIfDelay(receptor.getWorld(), 1L)))
      receptor.doWork(this);
  }

  private void updateSources(ForgeDirection source)
  {
    if (sourcesTracker.markTimeIfDelay(receptor.getWorld(), 1L)) {
      for (int i = 0; i < 6; i++)
      {
        int tmp33_32 = i;
        int[] tmp33_29 = powerSources; tmp33_29[tmp33_32] = ((int)(tmp33_29[tmp33_32] - sourcesTracker.durationOfLastDelay()));
        if (powerSources[i] < 0) {
          powerSources[i] = 0;
        }
      }
    }

    if (source != null)
      powerSources[source.ordinal()] = 10;
  }

  public float useEnergy(float min, float max, boolean doUse)
  {
    applyPerdition();

    float result = 0.0F;

    if (energyStored >= min) {
      if (energyStored <= max) {
        result = energyStored;
        if (doUse)
          energyStored = 0.0F;
      }
      else {
        result = max;
        if (doUse) {
          energyStored -= max;
        }
      }
    }

    validateEnergy();

    return result;
  }

  public void readFromNBT(NBTTagCompound data) {
    readFromNBT(data, "powerProvider");
  }

  public void readFromNBT(NBTTagCompound data, String tag) {
    NBTTagCompound nbt = data.getCompoundTag(tag);
    energyStored = nbt.getFloat("storedEnergy");
  }

  public void writeToNBT(NBTTagCompound data) {
    writeToNBT(data, "powerProvider");
  }

  public void writeToNBT(NBTTagCompound data, String tag) {
    NBTTagCompound nbt = new NBTTagCompound();
    nbt.setFloat("storedEnergy", energyStored);
    data.setCompoundTag(tag, nbt);
  }

  public float addEnergy(float quantity)
  {
    energyStored += quantity;

    if (energyStored > maxEnergyStored) {
      quantity -= energyStored - maxEnergyStored;
      energyStored = maxEnergyStored;
    } else if (energyStored < 0.0F) {
      quantity -= energyStored;
      energyStored = 0.0F;
    }

    applyPerdition();

    return quantity;
  }

  public void setEnergy(float quantity) {
    energyStored = quantity;
    validateEnergy();
  }

  public boolean isPowerSource(ForgeDirection from) {
    return powerSources[from.ordinal()] != 0;
  }

  private void validateEnergy() {
    if (energyStored < 0.0F) {
      energyStored = 0.0F;
    }
    if (energyStored > maxEnergyStored)
      energyStored = maxEnergyStored;
  }

  public final class PowerReceiver
  {
    private PowerReceiver()
    {
    }

    public float getMinEnergyReceived()
    {
      return minEnergyReceived;
    }

    public float getMaxEnergyReceived() {
      return maxEnergyReceived;
    }

    public float getMaxEnergyStored() {
      return maxEnergyStored;
    }

    public float getActivationEnergy() {
      return activationEnergy;
    }

    public float getEnergyStored() {
      return energyStored;
    }

    public PowerHandler.Type getType() {
      return type;
    }

    public void update() {
      PowerHandler.this.update();
    }

    public float powerRequest()
    {
      update();
      return Math.min(maxEnergyReceived, maxEnergyStored - energyStored);
    }

    public float receiveEnergy(PowerHandler.Type source, float quantity, ForgeDirection from)
    {
      float used = quantity;
      if (source == PowerHandler.Type.ENGINE) {
        if (used < minEnergyReceived)
          return 0.0F;
        if (used > maxEnergyReceived) {
          used = maxEnergyReceived;
        }
      }

      PowerHandler.this.updateSources(from);

      used -= used * getPerdition().getTaxPercent();

      used = addEnergy(used);

      PowerHandler.this.applyWork();

      if ((source == PowerHandler.Type.ENGINE) && (type.eatsEngineExcess())) {
        used = Math.min(quantity, maxEnergyReceived);
      }

      return used;
    }
  }

  public static class PerditionCalculator
  {
    public static final float DEFAULT_POWERLOSS = 1.0F;
    public static final float MIN_POWERLOSS = 0.01F;
    private final float powerLoss;

    public PerditionCalculator()
    {
      powerLoss = 1.0F;
    }

    public PerditionCalculator(float powerLoss)
    {
      if (powerLoss < 0.01F) {
        powerLoss = 0.01F;
      }
      this.powerLoss = powerLoss;
    }

    public float applyPerdition(PowerHandler powerHandler, float current, long ticksPassed)
    {
      current -= powerLoss * (float)ticksPassed;
      if (current < 0.0F) {
        current = 0.0F;
      }

      return current;
    }

    public float getTaxPercent()
    {
      return 0.0F;
    }
  }

  public static enum Type
  {
    ENGINE, GATE, MACHINE, PIPE, STORAGE;

    public boolean canReceiveFromPipes() {
      switch (PowerHandler.1.$SwitchMap$buildcraft$api$power$PowerHandler$Type[ordinal()]) {
      case 1:
      case 2:
        return true;
      }
      return false;
    }

    public boolean eatsEngineExcess()
    {
      switch (PowerHandler.1.$SwitchMap$buildcraft$api$power$PowerHandler$Type[ordinal()]) {
      case 1:
      case 2:
        return true;
      }
      return false;
    }
  }
}