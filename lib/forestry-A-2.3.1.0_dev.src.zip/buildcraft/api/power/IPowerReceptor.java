package buildcraft.api.power;

import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public abstract interface IPowerReceptor
{
  public abstract PowerHandler.PowerReceiver getPowerReceiver(ForgeDirection paramForgeDirection);

  public abstract void doWork(PowerHandler paramPowerHandler);

  public abstract World getWorld();
}