package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockDelegate extends BptBlock
{
  final int delegateTo;

  public BptBlockDelegate(int blockId, int delegateTo)
  {
    super(blockId);

    this.delegateTo = delegateTo;
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    BptSlotInfo newSlot = slot.clone();
    slot.blockId = delegateTo;

    if (buildcraft.api.blueprints.BlueprintManager.blockBptProps[delegateTo] != null)
      buildcraft.api.blueprints.BlueprintManager.blockBptProps[delegateTo].addRequirements(newSlot, context, requirements);
    else
      super.addRequirements(newSlot, context, requirements);
  }

  public boolean isValid(BptSlotInfo slot, IBptContext context)
  {
    BptSlotInfo newSlot = slot.clone();
    slot.blockId = delegateTo;

    if (buildcraft.api.blueprints.BlueprintManager.blockBptProps[delegateTo] != null) {
      return buildcraft.api.blueprints.BlueprintManager.blockBptProps[delegateTo].isValid(newSlot, context);
    }
    return super.isValid(newSlot, context);
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    BptSlotInfo newSlot = slot.clone();
    slot.blockId = delegateTo;

    if (buildcraft.api.blueprints.BlueprintManager.blockBptProps[delegateTo] != null)
      buildcraft.api.blueprints.BlueprintManager.blockBptProps[delegateTo].rotateLeft(newSlot, context);
    else
      super.rotateLeft(newSlot, context);
  }
}