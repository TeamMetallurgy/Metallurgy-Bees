package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockIgnore extends BptBlock
{
  public BptBlockIgnore(int blockId)
  {
    super(blockId);
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    requirements.add(new ItemStack(slot.blockId, 0, 0));
  }

  public boolean isValid(BptSlotInfo slot, IBptContext context)
  {
    return true;
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
  }

  public boolean ignoreBuilding(BptSlotInfo slot)
  {
    return true;
  }
}