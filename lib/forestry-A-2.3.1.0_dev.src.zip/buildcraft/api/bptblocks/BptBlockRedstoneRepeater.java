package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockRedstoneRepeater extends BptBlock
{
  public BptBlockRedstoneRepeater(int blockId)
  {
    super(blockId);
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    requirements.add(new ItemStack(Item.redstoneRepeater));
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    int step = slot.meta - (slot.meta & 0x3);

    switch (slot.meta - step) {
    case 0:
      slot.meta = (1 + step);
      break;
    case 1:
      slot.meta = (2 + step);
      break;
    case 2:
      slot.meta = (3 + step);
      break;
    case 3:
      slot.meta = (0 + step);
    }
  }
}