package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import net.minecraft.world.World;

@Deprecated
public class BptBlockPiston extends BptBlockRotateMeta
{
  public BptBlockPiston(int blockId)
  {
    super(blockId, new int[] { 2, 5, 3, 4 }, true);
  }

  public void buildBlock(BptSlotInfo slot, IBptContext context)
  {
    int meta = slot.meta & 0x7;

    context.world().setBlock(slot.x, slot.y, slot.z, slot.blockId, meta, 1);
  }
}