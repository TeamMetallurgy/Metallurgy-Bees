package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockLever extends BptBlockWallSide
{
  public BptBlockLever(int blockId)
  {
    super(blockId);
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    requirements.add(new ItemStack(slot.blockId, 1, 0));
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    int status = slot.meta - (slot.meta & 0x7);

    slot.meta -= status;
    super.rotateLeft(slot, context);
    slot.meta += status;
  }
}