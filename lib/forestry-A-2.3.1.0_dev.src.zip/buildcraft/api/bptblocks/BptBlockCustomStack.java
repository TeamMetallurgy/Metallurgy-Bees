package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockCustomStack extends BptBlock
{
  final ItemStack customStack;

  public BptBlockCustomStack(int blockId, ItemStack customStack)
  {
    super(blockId);

    this.customStack = customStack;
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    requirements.add(customStack.copy());
  }
}