package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

@Deprecated
public class BptBlockBed extends BptBlock
{
  public BptBlockBed(int blockId)
  {
    super(blockId);
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    if ((slot.meta & 0x8) == 0)
      requirements.add(new ItemStack(Item.bed));
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    int orientation = slot.meta & 0x7;
    int others = slot.meta - orientation;

    switch (orientation) {
    case 0:
      slot.meta = (1 + others);
      break;
    case 1:
      slot.meta = (2 + others);
      break;
    case 2:
      slot.meta = (3 + others);
      break;
    case 3:
      slot.meta = (0 + others);
    }
  }

  public void buildBlock(BptSlotInfo slot, IBptContext context)
  {
    if ((slot.meta & 0x8) != 0) {
      return;
    }
    context.world().setBlock(slot.x, slot.y, slot.z, slot.blockId, slot.meta, 1);

    int x2 = slot.x;
    int z2 = slot.z;

    switch (slot.meta) {
    case 0:
      z2++;
      break;
    case 1:
      x2--;
      break;
    case 2:
      z2--;
      break;
    case 3:
      x2++;
    }

    context.world().setBlock(x2, slot.y, z2, slot.blockId, slot.meta + 8, 1);
  }

  public boolean ignoreBuilding(BptSlotInfo slot)
  {
    return (slot.meta & 0x8) != 0;
  }
}