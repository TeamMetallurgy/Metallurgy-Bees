package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockWallSide extends BptBlock
{
  public BptBlockWallSide(int blockId)
  {
    super(blockId);
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    requirements.add(new ItemStack(slot.blockId, 1, 0));
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    int XPos = 2;
    int XNeg = 1;
    int ZPos = 4;
    int ZNeg = 3;

    switch (slot.meta) {
    case 2:
      slot.meta = 4;
      break;
    case 3:
      slot.meta = 2;
      break;
    case 1:
      slot.meta = 3;
      break;
    case 4:
      slot.meta = 1;
    }
  }
}