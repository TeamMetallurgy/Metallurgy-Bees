package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

@Deprecated
public class BptBlockDoor extends BptBlock
{
  final ItemStack stack;

  public BptBlockDoor(int blockId, ItemStack stack)
  {
    super(blockId);

    this.stack = stack;
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    if ((slot.meta & 0x8) == 0)
      requirements.add(stack.copy());
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    int orientation = slot.meta & 0x3;
    int others = slot.meta - orientation;

    switch (orientation) {
    case 0:
      slot.meta = (1 + others);
      break;
    case 1:
      slot.meta = (2 + others);
      break;
    case 2:
      slot.meta = (3 + others);
      break;
    case 3:
      slot.meta = (0 + others);
    }
  }

  public boolean ignoreBuilding(BptSlotInfo slot)
  {
    return (slot.meta & 0x8) != 0;
  }

  public void buildBlock(BptSlotInfo slot, IBptContext context)
  {
    context.world().setBlock(slot.x, slot.y, slot.z, slot.blockId, slot.meta, 1);
    context.world().setBlock(slot.x, slot.y + 1, slot.z, slot.blockId, slot.meta + 8, 1);

    context.world().setBlockMetadataWithNotify(slot.x, slot.y + 1, slot.z, slot.meta + 8, 1);
    context.world().setBlockMetadataWithNotify(slot.x, slot.y, slot.z, slot.meta, 1);
  }
}