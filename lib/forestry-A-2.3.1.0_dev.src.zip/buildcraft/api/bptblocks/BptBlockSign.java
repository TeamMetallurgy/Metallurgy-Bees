package buildcraft.api.bptblocks;

import buildcraft.api.blueprints.BlockSignature;
import buildcraft.api.blueprints.BptBlock;
import buildcraft.api.blueprints.BptSlotInfo;
import buildcraft.api.blueprints.IBptContext;
import java.util.LinkedList;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Deprecated
public class BptBlockSign extends BptBlock
{
  boolean isWall;

  public BptBlockSign(int blockId, boolean isWall)
  {
    super(blockId);

    this.isWall = isWall;
  }

  public void addRequirements(BptSlotInfo slot, IBptContext context, LinkedList<ItemStack> requirements)
  {
    requirements.add(new ItemStack(Item.sign));
  }

  public void rotateLeft(BptSlotInfo slot, IBptContext context)
  {
    if (!isWall) {
      double angle = slot.meta * 360.0D / 16.0D;
      angle += 90.0D;
      if (angle >= 360.0D) {
        angle -= 360.0D;
      }
      slot.meta = ((int)(angle / 360.0D * 16.0D));
    }
  }

  public BlockSignature getSignature(Block block)
  {
    BlockSignature sig = super.getSignature(block);

    if (isWall)
      sig.customField = "wall";
    else {
      sig.customField = "floor";
    }

    return sig;
  }
}