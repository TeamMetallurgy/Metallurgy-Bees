package buildcraft.api.tools;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

public abstract interface IToolPipette
{
  public abstract int getCapacity(ItemStack paramItemStack);

  public abstract boolean canPipette(ItemStack paramItemStack);

  public abstract int fill(ItemStack paramItemStack, FluidStack paramFluidStack, boolean paramBoolean);

  public abstract FluidStack drain(ItemStack paramItemStack, int paramInt, boolean paramBoolean);
}