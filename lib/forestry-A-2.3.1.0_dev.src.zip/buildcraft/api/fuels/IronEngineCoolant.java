package buildcraft.api.fuels;

import buildcraft.api.core.StackWrapper;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;

public final class IronEngineCoolant
{
  public static Map<String, Coolant> liquidCoolants = new HashMap();
  public static Map<StackWrapper, FluidStack> solidCoolants = new HashMap();

  public static FluidStack getFluidCoolant(ItemStack stack) {
    return (FluidStack)solidCoolants.get(new StackWrapper(stack));
  }

  public static Coolant getCoolant(ItemStack stack) {
    return getCoolant(getFluidCoolant(stack));
  }

  public static Coolant getCoolant(FluidStack fluidStack) {
    return fluidStack != null ? (Coolant)liquidCoolants.get(fluidStack.getFluid().getName()) : null;
  }

  public static void addCoolant(Fluid fluid, float degreesCoolingPerMB)
  {
    if (fluid != null)
      liquidCoolants.put(fluid.getName(), new Coolant()
      {
        public float getDegreesCoolingPerMB(float currentHeat) {
          return val$degreesCoolingPerMB;
        }
      });
  }

  public static void addCoolant(ItemStack stack, FluidStack coolant)
  {
    if ((stack != null) && (net.minecraft.item.Item.itemsList[itemID] != null) && (coolant != null))
      solidCoolants.put(new StackWrapper(stack), coolant);
  }

  public static void addCoolant(int itemId, int metadata, FluidStack coolant)
  {
    addCoolant(new ItemStack(itemId, 1, metadata), coolant);
  }

  public static boolean isCoolant(Fluid fluid) {
    return liquidCoolants.containsKey(fluid.getName());
  }

  public static abstract interface Coolant
  {
    public abstract float getDegreesCoolingPerMB(float paramFloat);
  }
}