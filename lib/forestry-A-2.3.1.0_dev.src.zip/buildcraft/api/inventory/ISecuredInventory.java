package buildcraft.api.inventory;

import net.minecraftforge.common.ForgeDirection;

public abstract interface ISecuredInventory
{
  public abstract boolean canAccess(String paramString);

  public abstract void prepareTransaction(ForgeDirection paramForgeDirection, String paramString);
}