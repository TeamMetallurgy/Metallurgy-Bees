package buildcraft.api.inventory;

import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.ForgeDirection;

public abstract interface ISpecialInventory extends IInventory
{
  public abstract int addItem(ItemStack paramItemStack, boolean paramBoolean, ForgeDirection paramForgeDirection);

  public abstract ItemStack[] extractItem(boolean paramBoolean, ForgeDirection paramForgeDirection, int paramInt);
}