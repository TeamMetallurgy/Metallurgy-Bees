package buildcraft.api.inventory;

import net.minecraft.item.ItemStack;
import net.minecraftforge.common.ForgeDirection;

public abstract interface ISelectiveInventory extends ISpecialInventory
{
  public abstract ItemStack[] extractItem(Object[] paramArrayOfObject, boolean paramBoolean1, boolean paramBoolean2, ForgeDirection paramForgeDirection, int paramInt);
}