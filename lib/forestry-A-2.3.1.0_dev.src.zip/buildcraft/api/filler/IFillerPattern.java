package buildcraft.api.filler;

import buildcraft.api.core.IBox;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;

public abstract interface IFillerPattern
{
  public abstract int getId();

  public abstract void setId(int paramInt);

  public abstract boolean iteratePattern(TileEntity paramTileEntity, IBox paramIBox, ItemStack paramItemStack);

  @SideOnly(Side.CLIENT)
  public abstract Icon getTexture();

  public abstract String getName();
}