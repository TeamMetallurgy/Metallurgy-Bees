package buildcraft.api.filler;

import net.minecraft.inventory.IInventory;

public abstract interface IFillerRegistry
{
  public abstract void addRecipe(IFillerPattern paramIFillerPattern, Object[] paramArrayOfObject);

  public abstract IFillerPattern findMatchingRecipe(IInventory paramIInventory);

  public abstract int getPatternNumber(IFillerPattern paramIFillerPattern);

  public abstract IFillerPattern getPattern(int paramInt);
}