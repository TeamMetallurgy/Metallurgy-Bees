package buildcraft.api.gates;

public abstract interface IActionReceptor
{
  public abstract void actionActivated(IAction paramIAction);
}