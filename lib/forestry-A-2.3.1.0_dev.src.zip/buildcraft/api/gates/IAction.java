package buildcraft.api.gates;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.util.Icon;

public abstract interface IAction
{
  public abstract int getLegacyId();

  public abstract String getUniqueTag();

  @SideOnly(Side.CLIENT)
  public abstract Icon getIcon();

  @SideOnly(Side.CLIENT)
  public abstract void registerIcons(IconRegister paramIconRegister);

  public abstract boolean hasParameter();

  public abstract String getDescription();
}