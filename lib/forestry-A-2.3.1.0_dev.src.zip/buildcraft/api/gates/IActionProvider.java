package buildcraft.api.gates;

import java.util.LinkedList;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;

public abstract interface IActionProvider
{
  public abstract LinkedList<IAction> getNeighborActions(Block paramBlock, TileEntity paramTileEntity);
}