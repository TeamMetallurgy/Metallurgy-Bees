package buildcraft.api.gates;

import buildcraft.api.transport.IPipe;
import java.util.LinkedList;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;

public abstract interface ITriggerProvider
{
  public abstract LinkedList<ITrigger> getPipeTriggers(IPipe paramIPipe);

  public abstract LinkedList<ITrigger> getNeighborTriggers(Block paramBlock, TileEntity paramTileEntity);
}