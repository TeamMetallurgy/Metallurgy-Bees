package buildcraft.api.gates;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public abstract interface ITriggerParameter
{
  public abstract ItemStack getItemStack();

  public abstract void set(ItemStack paramItemStack);

  public abstract void writeToNBT(NBTTagCompound paramNBTTagCompound);

  public abstract void readFromNBT(NBTTagCompound paramNBTTagCompound);

  @Deprecated
  public abstract ItemStack getItem();
}