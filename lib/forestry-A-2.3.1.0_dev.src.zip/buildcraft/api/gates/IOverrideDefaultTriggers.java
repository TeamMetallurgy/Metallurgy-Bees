package buildcraft.api.gates;

import java.util.LinkedList;

public abstract interface IOverrideDefaultTriggers
{
  public abstract LinkedList<ITrigger> getTriggers();
}