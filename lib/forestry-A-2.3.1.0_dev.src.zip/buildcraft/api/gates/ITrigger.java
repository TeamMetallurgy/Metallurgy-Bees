package buildcraft.api.gates;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraftforge.common.ForgeDirection;

public abstract interface ITrigger
{
  public abstract int getLegacyId();

  public abstract String getUniqueTag();

  @SideOnly(Side.CLIENT)
  public abstract Icon getIcon();

  @SideOnly(Side.CLIENT)
  public abstract void registerIcons(IconRegister paramIconRegister);

  public abstract boolean hasParameter();

  public abstract boolean requiresParameter();

  public abstract String getDescription();

  public abstract boolean isTriggerActive(ForgeDirection paramForgeDirection, TileEntity paramTileEntity, ITriggerParameter paramITriggerParameter);

  public abstract ITriggerParameter createParameter();
}