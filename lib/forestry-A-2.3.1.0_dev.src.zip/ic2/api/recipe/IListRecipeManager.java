package ic2.api.recipe;

import java.util.List;
import net.minecraft.item.ItemStack;

public abstract interface IListRecipeManager extends Iterable<ItemStack>
{
  public abstract void add(ItemStack paramItemStack);

  public abstract boolean contains(ItemStack paramItemStack);

  public abstract List<ItemStack> getStacks();
}