package ic2.api.recipe;

import net.minecraft.item.ItemStack;

public abstract interface ICraftingRecipeManager
{
  public abstract void addRecipe(ItemStack paramItemStack, Object[] paramArrayOfObject);

  public abstract void addShapelessRecipe(ItemStack paramItemStack, Object[] paramArrayOfObject);
}