package ic2.api.recipe;

import java.util.Map;
import net.minecraftforge.fluids.Fluid;

public abstract interface ISemiFluidFuelManager extends ILiquidAcceptManager
{
  public abstract void addFluid(String paramString, int paramInt, double paramDouble);

  public abstract BurnProperty getBurnProperty(Fluid paramFluid);

  public abstract Map<String, BurnProperty> getBurnProperties();

  public static class BurnProperty
  {
    public final int amount;
    public final double power;

    public BurnProperty(int amount, double power)
    {
      this.amount = amount;
      this.power = power;
    }
  }
}