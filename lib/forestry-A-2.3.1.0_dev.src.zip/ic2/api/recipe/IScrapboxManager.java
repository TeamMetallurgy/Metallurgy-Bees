package ic2.api.recipe;

import java.util.Map;
import net.minecraft.item.ItemStack;

public abstract interface IScrapboxManager
{
  public abstract void addDrop(ItemStack paramItemStack, float paramFloat);

  public abstract ItemStack getDrop(ItemStack paramItemStack, boolean paramBoolean);

  public abstract Map<ItemStack, Float> getDrops();
}