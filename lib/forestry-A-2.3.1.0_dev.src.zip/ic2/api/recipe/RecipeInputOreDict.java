package ic2.api.recipe;

import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

public class RecipeInputOreDict
  implements IRecipeInput
{
  public final String input;
  public final int amount;

  public RecipeInputOreDict(String input)
  {
    this(input, 1);
  }

  public RecipeInputOreDict(String input, int amount) {
    this.input = input;
    this.amount = amount;
  }

  public boolean matches(ItemStack subject)
  {
    List inputs = OreDictionary.getOres(this.input);

    for (ItemStack input : inputs) {
      if ((subject.itemID == input.itemID) && ((subject.getItemDamage() == input.getItemDamage()) || (input.getItemDamage() == 32767)))
      {
        return true;
      }
    }

    return false;
  }

  public int getAmount()
  {
    return amount;
  }

  public List<ItemStack> getInputs()
  {
    return OreDictionary.getOres(input);
  }
}