package ic2.api.recipe;

import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

public abstract interface ICannerEnrichRecipeManager
{
  public abstract void addRecipe(FluidStack paramFluidStack1, IRecipeInput paramIRecipeInput, FluidStack paramFluidStack2);

  public abstract RecipeOutput getOutputFor(FluidStack paramFluidStack, ItemStack paramItemStack, boolean paramBoolean1, boolean paramBoolean2);

  public abstract Map<Input, FluidStack> getRecipes();

  public static class Input
  {
    public final FluidStack fluid;
    public final IRecipeInput additive;

    public Input(FluidStack fluid, IRecipeInput additive)
    {
      this.fluid = fluid;
      this.additive = additive;
    }

    public boolean matches(FluidStack fluid, ItemStack additive) {
      return ((this.fluid == null) || (this.fluid.isFluidEqual(fluid))) && (this.additive.matches(additive));
    }
  }
}