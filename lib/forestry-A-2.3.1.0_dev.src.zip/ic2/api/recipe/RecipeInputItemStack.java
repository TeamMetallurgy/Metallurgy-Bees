package ic2.api.recipe;

import java.util.Arrays;
import java.util.List;
import net.minecraft.item.ItemStack;

public class RecipeInputItemStack
  implements IRecipeInput
{
  public final ItemStack input;
  public final int amount;

  public RecipeInputItemStack(ItemStack input)
  {
    this(input, input.stackSize);
  }

  public RecipeInputItemStack(ItemStack input, int amount) {
    this.input = input;
    this.amount = amount;
  }

  public boolean matches(ItemStack subject)
  {
    return (subject.itemID == input.itemID) && ((subject.getItemDamage() == input.getItemDamage()) || (input.getItemDamage() == 32767));
  }

  public int getAmount()
  {
    return amount;
  }

  public List<ItemStack> getInputs()
  {
    return Arrays.asList(new ItemStack[] { input });
  }
}