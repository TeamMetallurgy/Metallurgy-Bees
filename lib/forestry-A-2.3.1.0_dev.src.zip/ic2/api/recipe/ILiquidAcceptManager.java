package ic2.api.recipe;

import java.util.Set;
import net.minecraftforge.fluids.Fluid;

public abstract interface ILiquidAcceptManager
{
  public abstract boolean acceptsFluid(Fluid paramFluid);

  public abstract Set<Fluid> getAcceptedFluids();
}