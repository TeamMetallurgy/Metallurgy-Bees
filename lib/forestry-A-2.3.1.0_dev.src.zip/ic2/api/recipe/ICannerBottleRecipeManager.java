package ic2.api.recipe;

import java.util.Map;
import net.minecraft.item.ItemStack;

public abstract interface ICannerBottleRecipeManager
{
  public abstract void addRecipe(IRecipeInput paramIRecipeInput1, IRecipeInput paramIRecipeInput2, ItemStack paramItemStack);

  public abstract RecipeOutput getOutputFor(ItemStack paramItemStack1, ItemStack paramItemStack2, boolean paramBoolean1, boolean paramBoolean2);

  public abstract Map<Input, RecipeOutput> getRecipes();

  public static class Input
  {
    public final IRecipeInput container;
    public final IRecipeInput fill;

    public Input(IRecipeInput container, IRecipeInput fill)
    {
      this.container = container;
      this.fill = fill;
    }

    public boolean matches(ItemStack container, ItemStack fill) {
      return (this.container.matches(container)) && (this.fill.matches(fill));
    }
  }
}