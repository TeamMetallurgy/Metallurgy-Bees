package ic2.api.tile;

import net.minecraftforge.common.ForgeDirection;

public abstract interface IEnergyStorage
{
  public abstract int getStored();

  public abstract void setStored(int paramInt);

  public abstract int addEnergy(int paramInt);

  public abstract int getCapacity();

  public abstract int getOutput();

  public abstract double getOutputEnergyUnitsPerTick();

  public abstract boolean isTeleporterCompatible(ForgeDirection paramForgeDirection);
}