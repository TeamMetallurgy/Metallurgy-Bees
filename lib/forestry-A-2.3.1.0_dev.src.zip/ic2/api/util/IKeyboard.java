package ic2.api.util;

import net.minecraft.entity.player.EntityPlayer;

public abstract interface IKeyboard
{
  public abstract boolean isAltKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isBoostKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isForwardKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isJumpKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isModeSwitchKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isSideinventoryKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isHudModeKeyDown(EntityPlayer paramEntityPlayer);

  public abstract boolean isSneakKeyDown(EntityPlayer paramEntityPlayer);
}