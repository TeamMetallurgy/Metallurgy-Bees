package ic2.api.energy.prefab;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import ic2.api.energy.EnergyNet;
import ic2.api.energy.IEnergyNet;
import ic2.api.energy.event.EnergyTileLoadEvent;
import ic2.api.energy.event.EnergyTileUnloadEvent;
import ic2.api.energy.tile.IEnergySink;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;

public class BasicSink extends TileEntity
  implements IEnergySink
{
  public final TileEntity parent;
  public final int capacity;
  public final int tier;
  protected double energyStored;
  protected boolean addedToEnet;

  public BasicSink(TileEntity parent, int capacity, int tier)
  {
    this.parent = parent;
    this.capacity = capacity;
    this.tier = tier;
  }

  public void onUpdateEntity()
  {
    if (!addedToEnet) onLoaded();
  }

  public void onLoaded()
  {
    if ((!addedToEnet) && (!FMLCommonHandler.instance().getEffectiveSide().isClient())) {
      worldObj = parent.worldObj;
      xCoord = parent.xCoord;
      yCoord = parent.yCoord;
      zCoord = parent.zCoord;

      MinecraftForge.EVENT_BUS.post(new EnergyTileLoadEvent(this));

      addedToEnet = true;
    }
  }

  public void onInvalidate()
  {
    if (addedToEnet) {
      MinecraftForge.EVENT_BUS.post(new EnergyTileUnloadEvent(this));

      addedToEnet = false;
    }
  }

  public void onOnChunkUnload()
  {
    onInvalidate();
  }

  public void onReadFromNbt(NBTTagCompound tag)
  {
    NBTTagCompound data = tag.getCompoundTag("IC2BasicSink");

    energyStored = data.getDouble("energy");
  }

  public void onWriteToNbt(NBTTagCompound tag)
  {
    NBTTagCompound data = new NBTTagCompound();

    data.setDouble("energy", energyStored);

    tag.setTag("IC2BasicSink", data);
  }

  public double getEnergyStored()
  {
    return energyStored;
  }

  public void setEnergyStored(double amount)
  {
    energyStored = amount;
  }

  public boolean canUseEnergy(double amount)
  {
    return energyStored >= amount;
  }

  public boolean useEnergy(double amount)
  {
    if ((canUseEnergy(amount)) && (!FMLCommonHandler.instance().getEffectiveSide().isClient())) {
      energyStored -= amount;

      return true;
    }
    return false;
  }

  public boolean acceptsEnergyFrom(TileEntity emitter, ForgeDirection direction)
  {
    return true;
  }

  public double demandedEnergyUnits()
  {
    return Math.max(0.0D, capacity - energyStored);
  }

  public double injectEnergyUnits(ForgeDirection directionFrom, double amount)
  {
    energyStored += amount;

    return 0.0D;
  }

  public int getMaxSafeInput()
  {
    return EnergyNet.instance.getPowerFromTier(tier);
  }
}