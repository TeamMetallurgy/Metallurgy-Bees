package ic2.api.energy.prefab;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import ic2.api.energy.EnergyNet;
import ic2.api.energy.IEnergyNet;
import ic2.api.energy.event.EnergyTileLoadEvent;
import ic2.api.energy.event.EnergyTileUnloadEvent;
import ic2.api.energy.tile.IEnergySource;
import ic2.api.item.ElectricItem;
import ic2.api.item.IElectricItemManager;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;

public class BasicSource extends TileEntity
  implements IEnergySource
{
  public final TileEntity parent;
  public final int capacity;
  public final int tier;
  protected double energyStored;
  protected boolean addedToEnet;

  public BasicSource(TileEntity parent, int capacity, int tier)
  {
    int power = EnergyNet.instance.getPowerFromTier(tier);

    this.parent = parent;
    this.capacity = (capacity < power ? power : capacity);
    this.tier = tier;
  }

  public void onUpdateEntity()
  {
    if (!addedToEnet) onLoaded();
  }

  public void onLoaded()
  {
    if ((!addedToEnet) && (!FMLCommonHandler.instance().getEffectiveSide().isClient())) {
      worldObj = parent.worldObj;
      xCoord = parent.xCoord;
      yCoord = parent.yCoord;
      zCoord = parent.zCoord;

      MinecraftForge.EVENT_BUS.post(new EnergyTileLoadEvent(this));

      addedToEnet = true;
    }
  }

  public void onInvalidate()
  {
    if (addedToEnet) {
      MinecraftForge.EVENT_BUS.post(new EnergyTileUnloadEvent(this));

      addedToEnet = false;
    }
  }

  public void onOnChunkUnload()
  {
    onInvalidate();
  }

  public void onReadFromNbt(NBTTagCompound tag)
  {
    NBTTagCompound data = tag.getCompoundTag("IC2BasicSource");

    energyStored = data.getDouble("energy");
  }

  public void onWriteToNbt(NBTTagCompound tag)
  {
    NBTTagCompound data = new NBTTagCompound();

    data.setDouble("energy", energyStored);

    tag.setTag("IC2BasicSource", data);
  }

  public double getEnergyStored()
  {
    return energyStored;
  }

  public void setEnergyStored(double amount)
  {
    energyStored = amount;
  }

  public double getFreeCapacity()
  {
    return capacity - energyStored;
  }

  public double addEnergy(double amount)
  {
    if (FMLCommonHandler.instance().getEffectiveSide().isClient()) return 0.0D;
    if (amount > capacity - energyStored) amount = capacity - energyStored;

    energyStored += amount;

    return amount;
  }

  public boolean charge(ItemStack stack)
  {
    if (stack == null) return false;

    int amount = ElectricItem.manager.charge(stack, (int)energyStored, tier, false, false);

    energyStored -= amount;

    return amount > 0;
  }

  public boolean emitsEnergyTo(TileEntity receiver, ForgeDirection direction)
  {
    return true;
  }

  public double getOfferedEnergy()
  {
    int power = EnergyNet.instance.getPowerFromTier(tier);

    if (energyStored >= power) {
      return power;
    }
    return 0.0D;
  }

  public void drawEnergy(double amount)
  {
    energyStored -= amount;
  }
}