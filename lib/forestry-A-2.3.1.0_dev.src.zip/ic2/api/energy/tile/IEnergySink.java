package ic2.api.energy.tile;

import net.minecraftforge.common.ForgeDirection;

public abstract interface IEnergySink extends IEnergyAcceptor
{
  public abstract double demandedEnergyUnits();

  public abstract double injectEnergyUnits(ForgeDirection paramForgeDirection, double paramDouble);

  public abstract int getMaxSafeInput();
}