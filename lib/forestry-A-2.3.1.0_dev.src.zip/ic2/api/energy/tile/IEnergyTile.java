package ic2.api.energy.tile;

public abstract interface IEnergyTile
{
}