package ic2.api.energy;

public final class EnergyNet
{
  public static IEnergyNet instance;
}