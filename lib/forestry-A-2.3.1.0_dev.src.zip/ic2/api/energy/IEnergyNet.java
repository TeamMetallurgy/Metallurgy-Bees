package ic2.api.energy;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeDirection;

public abstract interface IEnergyNet
{
  public abstract TileEntity getTileEntity(World paramWorld, int paramInt1, int paramInt2, int paramInt3);

  public abstract TileEntity getNeighbor(TileEntity paramTileEntity, ForgeDirection paramForgeDirection);

  public abstract long getTotalEnergyEmitted(TileEntity paramTileEntity);

  public abstract long getTotalEnergySunken(TileEntity paramTileEntity);

  public abstract int getPowerFromTier(int paramInt);
}