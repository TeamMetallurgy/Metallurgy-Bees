package ic2.api.reactor;

public abstract interface IReactorChamber
{
  public abstract IReactor getReactor();
}