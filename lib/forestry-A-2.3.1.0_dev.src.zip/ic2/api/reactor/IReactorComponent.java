package ic2.api.reactor;

import net.minecraft.item.ItemStack;

public abstract interface IReactorComponent
{
  public abstract void processChamber(IReactor paramIReactor, ItemStack paramItemStack, int paramInt1, int paramInt2);

  public abstract boolean acceptUraniumPulse(IReactor paramIReactor, ItemStack paramItemStack1, ItemStack paramItemStack2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract boolean canStoreHeat(IReactor paramIReactor, ItemStack paramItemStack, int paramInt1, int paramInt2);

  public abstract int getMaxHeat(IReactor paramIReactor, ItemStack paramItemStack, int paramInt1, int paramInt2);

  public abstract int getCurrentHeat(IReactor paramIReactor, ItemStack paramItemStack, int paramInt1, int paramInt2);

  public abstract int alterHeat(IReactor paramIReactor, ItemStack paramItemStack, int paramInt1, int paramInt2, int paramInt3);

  public abstract float influenceExplosion(IReactor paramIReactor, ItemStack paramItemStack);
}