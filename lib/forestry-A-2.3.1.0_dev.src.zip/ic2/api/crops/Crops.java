package ic2.api.crops;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.item.ItemStack;
import net.minecraft.world.biome.BiomeGenBase;

public abstract class Crops
{
  public static Crops instance;

  public abstract void addBiomeBonus(BiomeGenBase paramBiomeGenBase, int paramInt1, int paramInt2);

  public abstract int getHumidityBiomeBonus(BiomeGenBase paramBiomeGenBase);

  public abstract int getNutrientBiomeBonus(BiomeGenBase paramBiomeGenBase);

  public abstract CropCard[] getCropList();

  public abstract short registerCrop(CropCard paramCropCard);

  public abstract boolean registerCrop(CropCard paramCropCard, int paramInt);

  public abstract boolean registerBaseSeed(ItemStack paramItemStack, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract BaseSeed getBaseSeed(ItemStack paramItemStack);

  @SideOnly(Side.CLIENT)
  public abstract void startSpriteRegistration(IconRegister paramIconRegister);

  public abstract int getIdFor(CropCard paramCropCard);
}