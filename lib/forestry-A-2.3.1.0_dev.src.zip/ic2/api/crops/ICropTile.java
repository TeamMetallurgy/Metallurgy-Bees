package ic2.api.crops;

import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;

public abstract interface ICropTile
{
  public abstract short getID();

  public abstract void setID(short paramShort);

  public abstract byte getSize();

  public abstract void setSize(byte paramByte);

  public abstract byte getGrowth();

  public abstract void setGrowth(byte paramByte);

  public abstract byte getGain();

  public abstract void setGain(byte paramByte);

  public abstract byte getResistance();

  public abstract void setResistance(byte paramByte);

  public abstract byte getScanLevel();

  public abstract void setScanLevel(byte paramByte);

  public abstract NBTTagCompound getCustomData();

  public abstract int getNutrientStorage();

  public abstract void setNutrientStorage(int paramInt);

  public abstract int getHydrationStorage();

  public abstract void setHydrationStorage(int paramInt);

  public abstract int getWeedExStorage();

  public abstract void setWeedExStorage(int paramInt);

  public abstract byte getHumidity();

  public abstract byte getNutrients();

  public abstract byte getAirQuality();

  public abstract World getWorld();

  public abstract ChunkCoordinates getLocation();

  public abstract int getLightLevel();

  public abstract boolean pick(boolean paramBoolean);

  public abstract boolean harvest(boolean paramBoolean);

  public abstract void reset();

  public abstract void updateState();

  public abstract boolean isBlockBelow(Block paramBlock);

  public abstract ItemStack generateSeeds(short paramShort, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4);
}