package ic2.api.item;

import net.minecraft.item.ItemStack;

public abstract interface ISpecialElectricItem extends IElectricItem
{
  public abstract IElectricItemManager getManager(ItemStack paramItemStack);
}