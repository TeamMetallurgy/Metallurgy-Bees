package ic2.api.item;

import java.util.List;
import net.minecraft.item.ItemStack;

public abstract interface IItemHudInfo
{
  public abstract List<String> getHudInfo(ItemStack paramItemStack);
}