package ic2.api.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public abstract interface IMetalArmor
{
  public abstract boolean isMetalArmor(ItemStack paramItemStack, EntityPlayer paramEntityPlayer);
}