package ic2.api.item;

public abstract interface IDebuggable
{
  public abstract boolean isDebuggable();

  public abstract String getDebugText();
}