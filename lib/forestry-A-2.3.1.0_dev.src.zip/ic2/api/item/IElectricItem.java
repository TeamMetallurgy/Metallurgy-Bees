package ic2.api.item;

import net.minecraft.item.ItemStack;

public abstract interface IElectricItem
{
  public abstract boolean canProvideEnergy(ItemStack paramItemStack);

  public abstract int getChargedItemId(ItemStack paramItemStack);

  public abstract int getEmptyItemId(ItemStack paramItemStack);

  public abstract int getMaxCharge(ItemStack paramItemStack);

  public abstract int getTier(ItemStack paramItemStack);

  public abstract int getTransferLimit(ItemStack paramItemStack);
}