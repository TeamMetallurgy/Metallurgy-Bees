package ic2.api.item;

import net.minecraft.world.World;

public abstract interface ITerraformingBP
{
  public abstract int getConsume();

  public abstract int getRange();

  public abstract boolean terraform(World paramWorld, int paramInt1, int paramInt2, int paramInt3);
}