package ic2.api.item;

import net.minecraft.item.ItemStack;

public abstract interface IBoxable
{
  public abstract boolean canBeStoredInToolbox(ItemStack paramItemStack);
}