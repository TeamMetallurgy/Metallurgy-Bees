package ic2.api.item;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public abstract interface IElectricItemManager
{
  public abstract int charge(ItemStack paramItemStack, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2);

  public abstract int discharge(ItemStack paramItemStack, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2);

  public abstract int getCharge(ItemStack paramItemStack);

  public abstract boolean canUse(ItemStack paramItemStack, int paramInt);

  public abstract boolean use(ItemStack paramItemStack, int paramInt, EntityLivingBase paramEntityLivingBase);

  public abstract void chargeFromArmor(ItemStack paramItemStack, EntityLivingBase paramEntityLivingBase);

  public abstract String getToolTip(ItemStack paramItemStack);
}