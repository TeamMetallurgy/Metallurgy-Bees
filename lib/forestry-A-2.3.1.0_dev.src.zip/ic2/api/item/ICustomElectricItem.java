package ic2.api.item;

import net.minecraft.item.ItemStack;

@Deprecated
public abstract interface ICustomElectricItem extends IElectricItem
{
  public abstract int charge(ItemStack paramItemStack, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2);

  public abstract int discharge(ItemStack paramItemStack, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2);

  public abstract boolean canUse(ItemStack paramItemStack, int paramInt);

  public abstract boolean canShowChargeToolTip(ItemStack paramItemStack);
}