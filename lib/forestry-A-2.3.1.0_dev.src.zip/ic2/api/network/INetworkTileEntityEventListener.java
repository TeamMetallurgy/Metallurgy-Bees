package ic2.api.network;

public abstract interface INetworkTileEntityEventListener
{
  public abstract void onNetworkEvent(int paramInt);
}