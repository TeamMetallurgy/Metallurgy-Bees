package ic2.api.network;

import net.minecraft.entity.player.EntityPlayer;

public abstract interface INetworkClientTileEntityEventListener
{
  public abstract void onNetworkEvent(EntityPlayer paramEntityPlayer, int paramInt);
}