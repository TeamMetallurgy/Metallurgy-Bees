package ic2.api.network;

import java.util.List;

public abstract interface INetworkDataProvider
{
  public abstract List<String> getNetworkedFields();
}