package ic2.api.network;

public abstract interface INetworkUpdateListener
{
  public abstract void onNetworkUpdate(String paramString);
}