package ic2.api.network;

import net.minecraft.entity.player.EntityPlayer;

public abstract interface INetworkItemEventListener
{
  public abstract void onNetworkEvent(int paramInt1, EntityPlayer paramEntityPlayer, int paramInt2);
}