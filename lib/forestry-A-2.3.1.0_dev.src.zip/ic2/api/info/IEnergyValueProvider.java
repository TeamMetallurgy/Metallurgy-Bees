package ic2.api.info;

import net.minecraft.item.ItemStack;

public abstract interface IEnergyValueProvider
{
  public abstract int getEnergyValue(ItemStack paramItemStack);
}