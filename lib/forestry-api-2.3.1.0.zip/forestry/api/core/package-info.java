@API(apiVersion="1.0", owner="Forestry", provides="ForestryAPI|core")
package forestry.api.core;
import cpw.mods.fml.common.API;