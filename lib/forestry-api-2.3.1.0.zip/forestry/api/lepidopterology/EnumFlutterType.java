package forestry.api.lepidopterology;

public enum EnumFlutterType {
	BUTTERFLY,
	SERUM,
	CATERPILLAR,
	NONE;
	
	public static final EnumFlutterType[] VALUES = values();
}