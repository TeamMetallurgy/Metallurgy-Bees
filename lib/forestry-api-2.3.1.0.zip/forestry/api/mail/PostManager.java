package forestry.api.mail;


public class PostManager {
	public static IPostRegistry postRegistry;
}
