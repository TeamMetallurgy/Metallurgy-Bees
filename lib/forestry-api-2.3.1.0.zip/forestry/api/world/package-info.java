@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|world")
package forestry.api.world;
import cpw.mods.fml.common.API;