package forestry.api.circuits;

public interface ICircuitLibrary {

}
