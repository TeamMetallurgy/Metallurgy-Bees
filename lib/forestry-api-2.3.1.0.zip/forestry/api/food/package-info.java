@API(apiVersion="1.0", owner="ForestryAPI|core", provides="ForestryAPI|food")
package forestry.api.food;
import cpw.mods.fml.common.API;