package forestry.api.genetics;

/**
 * Simple interface to allow adding additional alleles containing float values.
 */
public interface IAlleleBoolean extends IAllele {

	boolean getValue();


}
