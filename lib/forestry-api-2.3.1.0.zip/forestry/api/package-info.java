@API(apiVersion="1.0", owner="Forestry", provides="ForestryAPI|core")
package forestry.api;
import cpw.mods.fml.common.API;